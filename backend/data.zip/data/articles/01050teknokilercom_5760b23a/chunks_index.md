# Chunks Index

| ID    | Section                        | Heading Path                   | Char Range | Preview                                                                                     |
| ----- | ------------------------------ | ------------------------------ | ---------- | ------------------------------------------------------------------------------------------- |
| c0000 | Angry Birds Halka Arz Ediliyor | Angry Birds Halka Arz Ediliyor | 0-1000     | = Angry Birds Halka Arz Ediliyor = Bir dönemi kasıp kavuran Angry Birds halka arz ediliyor. |
| c0001 | Angry Birds Halka Arz Ediliyor | Angry Birds Halka Arz Ediliyor | 800-1446   | gerçekleşirse, şirketin hisse başı hedeflediği rakamlar 10.25 ile 11.50 Euro arasında.      |