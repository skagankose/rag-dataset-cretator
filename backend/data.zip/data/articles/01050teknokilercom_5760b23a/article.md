---
id: 01050teknokilercom_5760b23a
url: file://01050_teknokiler_com.md
title: 01050 teknokiler com
lang: en
created_at: '2025-12-19T23:30:28.541931'
checksum: b92b56f2f120adf4f838175b09911d532d583017e2be49a001c13fe5eaeba4a9
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 205
  char_count: 1446
  num_chunks: 2
  num_sections: 1
---
= Angry Birds Halka Arz Ediliyor =

Bir dönemi kasıp kavuran Angry Birds halka arz ediliyor. Firmanın hisselerine şimdiden değer biçildi. Bir dönemin popüler mobil oyunu Angry Birds'ü hatırlıyor musunuz? Hisseler halka açıldığına göre, demek ki hâlâ ilgi gösterenler var.

Akıllı telefon oyununun Finlandiya menşeli geliştiricisi Rovio Entertainment, iki hafta içinde şirketi Helsinki Nasdaq'ta halka arz etmek için hazırlanıyor. Halka arz için fiyat aralığı 1 milyar dolar olarak belirlenirken, daha önce ümit edilen rakam 2 milyar dolardan fazlaydı. Rovio Entertainment, aynı zamanda Accel, Atomico, Felicis Ventures ve diğer şirketlerden en azından 42 milyon dolar öz sermaye finansmanı sağladı.

Filmi dahi çekilmişti fakat yine de ciddi oranda para kazanılması bekleniyor. Eğer halka arz işlemi gerçekleşirse, şirketin hisse başı hedeflediği rakamlar 10.25 ile 11.50 Euro arasında.

İlk olarak 2009 yılında piyasaya çıkan Angry Birds oyunları şimdiye kadar 3.7 milyardan fazla indirildi. Bu başarı öylesine büyüktü ki, nadir gerçekleşen bir olay oldu ve oyunun filmi çekildi. *The Angry Birds Movie* adlı film geçen yıl gösterime girmişti ve ‘ortalama’ olarak değerlendirilmişti.

Crush the Castle oyunundan etkilenen ve eğlenceli tarzı, uygun fiyatıyla kısa sürede büyük etki yaratan Angry Birds, iOS'tan sonra Android, Symbian ve Windows Phone işletim sistemlerine gelmişti. Hatta daha sonra oyun konsolları ve PC için dahi port edilmişti.