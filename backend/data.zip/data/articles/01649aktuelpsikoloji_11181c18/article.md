---
id: 01649aktuelpsikoloji_11181c18
url: file://01649_aktuelpsikoloji_com.md
title: 01649 aktuelpsikoloji com
lang: en
created_at: '2025-12-19T23:50:14.536323'
checksum: 222c16bc39aaddf8b1b2ab6817f995d1200e755b71911017f5ebb35608e6297b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 362
  char_count: 2897
  num_chunks: 4
  num_sections: 3
---
13:2113 Ocak 2011 Mardin'in Midyat ilçesinde sosyolog Tekin Karaçam tarafından öğrencilerin evden kaçma eğilimine yönelik bir araştırma yapıldı. Araştırmaya göre ailesinden şiddet gören, sigara ve uyuşturucu kullanan öğrencilerin evden kaçma eğilimi daha fazla. Bu öğrencilerin yüzde 67'si ailesiyle önemli sorunlar yaşarken, öğrencilerde öfke kontrol sorunu olduğu ve yüzde 70,4'ünün aşırı TV izlediği belirlendi.  

Mardin'in Midyat ilçesinde yapılan bir araştırmada, sigara ve uyuşturucu kullanan, ailesinden şiddet gören ve arabesk müzik dinleyen öğrencilerin evden kaçmaya meyilli oldukları ortaya çıktı. Midyat Cumhuriyet Başsavcılığı'na bağlı Denetimli Serbestlik Şube Müdürlüğü'nce sosyolog Tekin Karaçam'a yaptırılan araştırmaya Midyat'ta okuyan 102 öğrenci katıldı. Yapılan yüz yüze görüşmeler ve anket formlarının doldurulmasıyla evden kaçma düşüncesinde olan lise öğrencileri tespit edilerek bu öğrenciler üzerinde araştırma yapıldı.  

Evden kaçma eğiliminde olan her üç öğrenciden birinin (yüzde 32,3) ailesinden şiddet gördüğü, bu öğrencilerin aileleri ile ilişkilerinde önemli oranda sorunlar yaşandığı (yüzde 67), özellikle ebeveynler ile çocuklar arasında iletişimin kopuk olduğunun ortaya çıktığını belirten Karaçam, "Uyuşturucu ve sigara bağımlısı çocuklar evden kaçmaya daha çok eğilimlidir. Yine aynı şekilde arabesk müziğinin de (yüzde 26,9) evden kaçma davranışında itici bir rol oynadığı görülmüştür. Öğrencilerin yüzde 19,6'sı sigara tiryakisidir." dedi.  

Her dört öğrenciden en az birinin bıçak ve benzeri aletler taşıdığı (yüzde 27,4), kendilerini güvende hissetmedikleri, diğer öğrencilerden farklı olarak intihara daha eğilimli oldukları (yüzde 31,3) yapılan araştırmada ulaşılan sonuçlar arasında yer aldı.  

= EVDEN KAÇMAK İSTEYEN ÖĞRENCİ, ÇOK TELEVİZYON İZLİYOR =
Evden kaçma eğiliminde olan her iki öğrenciden birinin aile içinde sık sık sorunlar yaşadığını, her iki öğrenciden birinin öfke sorunu olduğunu (yüzde 67,6) kaydeden Karaçam, evden kaçma eğiliminde olan öğrencilerin diğer öğrencilere göre daha uzun süreli televizyon izlediklerini (yüzde 70,4) ve meşhur olmak istediklerini aktardı.  

= EVDEN KAÇMANIN SEBEPLERİNİ ARAŞTIRDI =
Araştırmayı yapan sosyolog Tekin Karaçam, öğrencileri suç ve riskli davranışlar açısından incelediklerini ancak evden kaçma düşüncesinin bazı öğrencide yoğun yaşandığını fark ettiklerini, bu yüzden öğrencilerin evden kaçma düşüncesinin sebeplerini bulmak için böyle bir araştırma yaptıklarını ifade etti. Karaçam, "Yapılan araştırmada ortaya çıkan sonuçlar değerlendirildiğinde her şeyden önce ebeveynlerin çocukları ile daha sık ilgilenmeleri, çocukların yaşları ve gelişim dönemlerini de göz önüne alarak çocuklara yaklaşımda daha özenli davranmaları gerektiği ortaya çıkmıştır." dedi. TV'nin çocuklar üzerindeki etkilerinin sınırlandırılması gerektiğini dile getiren Karaçam, yaşları ve gelişimleri itibarıyla duyg...