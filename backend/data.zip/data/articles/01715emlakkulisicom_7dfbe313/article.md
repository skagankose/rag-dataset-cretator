---
id: 01715emlakkulisicom_7dfbe313
url: file://01715_emlakkulisi_com.md
title: 01715 emlakkulisi com
lang: en
created_at: '2025-12-19T23:52:27.543998'
checksum: 019e7d8381f9cd3064eddd1baa5114d573d9c16dd411a6c930859baf224d6c17
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 280
  char_count: 2080
  num_chunks: 3
  num_sections: 1
---
= İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor =

30 Ocak 2020, Perşembe / 10:30 – İtalya’da birçok küçük köy ve kasabanın uyguladığı “1 Avro’ya ev” projesi ilk kez bir şehirde de başlatılacak. Ülkenin güneyindeki Taranto şehri, tarihi kent merkezini canlandırmak ve kalkındırmak hedefiyle 1 Avro’ya ev projesi başlatmaya karar verdi.

Taranto son senelerde, Avrupa’nın en büyük çelik fabrikası Ilva ve bu fabrikanın sebep olduğu çevre kirliliği ile haberlerde sık sık yer alan bir şehir. Cumhuriyet gazetesinde yer alan habere göre, İtalya’nın güneyinde, Puglia bölgesinde yer alan Taranto şehri, nüfus kaybı yaşayan tarihi kent merkezini yeniden canlandırmak ve kalkındırmak hedefiyle 1 Avro’ya ev projesi başlatmaya karar verdi.

İlk aşamada belediyeye ait 5 ev bu proje kapsamında satışa çıkarılacak, başarılı sonuç alınırsa başka evler de bu şekilde satışa sunulacak. 1 Avro’ya ev projesi başlatan diğer yerleşim yerlerinde olduğu gibi Taranto’da da bu fırsattan faydalanabilmek için, büyük onarıma ihtiyaç duyan evlerde restorasyon yaptırma garantisi istenecek.

Taranto Belediye Meclisi’nin tarihi mirastan sorumlu üyesi Francesca Viggiano, “1 Avro’ya ev” planıyla ilgili basın açıklamasında, “Tarihi kent merkezini canlandıracak yatırımları çekmek istiyoruz” diye konuştu. Taranto’nun dışarıya göç veren bir kent olduğunu belirten Viggiano, “Taranto’nun artık insanların gittiği bir yer değil, döndüğü bir yer olmasını” planladıklarını aktardı.

Taranto’nun tarihi merkezinde 19. yüzyılda yaklaşık 37 bin kişi yaşarken bugün bu sayının 2 800 civarına kadar indiği belirtiliyor. İtalya’da özellikle güney bölgelerde nüfus kaybı sorunu yaşayan çok sayıda küçük köy ve kasaba, metruk evleri 1 Avro’dan başlayan fiyatlarla satışa çıkarmıştı. Sicilya adasındaki Bivona, Cammarata, Mussomeli ve Sambuca kasabaları, “hayalet kasabaya” dönmekten kurtulmak için benzer projelerle terk edilmiş evleri satışa sunan yerleşim birimleri arasında bulunuyor. Bu projelerin bazısı açık artırma usulüyle, bazılarıysa kapsamlı bir restorasyon planı sunumuyla katılım olanağı verilmişti.