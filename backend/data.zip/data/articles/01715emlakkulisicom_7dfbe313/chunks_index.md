# Chunks Index

| ID    | Section                                           | Heading Path                                      | Char Range | Preview                                                                                                |
| ----- | ------------------------------------------------- | ------------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | 0-1000     | = İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor = 30 Ocak 2020, Perşembe / 10:30 – İtalya’da...    |
| c0001 | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | 800-1800   | arılacak, başarılı sonuç alınırsa başka evler de bu şekilde satışa sunulacak.                          |
| c0002 | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | İtalya’da 1 Avroya Ev Satışı: Taranto’da Başlıyor | 1600-2080  | özellikle güney bölgelerde nüfus kaybı sorunu yaşayan çok sayıda küçük köy ve kasaba, metruk evleri... |