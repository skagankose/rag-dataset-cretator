---
id: 00536haberlercom_b1298014
url: file://00536_haberler_com.md
title: 00536 haberler com
lang: en
created_at: '2025-12-19T23:13:19.535240'
checksum: 4c7b1eaf249b5667c5680d7e94dff6101c2c91cc00bd8b955aa1524b878f2c1a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 228
  char_count: 1689
  num_chunks: 2
  num_sections: 1
---
Alman basını, Bayern Münih'in ilk maç sonunda turu bitirdiğini yazdı, "Çeyrek final bileti artık Bayern'in elinden alınamaz" ifadesini kullandı. 22 Şubat 2018 Perşembe 02:36 UEFA Şampiyonlar Ligi son 16 turu ilk maçında Bayern Münih'in evinde Başiktaş'ı 5-0 mağlup etmesi Alman basınında geniş yer buldu. Ülke medyası, Bayern Münih'in çeyrek finali büyük ölçüde garantilediği görüşünde birleşti. Kicker dergisi, "Bayern Münih açık bir şekilde çeyrek final yolunda" başlığını kullanarak, kırmızı-beyazlıların son 8'e kalma yolunda dev bir adım attığını vurguladı. Haberde, Beşiktaş'ın 10 kişi kaldıktan sonra Vagner Love ve Quaresma ile iki gol pozisyonu bulduğuna da dikkat çekildi. "İKİNCİ YARIDA FARKA KOŞTULAR" Frankfurter Allgemeine Zeitung gazetesi, "Bayern Münih 5-0'la Beşiktaş'ı cezalandırdı" başlığıyla duyurduğu haberde, Beşiktaş'ın Vida'nın kırmızı kart görmesinden sonra yarım saat daha maça ortak olduğu ancak Alman ekibinin ikinci yarıda farka koştuğu kaydedildi. Diğer gazetelerde öne çıkan yorumlar ise şöyle: "ARTIK BİLET MÜNİH'TEN ALINAMAZ" Sport Bild: Lewandowski ve Müller'in duble golleri ile Şampiyonlar Ligi'nde çeyrek final bileti artık Bayern Münih'in elinden alınamaz. Abendzeitung: Çak bir beşlik! Bayern Münih sahasında Beşiktaş'ı dağıttı. Maçı 5-0'lık ezici skorla kazanan Bayern çok rahat şekilde İstanbul'a gidecek. "ROBBEN ÜZGÜNDÜ" Süddeutsche: Bayern Münih, Beşiktaş karşısında 5-0 galip gelerek ikinci maç için çok büyük avantaj sağladı. Müller, takımına iki gol ile katkı sağlarken, Robben ilk 11'de başlamadığı için üzgündü. Tagesspiegel: Şampiyonlar Ligi son 16 turunda bir kırmızı kart, 5-0'lık kolay galibiyet almak için Bayern Münih'e yardımcı oldu.