# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                              |
| ----- | ------- | ------------ | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Alman basını, Bayern Münih'in ilk maç sonunda turu bitirdiğini yazdı, "Çeyrek final bileti artık...  |
| c0001 | Lead    | Lead         | 800-1689   | başlığıyla duyurduğu haberde, Beşiktaş'ın Vida'nın kırmızı kart görmesinden sonra yarım saat daha... |