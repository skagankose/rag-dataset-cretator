---
id: 01694donanimhabercom_94fd1b61
url: file://01694_donanimhaber_com.md
title: 01694 donanimhaber com
lang: en
created_at: '2025-12-19T23:51:44.530700'
checksum: 593d0d0f522e35407ca3609e47bfae9c4d782e1823b6a047cbc47e3137e04b25
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 136
  char_count: 1357
  num_chunks: 2
  num_sections: 1
---
= Nokia 14 Milyon şarj cihazı için değiştirme programı hazırladı =

*09 Kasım 2009, 22:05 (12 yıl)*  

Dünyanın telekomünikasyon denildiğinde ilk akla gelen firmalarından Finlandiya merkezli Nokia, BYD tarafından 15 Haziran 2009 ile 9 Ağustos 2009 tarihleri arasında üretilmiş AC‑3U ve AC‑3E ile 13 Nisan 2009 ile 25 Ekim 2009 arasında üretilen AC‑4U'u kapsayan yaklaşık 14 milyon şarj adaptörü için değiştirme programını başlattığını duyurdu. Firma tarafından yapılan açıklamada ilgili şarj cihazlarının plastik kapaklarının gevşemesi sonucunda dahili bileşenlerinin açıkta kalabileceğini ve bunun sonucunda elektrik çarpması gibi durumlara maruz kalınabileceği belirtildi. Ayrıca Finlandiyalı Nokia, konuyla ilgili şimdiye kadar cihazlarla ilgili herhangi bir olay haberi alınmamasına rağmen, tedbir gereği böyle bir değiştirme programı hazırlandığını da ekledi.

[https://chargerexchange.nokia.com/chargerexchange/tr/](https://chargerexchange.nokia.com/chargerexchange/tr/) adresindeki ilgili alanları doldurarak şarj cihazınızın geri çağrılan adaptörlerden olup olmadığını rahatlıkla anlayabilir, değiştirme kapsamındaysa ücretsiz olarak programdan yararlanabilirsiniz.

**Kaynaklar:** [Nokia](http://chargerexchange.nokia.com/chargerexchange/tr/), [Electronista](http://www.electronista.com/articles/09/11/09/nokia.to.replace.faulty.byd.phone.chargers)