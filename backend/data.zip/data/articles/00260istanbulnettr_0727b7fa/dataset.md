# Dataset: 00260 istanbul net tr

Generated on: 2025-12-19T23:04:26.707802
Total questions: 1

| # | Question                                     | Answer                                     | Category | Related_Chunk_IDs |
| - | -------------------------------------------- | ------------------------------------------ | -------- | ----------------- |
| 1 | No Age hangi tarihte ve nerede sahne alacak? | 30 Nisan Cumartesi günü Bronx Pi Sahne'de. | FACTUAL  | c0000             |