# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                               |
| ----- | ------- | ------------ | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-733      | Kulaklığınızı kulağınıza taktığınız anda gökyüzündeki bulutların aralanıp ışıldayan güneşin ortaya... |