# Chunks Index

| ID    | Section                                   | Heading Path                              | Char Range | Preview                                                                                               |
| ----- | ----------------------------------------- | ----------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | Sağlık Bakanı 05:30'da Hastaneye Giderse! | Sağlık Bakanı 05:30'da Hastaneye Giderse! | 0-1000     | = Sağlık Bakanı 05:30'da Hastaneye Giderse!                                                           |
| c0001 | Sağlık Bakanı 05:30'da Hastaneye Giderse! | Sağlık Bakanı 05:30'da Hastaneye Giderse! | 800-1330   | yerine kolaylık sağlamak hedefinde olduklarını söyleyen Sucuoğlu, en kısa sürede hastane Başhekimi... |