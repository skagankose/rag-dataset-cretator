---
id: 03632detaykibriscom_fc6fe89c
url: file://03632_detaykibris_com.md
title: 03632 detaykibris com
lang: en
created_at: '2025-12-20T00:30:57.554524'
checksum: e0844070402a6036ccac17f1c6d0db04a0201e905c7cf353ff9726cbb449a3d0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 162
  char_count: 1330
  num_chunks: 2
  num_sections: 1
---
= Sağlık Bakanı 05:30'da Hastaneye Giderse! =

Sağlık Bakanı Dr. Faiz Sucuoğlu, bu sabah 05.30'da Dr. Burhan Nalbantoğlu Devlet Hastanesi poliklinik servisini ziyaret ederek, sıra numarası almak için gelen vatandaşlar ile görüştü. Bakan Sucuoğlu'na ziyareti sırasında Müsteşar, Bakanlık Müdürü, Hastane Başhekimi, Bakanlık yetkilileri ve hastane yetkilileri eşlik etti.

Hastanenin poliklinik servisinde doktor muayenesi yaptırmak için erken saatlerde gelen vatandaşların yaşadığı sıkıntıları görmek ve yıllardır süren mağduriyete bir çözüm üretmek amacıyla sabahın erken saatlerinde hastaneyi ziyaret eden Bakan Sucuoğlu, vatandaşların erken saatlerde gelip perişan olmamaları için hastane yönetimi ile yeni bir düzenleme yapacaklarını ifade etti.

Vatandaşa sağlık hizmeti sunarken zorluk çıkarmak yerine kolaylık sağlamak hedefinde olduklarını söyleyen Sucuoğlu, en kısa sürede hastane Başhekimi ile birlikte bir basın toplantısı düzenleyerek alacakları tedbirleri açıklayacaklarını söyledi.

Sabah saatlerinde polikliniğe gelen vatandaşların şikayetlerini de dinleyen Sucuoğlu, daha sonra hastanede yatan hastaları ziyaret ederek, hastaların mevcut sağlık sistemi hakkındaki görüşlerini aldı.

Hastanede yatan eski Sağlık Bakanı Mustafa Erbilen'e de ziyarette bulunan Sucuoğlu, Erbilen ile sohbet ederek tecrübelerini dinledi.