---
id: 01284bodyforumtrcom_a1178cf7
url: file://01284_bodyforumtr_com.md
title: 01284 bodyforumtr com
lang: en
created_at: '2025-12-19T23:38:04.542818'
checksum: 392b23a51ff1157a508c7285fb319d38afc8a503b83d74e9bc3c7569c85a21d6
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 429
  char_count: 3066
  num_chunks: 4
  num_sections: 1
---
= Yağları yakmak istedim küçüldüm =

Yağları yakmak istedim küçüldüm. | BodyForumTR Vücut Geliştirme Forumu Yağları yakmak istedim küçüldüm. Konusu **Beslenme** forumundadır ve thekinger tarafından 5 Mayıs 2014 başlatılmıştır.

Birtakım rahatsızlıklarım nedeniyle tahliller v.s. yaptırdığım için 6 aydır supplement kullanmıyorum ve bundan sonrada kullanmayacağım. Tamamen doğal beslenmeye döndüm. Elbette ki aynı verimi alamıyorum. Protein ağırlıklı beslenmeye devam ediyorum. Şeker sıfır. Karbonhidrat gerektiği kadar alıyorum. Bazen h.sonları kendimi şımartıyorum. Zaten ya birinin doğum günü oluyor ya ev ziyaretleri oluyor pasta, börek, rakı, şarap falan derken biraz kaçırıyorum kantarın topuzunu.

Ama esasen niyetim (bir süre ağırlık çalışamadığım için sadece kardiyoya devam ettim) hazır kardiyovasküler tempoyu artmışken ve kondisyonu toparlamışken bu şekilde devam edip yağ yakımını hızlandırmak ve metabolizmayı ateşlemek istedim. Bazen günde çift işman yaptım: sabahları 50 dk tempolu yürüyüş ve koşu, akşamları 30‑45 dk; bisiklet, yürüyüş bandı ve eliptik karması ile kardiyo; arada ise 1 saat ağırlık idmanı. Ağırlıkları düşürmedim ama artırmadım da. Yani kendimi limitte değil, son sette zorlanacak ağırlıklara göre ayarladım.

Bunu yoğun olarak 1 aydır yapıyorum ve 5 kg verdim. Gönek ve göğüsteki yağlarda ciddi oranda azalma oldu, hatta göbeğin en alt sarkan deri kısmının katlanma izi bile gitti. Kalan sarkık yağlı deri yumuşacık oldu. Bu tempoyu sürdürürsem sanırım yaza kadar abdominellerin en üstündeki görünür hâle gelebilir ya da dümdüz bir karnım olur. Bunlar güzel gelişmeler ancak kaslarımda küçüldü maalesef. Güçte düşüş yok ancak hacimde azalma var, özellikle kollarımda. Tabii ki sadece kardiyo ile değil, aldığım ve yaktığım kalori hesabının etkisi büyük oldu. 2 bin kalorinin altında kalmaya özen gösterdim.

Benim yaşım 39 ve artık benden bir Van Damme vücudu çıkmasını beklemiyorum. Adelelerim dağ gibi olsun gibi beklentimde kalmadı. Her şeyin başının sağlık olduğunu iyi anladım. Bu nedenle fit kalmak için bu sporu yapmaya devam edeceğim. Giydiğim yakışsın, hantal olmayım, hızlı ve genç kalayım ve en önemlisi sağlığım yerinde olsun diye çabalıyorum. Zayıfladıkça daha genç duruyorum zaten; hatta “yüzün kaşık kadar kaldı” diyenler var. Maalesef ektomorf yapıya sahip olduğum için özellikle de yüzümden çok zayflıyorum. Elimden geldiğince kasları diri ve iri tutmaya çalışacağım. Evet, belki Van Damme olmaz benden ama bir Tom Cruise olabilirim.

Bişeyleri başarmak çok önemli ve güzel. Vakit ayırıp okuduğunuz için çok teşekkürler. Herkese sağlıklı ve mutlu sporlar dilerim.

*thekinger, 5 Mayıs 2014*

Güöte azalma olmadığına göre ciddi bir kas kaybı yoktur. Yağlar gittiği için hacimde azalma normal. Bunun dışında aldığınız karbonhidrat miktarı, muhtemelen tuz miktarı da azaldığı için vücudunuz su atmıştır. Aynen devam edin, hiç bozmayın. Yağlar gidip de definasyon belli olmaya başlayınca görsel algınızda da değişim olacak ve şu andan daha hacimsiz olmanıza rağmen daha iri görüneceksiniz. Mesela 37‑38 cm define bir...