---
id: 00561haberaktuelcom_70c9366e
url: file://00561_haberaktuel_com.md
title: 00561 haberaktuel com
lang: en
created_at: '2025-12-19T23:14:09.532705'
checksum: df2ec5268f2e336e397df8838129231221e029d76ae84a4e52816b5eec2ef7f7
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 374
  char_count: 3009
  num_chunks: 4
  num_sections: 2
---
= Giriş =

15.09.2008 / 08:30:00 Başbakanlık Basın Merkezi ve Denizcilik Müsteşarlığı, Bandırma'da batan Ro‑Ro gemisi ile ilgili son bilgileri verdi: 23 kişinin akibeti henüz belli değil. Denizcilik Müsteşarlığında, Bandırma Limanı'ndan ayrıldıktan kısa süre sonra batan Ro‑Ro gemisiyle ilgili oluşturulan kriz merkezinden yapılan açıklamada, olayda 1 kişinin öldüğü, 72 kişinin kurtarıldığı, kurtarılanlardan 24'ünün yaralı, 23 kişinin kayıp olduğu bildirildi.

Denizcilik Müsteşarlığı Müsteşar Yardımcısı Mehmet Solgun başkanlığında oluşturulan kriz merkezi, şu ana kadar olayla ilgili elde edilen bilgileri açıkladı. Gemide 29'u mürettebat olmak üzere toplam 96 kişinin bulunduğu belirtilen açıklamada, kurtarılan 70 kişiden yaralı olan 24'ünün hastanelerde tedavi altına alındığı bildirildi.

> “14 Eylül 2008 tarihinde saat 23.34'de merkezimize ulaşan uydu sinyalinin test edilmesi üzerine otomatik tanımlama sistemi devreye sokularak derhal Sahil Radyo ile görüşülmüş, olayın teyidi alındıktan sonra Sahil Güvenlik Komutanlığı ve mahalli yetkililerle görüşülerek, kurtarma ekipleri olay yerine sevk edilmiştir. Olayın meydana geldiği yer Bandırma Liman mendireğinden 1 mil açığında olan bölgedir. Koordinatlar, Müsteşarlığımız merkezinde dijital olarak alınarak bölgedeki mahalli kurtarma ekiplerine derhal bildirilmiştir. Valilik ve kaymakamlık ekipleri, Sahil Güvenlik Komutanlığı ekipleri ve olayın yakınında bulunan Marmaray N isimli gemi mürettebatı tarafından kurtarma işlemleri sürdürülmüştür.”

Açıklamada, kurtarılanların misafirhanelere yerleştirildiği belirtildi.

== BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA ==

Ro‑Ro gemisinin batmasından sonra Sahil Güvenlik Komutanlığına ait 4 bot ve 1 vinçli arama kurtarma gemisinin, Deniz Kuvvetleri Komutanlığına ait 1 helikopterin, Balıkesir Sivil Savunma Müdürlüğüne ait 2 araç ile 5 dalgıcın ve Bursa Sivil Savunma Müdürlüğüne ait 1 ekibin olay mahallinde çalışmalarını sürdürdüğü bildirildi.

Başbakanlık Basın Merkezinden yapılan açıklamada, şunlar kaydedildi:

> “14 Eylül 2008 günü saat 23.15 sularında Bandırma açıklarında batan gemiyle ilgili arama‑kurtarma çalışmaları diğer kurumlarca koordinasyon halinde yürütülmektedir. 73 kamyon ve 2 otomobilin bulunduğu gemide 100 civarında yolcu olduğu tahmin edilirken, saat 02.00 itibariyle bir vatandaşımızın hayatını kaybettiği, 24 vatandaşımızın da yaralı olduğu tespit edilmiştir. Kaza sonrasında Sahil Güvenlik Komutanlığına ait 4 bot ve 1 vinçli arama kurtarma gemisi, Deniz Kuvvetleri Komutanlığına ait 1 helikopter, Balıkesir Sivil Savunma Müdürlüğüne ait 2 araç ve 5 dalgıç ile Bursa Sivil Savunma Müdürlüğüne ait 1 ekip olay mahallinde çalışmalarını sürdürmektedir. Kaza sonrası Başbakanlık Acil Durum Yönetimi Genel Müdürlüğü tarafından İçişleri Bakanlığı Kriz Merkezi, Balıkesir Valiliği, Bandırma Kaymakamlığı, Balıkesir Emniyet Müdürlüğü ve Genelkurmay Başkanlığı Harekat Merkezi ile görüşülerek, ihtiyaçların temini ve tespiti için başlatılan çalışmalar kesintisiz olarak sürdürülmektedir.”