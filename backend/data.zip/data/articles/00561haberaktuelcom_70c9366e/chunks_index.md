# Chunks Index

| ID    | Section                          | Heading Path                             | Char Range | Preview                                                                                              |
| ----- | -------------------------------- | ---------------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Giriş                            | Giriş                                    | 0-1000     | = Giriş = 15.09.2008 / 08:30:00 Başbakanlık Basın Merkezi ve Denizcilik Müsteşarlığı, Bandırma'da... |
| c0001 | Giriş                            | Giriş                                    | 800-1580   | 14 Eylül 2008 tarihinde saat 23.34'de merkezimize ulaşan uydu sinyalinin test edilmesi üzerine...    |
| c0002 | BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA | Giriş > BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA | 1582-2582  | == BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA == Ro‑Ro gemisinin batmasından sonra Sahil Güvenlik...           |
| c0003 | BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA | Giriş > BAŞBAKANLIK'TAN YAPILAN AÇIKLAMA | 2382-3009  | iştir.                                                                                               |