---
id: 00237istanbulnettr_b0bfcd33
url: file://00237_istanbul_net_tr.md
title: 00237 istanbul net tr
lang: en
created_at: '2025-12-19T23:03:34.565305'
checksum: 78264bbc411c88c3bbf0cfc23b8c3664a58a6a2a0c8e2b327bdbd365d5415faf
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 49
  char_count: 377
  num_chunks: 1
  num_sections: 1
---
Evinizi saracak kurabiye kokuları için İntema Yaşam Akademi'de gerçekleşecek workshop etkinliğinde yerinizi alın.

"Zencefil, tarçın ve portakal... Bu kez lezzetli yılbaşı kurabiyeleri yapmak için İntema Yaşam Akademi'de bir araya geldiler.

Yeni yılın olmazsa olmaz lezzetleri bu kurabiyeleri çayın yanında ikram etmek ve nefis bir servis sunmak istersen atölyemize bekleriz."