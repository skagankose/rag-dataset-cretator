# Dataset: 00237 istanbul net tr

Generated on: 2025-12-19T23:03:43.229533
Total questions: 1

| # | Question                                 | Answer                   | Category | Related_Chunk_IDs |
| - | ---------------------------------------- | ------------------------ | -------- | ----------------- |
| 1 | Workshop etkinliği nerede gerçekleşecek? | İntema Yaşam Akademi'de. | FACTUAL  | c0000             |