# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                               |
| ----- | ------- | ------------ | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-377      | Evinizi saracak kurabiye kokuları için İntema Yaşam Akademi'de gerçekleşecek workshop etkinliğinde... |