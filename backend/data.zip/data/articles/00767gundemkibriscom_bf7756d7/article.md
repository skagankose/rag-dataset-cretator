---
id: 00767gundemkibriscom_bf7756d7
url: file://00767_gundemkibris_com.md
title: 00767 gundemkibris com
lang: en
created_at: '2025-12-19T23:21:01.531103'
checksum: 1d91f054001a405210fdb0e4854035cd4dfc62e9c93a19a6e81263411c4eb116
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 205
  char_count: 1558
  num_chunks: 2
  num_sections: 1
---
= Almanya Lefkoşa Büyükelçiliği Konsolosu Peter Neven DAÜ'yü ziyaret etti =

16:46 11 Şubat 2016  

Almanya Lefkoşa Büyükelçiliği Konsolosu Peter Neven, Doğu Akdeniz Üniversitesi (DAÜ) Rektör Vekili Prof. Dr. Necdet Osam'ı makamında ziyaret etti. Peter Neven gerçekleşen nezaket ziyaretinde DAÜ hakkında geniş bilgiler aldı.  

A+A- DAÜ'yü yakından tanımak isteyen Peter Neven'a DAÜ hakkında geniş bilgiler veren DAÜ Rektör Vekili Prof. Dr. Necdet Osam, ayrıca Almanya ile DAÜ arasında akademik işbirliği konusunda gerekli girişimlere açık olduklarını kaydetti.  

DAÜ'nün 36 yıllık geçmişi ile Kıbrıs adasının en köklü üniversitesi konumunda bulunduğunu ifade eden Prof. Dr. Osam, DAÜ'nün her geçen yıl gelişmeye ve büyümeye devam ettiğini vurguladı. DAÜ'deki öğrenci ve öğretim görevlisi profili, kampüs ve alt yapı olanakları, fakülte ve bölümler hakkında bilgi veren Prof. Dr. Osam, özellikle uluslararası akreditasyona büyük önem verdiklerini de vurgulayarak, birçok bölümün uluslararası akreditasyona sahip olduğunu ve tüm bölümleri akredite etmek amacıyla çalışmaların devam ettiğinin altını çizdi.  

DAÜ'yü ziyaret etmekten duyduğu memnuniyeti dile getiren Peter Neven, DAÜ'nün etkileyici bir eğitim kurumu olduğunu kaydetti. Söz konusu görüşmeye Akademik İşler'den Sorumlu Rektör Yardımcısı Prof. Dr. Ahmet Sözen de katıldı.  

HABERE YORUM KATU  
YARI: Küfür, hakaret, rencide edici cümleler veya imalar, inançlara saldırı içeren, imla kuralları ile yazılmamış, Türkçe karakter kullanılmayan ve büyük harflerle yazılmış yorumlar onaylanmamaktadır.