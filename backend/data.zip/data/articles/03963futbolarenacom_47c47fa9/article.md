---
id: 03963futbolarenacom_47c47fa9
url: file://03963_futbolarena_com.md
title: 03963 futbolarena com
lang: en
created_at: '2025-12-20T00:36:28.545364'
checksum: bb1f2c212e4010c02aead09fa054f9d48b85b11dd99a58560cc72fdc9b2a3662
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 328
  char_count: 2419
  num_chunks: 4
  num_sections: 4
---
= Şok sözler! 'Krasnodar, Fenerbahçe'ye fark atabilir' =

21 Şubat 2017, Salı 18:00

Fenerbahçe - Krasnodar UEFA Avrupa Ligi maçı öncesi iddialı ve bir o kadar gündem yaratacak açıklama geldi. FutbolArena Dış Haberler - UEFA Avrupa Ligi son 32 turunda oynanacak Fenerbahçe - Krasnodar karşılaşması öncesinde heyecan artarken, Rusya'da rakibine 1-0 mağlup olan ve son derece etkisiz futbol ortaya koyan Fenerbahçe'de ligde alınan kötü sonuçların ardından tek hedef turu geçmek olarak belirlendi.

== Fenerbahçe - Krasnodar maçı ne olur, kaç kaç biter? ==

UEFA Avrupa Ligi'nde son 32 tur rövanş maçında 23 Şubat Perşembe günü Ülker Stadı'nda Fenerbahçe ile Krasnodar karşı karşıya gelecek. Zorlu maç öncesinde Krasnodar'ın eski teknik direktörlerinden Sergei Tashuyev ülke basınına yaptığı açıklamalarda iki takımın tur şansını değerlendirdi. İlk maçta Krasnodar'ın beklenmedik derecede rahat bir oyun sergilediğini ve Fenerbahçe'nin kötü bir oyun ortaya koyduğunu belirten Sergei Tashuyev, "Krasnodar'ı bu sezon bu kadar rahat kazanırken eminim kimse görmemiştir. Fenerbahçe hayal kırıklığı yarattı fakat bunda Shalimov'un payı vardı. Çünkü Fenerbahçe'ye karşı gizli bir 3 forvetli sistemle takımını sahaya sürdü. Fenerbahçe bunu tahmin etmiyordu. Van Persie'nin de yokluğunu handikap olarak ekleyebiliriz ama Krasnodar her halükarda Fenerbahçe karşısında üstündü." diye konuştu.

=== SEYİRCİ ÖNEMLİ HANDİKAP ===

Rövanş hakkında da konuşan Sergei Tashuyev, İstanbul'da Türk seyircilerin yarattığı ateşli atmosfere dikkat çekerek bunun zorlayıcı bir faktör olacağından bahsetti. Rus teknik adam, "Krasnodar'ı, İstanbul'da en fazla taraftar zorlayacak. Türk takımlarının Avrupa kupalarında iç sahada ne kadar başarılı olduklarını biliyoruz. Krasnodar eğer bu baskıyı üstünden atabilir ve kendini oyununu ortaya koyabilirse başarılı olur. Ben tek handikap olarak bunu görüyorum." dedi.

=== FARK OLABİLİR ===

Sergei Tashuyev'in yaptığı açıklamalarda en fazla dikkat çeken bölüm ise son söyledikleri oldu. Rus teknik adam, "Krasnodar, İstanbul'da savunma yapmaz. Mutlaka kontrollü oynayacaklardır ama kadrou yapısı savunma oyununa müsait değil. Konovov bu takıma pas futbolu kültürünü yerleştirdi ve Shalimov da bundan vazgeçmedi. Eğer ilk yarım saatte skor Krasnodar lehine olursa Fenerbahçe risk olacak. İşte o zaman hızlı ataklarda etkili olan Krasnodar, farklı bir skorla dahi İstanbul'dan ayrılabilir." diye konuştu.