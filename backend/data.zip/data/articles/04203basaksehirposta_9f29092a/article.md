---
id: 04203basaksehirposta_9f29092a
url: file://04203_basaksehirpostasi_com.md
title: 04203 basaksehirpostasi com
lang: en
created_at: '2025-12-20T00:40:28.599022'
checksum: 6d3d11cc106f3761f88c873ce90a8e52d4ddcfbe6af2e30b46d827c0099cb15a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 85
  char_count: 693
  num_chunks: 1
  num_sections: 1
---
= Başakşehir'de Uyuşturucu Operasyonu =

04 Ağustos 2020, Salı 18:26 / Son Güncelleme : 04 Ağustos 2020, Salı 18:26  

Güngören, Sancaktepe, Şişli, Avcılar, Başakşehir, Kartal ve Sultanbeyli'de düzenlenen eş zamanlı operasyonda 12 kişi gözaltına alındı. Adreslerde yapılan aramalarda, 13 bin 500 lira ile çeşitli tür ve miktarda uyuşturucu ele geçirildi. Emniyetteki işlemlerin ardından adliyeye sevk edilen 12 şüpheliden 5'i tutuklanırken, 4'ü adli kontrol şartıyla, 3'ü ise tutuksuz yargılanmak üzere serbest bırakıldı.  

#Narkotik Suçlarla Mücadele Şube #güngören #sancaktepe #şişli #avcılar #başakşehir #kartol #sultanbeyli #emniyet #uyuşturucuoperasyonu #başakşehirdeuyuşturucuoperasyonu