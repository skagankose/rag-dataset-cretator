# Chunks Index

| ID    | Section                             | Heading Path                        | Char Range | Preview                                                                                              |
| ----- | ----------------------------------- | ----------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Başakşehir'de Uyuşturucu Operasyonu | Başakşehir'de Uyuşturucu Operasyonu | 0-693      | = Başakşehir'de Uyuşturucu Operasyonu = 04 Ağustos 2020, Salı 18:26 / Son Güncelleme : 04 Ağustos... |