# Dataset: 04203 basaksehirpostasi com

Generated on: 2025-12-20T00:40:36.525207
Total questions: 1

| # | Question                                            | Answer          | Category | Related_Chunk_IDs |
| - | --------------------------------------------------- | --------------- | -------- | ----------------- |
| 1 | Adliyeye sevk edilen 12 şüpheliden kaçı tutuklandı? | 5'i tutuklandı. | FACTUAL  | c0000             |