# Chunks Index

| ID    | Section      | Heading Path | Char Range | Preview                                                                                             |
| ----- | ------------ | ------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Gezi Rehberi | Gezi Rehberi | 32-1032    | == Gezi Rehberi == Hayallerinizdeki tatil doğayı "'en doğal haliyle'" keşfetmekse, Tanzanya size... |
| c0001 | Gezi Rehberi | Gezi Rehberi | 832-1340   | ğrafyasıyla da ziyaretçilerin nefesini kesmeyi başarıyor.                                           |