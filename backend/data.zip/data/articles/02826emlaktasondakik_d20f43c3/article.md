---
id: 02826emlaktasondakik_d20f43c3
url: file://02826_emlaktasondakika_com.md
title: 02826 emlaktasondakika com
lang: en
created_at: '2025-12-20T00:17:31.552224'
checksum: db5954fd1e28b97789a4952d0ddf643972b460ba4f1cbdb4994a0ecf7bb88c5b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 137
  char_count: 1083
  num_chunks: 2
  num_sections: 1
---
= Ilısu Barajı'nda elektrik üretimi başladı =

*Yazar: Ali Asatekin*  
*19.05.2020 19:23*  

Dicle Nehri üzerinde inşa edilen Ilısu Barajı'nın ilk türbini hizmete girdi. Türkiye'nin en büyük elektrik üretimi projelerinden biri olan Ilısu Barajı'nın altı türbininden ilki, 19 Mayıs Atatürk'ü Anma, Gençlik ve Spor Bayramı'nda Cumhurbaşkanı Recep Tayyip Erdoğan'ın video konferansla katıldığı törenle hizmete alındı.

Törende konuşan Cumhurbaşkanı Erdoğan, "Ilısu Barajı'nın ülkemize, milletimize hayırlı olmasını diliyorum. 2008'den beri kredisinden inşasına her aşamasında pek çok engellemeyle karşılaştığımız bu eseri kararlılığımız sayesinde ülkemize kazandırdık. Karşımızda laf değil, eser üretme siyasetimizin bir örneği duruyor. Bu eser, Türkiye'yi yurt dışında şikayet edenlere en iyi cevaptır. Ilısu Barajı'ndan esecek barış, kardeşlik, refah ve huzur rüzgarı asırlar boyunca bu topraklarda dalga dalga kendini hissettirecektir. Hasankeyf başta olmak üzere tüm tarihi ve kültüsel varlıklar korunmuştur. Sadece bu çalışmalar için 200 milyon liralık kaynak kullanılmıştır" dedi.