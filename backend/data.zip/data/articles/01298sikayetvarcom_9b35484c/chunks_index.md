# Chunks Index

| ID    | Section                                | Heading Path                           | Char Range | Preview                                       |
| ----- | -------------------------------------- | -------------------------------------- | ---------- | --------------------------------------------- |
| c0000 | Samsung Üretim Hatasını Kabul Etmiyor! | Samsung Üretim Hatasını Kabul Etmiyor! | 0-1000     | = Samsung Üretim Hatasını Kabul Etmiyor!      |
| c0001 | Samsung Üretim Hatasını Kabul Etmiyor! | Samsung Üretim Hatasını Kabul Etmiyor! | 800-1800   | satış sonrası destek = SIFIR Hatta eksilerde. |
| c0002 | Samsung Üretim Hatasını Kabul Etmiyor! | Samsung Üretim Hatasını Kabul Etmiyor! | 1600-2303  | LI SAMSUNG TELEFONUMU kullanmaktayım!         |