---
id: 01298sikayetvarcom_9b35484c
url: file://01298_sikayetvar_com.md
title: 01298 sikayetvar com
lang: en
created_at: '2025-12-19T23:38:33.537169'
checksum: 0dbbc2c8198a51ede95369d752e4a327732384c6ff70791e2fee3a2648f42d1b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 310
  char_count: 2303
  num_chunks: 3
  num_sections: 1
---
= Samsung Üretim Hatasını Kabul Etmiyor! =

Ekteki fotoğraf Samsung'un bana sattığı üretim hatalı telefondan çekilmiştir. Sağ üst kısımdaki siyah beneklere bakın. Ekran hataları ve diğer birçok hataya sebep olan bir sürü problem telefonumda mevcut. Güzelce açıklamama rağmen; Samsung, üretim hatalı telefonu değiştirmedi. Üstelik beni yetkili servis müdürü kovdu ve hiçbir Samsung tarafı da asla yardım etmedi! İşte Samsung'a güvenen bir müşterinin düştüğü durum bu.

Satış sonrası desteklerinin sıfır olduğunu ispatlamam üzerine call center telefonu suratıma da kapatarak kalitesini gösterdi. Artık kim kimden ne hakkı talep edebilir, bana kim yardımcı olabilir meçhul?

**Fatih – 25 Kasım 2013**  
SAMSUNG = SIFIR MÜŞTERİ MEMNUNİYETİ SIFIR SATIŞ SONRASI DESTEK!

**Fatih – 30 Ekim 2013**  
Samsung satış sonrası destek = SIFIR Hatta eksilerde. Çünkü garantisiz mal satsalar bari bu kadar zamanımıza mal olmaz, sinirlerimizi bozmaz ve telefonlarımızı da daha da kötüleştirmezlerdi! Siteye vermiş olduğum tüm bilgiler doğrudur ve daha önce onlarca kez Samsung'un kapısına gittiğim iletişim bilgileriyle aynıdır. Bir kere çaldırdılar, önemli bir toplantıdaydım. Zaten telefon görüşmesini yaptığımız onlarca kez zaman kaybından başka hiçbir şey olmamıştı! Ancak boş boş standart mesajları yazarlar. Hiçbir aksiyon yok.

Samsung almadan önce çok düşünün, alternatiflerini araştırın. Kapılarında süründürüyorlar, Yetkili Servisleri müşterileri kovuyor ve iftira bile atıyor da bu SAMSUNG denen marka hiçbir işlemde bile bulunmuyor! Hala bana yamadıkları ve üzerinde HİÇBİR İŞLEM YAPMADIKLARI, İMALAT HATALI SAMSUNG TELEFONUMU kullanmaktayım! Ekranda bulutlanma var, fotoğraflarda nokta nokta lekeler çıkıyor... Şarj sorunu ayrı, kapanıp açılmalar, donmalar... Hepsini saymama imkan yok! Tüm Samsung müşteri ve muhtemel mülterilerinin bilgisine!

**Samsung Telefon Temsilcisi – 27 Ekim 2013 – Fatih**  
Her zaman söylediğim gibi: Samsung Satış Sonrası Destek = 0  

**Fatih – 23 Ekim 2013**  
Daha önce yirmi bin kere İNCELEME BAŞLATILMIŞTIR hikayelerini anlattılar. Hiçbir şey yaptıkları yok! YARDIM ETMEDİKLERİNİ defalarca açık açık bas bas bağardılar!

Markalar: LG Mobile, Vestel Venüs, iPhone, Huawei, Reeder, Sony Mobile, Lenovo‑Motorola Akıllı Telefonlar, Asus Cep Telefonu, General Mobile, Casper Via