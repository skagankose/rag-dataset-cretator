---
id: 00950yerliyurtcom_6b6b971d
url: file://00950_yerliyurt_com.md
title: 00950 yerliyurt com
lang: en
created_at: '2025-12-19T23:27:08.537448'
checksum: 6c7529e783fbfe91b4c03862b57a504594974f351785db89830e215dbd812644
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 293
  char_count: 2084
  num_chunks: 3
  num_sections: 1
---
= Çöküş devam ediyor! Bitcoin 10 günde yarı yarıya değer kaybetti =

== 06 Şubat 2018 - 21:17 ==

Kripto para birimlerinin piyasa hacmi en büyük olanı Bitcoin 7 bin doların altına geriledi. Bir günde yüzde 24,60 değer kaybeden Bitcoin, son 10 günde neredeyse yarı yarıya değer kaybetti. Toplam 1.514 adet sanal para biriminin oluşturduğu piyasa hacmi son 24 saatte yüzde 36,7’lik bir düşüş yaşadı.  

Piyasayı belirleyen Bitcoin'deki düşüş, ABD hisse senetlerindeki çöküşün ardından devam ediyor. Aralıkta 20 bin dolar seviyelerini görüp yatırımcısını sevindiren Bitcoin, 6 Şubat saat 10:20 itibarıyla 6 177 dolar seviyelerinden işlem görüyor. ABD ve Birleşik Krallık merkezli bankalarından getirilen “düzenleme” ve “kısıtlama” haberlerinin ardından kripto para piyasasındaki düşüş devam ediyor.  

ABD'li dev bankacılık kuruluşlarından JPMorgan Chase, Bank of America ve Citigroup, cuma günü yaptıkları açıklamada kripto paralardaki volatilite ve risk nedeniyle müşterilerinin kredi kartlarıyla kripto para alımına izin vermeyeceklerini duyurmuştu.  

Kripto para piyasa hacmi son 24 saatte 104 milyar dolara karşılık gelen yüzde 36,7’lik bir düşüşle 283 milyar 304 milyon dolara geriledi. Bitcoin, 104 milyar 518 milyon dolarlık piyasa hacmiyle toplam piyasa hacminin yüzde 36,9’unu oluştururken, kripto para piyasasındaki 24 saatlik işlem hacmi ise 28 milyar 201 milyon dolar olarak hesaplandı.  

Her bir blok üzerinde yüksek işlem gerektiren bir hash algoritması uygulanarak, belli bir sıfır sayısıyla başlayan ifadenin bulunması istenmektedir. Yaklaşık 10 dakikada bir gerçekleşen bu işlemi gerçekleştiren ilk kullanıcıya sıfırdan 50 BTC (şu anda 25 BTC) ödül olarak verilir. Böylece Bitcoin’ler emisyona sürülmüş olur.  

Her bir blok, kendisinden önce gelen son bloğun da hash ifadesini içerir. Böylece bozulması oldukça zor (%51 saldırısı hariç) bir blok zinciri oluşur. Bu zincirin amacı çifte harcamayı önlemek ve gönderimleri kayıt altında tutmaktır. Verilen ödül miktarı her 210 bin blokta bir (yaklaşık 4 yılda bir) yarıya düşürülür (50, 25, 12,5, …).  

*Kaynak: sozcu*