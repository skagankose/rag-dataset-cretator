# Chunks Index

| ID    | Section               | Heading Path          | Char Range | Preview                                                                                           |
| ----- | --------------------- | --------------------- | ---------- | ------------------------------------------------------------------------------------------------- |
| c0000 | 06 Şubat 2018 - 21:17 | 06 Şubat 2018 - 21:17 | 69-1069    | == 06 Şubat 2018 - 21:17 == Kripto para birimlerinin piyasa hacmi en büyük olanı Bitcoin 7 bin... |
| c0001 | 06 Şubat 2018 - 21:17 | 06 Şubat 2018 - 21:17 | 869-1869   | ve Citigroup, cuma günü yaptıkları açıklamada kripto paralardaki volatilite ve risk nedeniyle...  |
| c0002 | 06 Şubat 2018 - 21:17 | 06 Şubat 2018 - 21:17 | 1669-2084  | rak verilir.                                                                                      |