# Chunks Index

| ID    | Section                                | Heading Path                           | Char Range | Preview                                                                                         |
| ----- | -------------------------------------- | -------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | Bursa İnegöl'e Millet Bahçesi müjdesi! | Bursa İnegöl'e Millet Bahçesi müjdesi! | 0-1000     | = Bursa İnegöl'e Millet Bahçesi müjdesi!                                                        |
| c0001 | Bursa İnegöl'e Millet Bahçesi müjdesi! | Bursa İnegöl'e Millet Bahçesi müjdesi! | 800-1800   | dolayı teşekkür etti.                                                                           |
| c0002 | Bursa İnegöl'e Millet Bahçesi müjdesi! | Bursa İnegöl'e Millet Bahçesi müjdesi! | 1600-2258  | tmesi için fikrimizi Sayın Cumhurbaşkanımızla paylaştık, tabi konu Bursa ve İnegöl olunca ne... |