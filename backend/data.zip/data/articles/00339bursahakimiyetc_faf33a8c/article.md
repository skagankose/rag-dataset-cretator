---
id: 00339bursahakimiyetc_faf33a8c
url: file://00339_bursahakimiyet_com_tr.md
title: 00339 bursahakimiyet com tr
lang: en
created_at: '2025-12-19T23:06:54.530631'
checksum: 2c1be7a82a8d137cf0a2645c10379d1469c78b246a565f120bd73be34c09fa1b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 293
  char_count: 2258
  num_chunks: 3
  num_sections: 1
---
= Bursa İnegöl'e Millet Bahçesi müjdesi! =

Bursa İnegöl'ü marka kent yapmak için Ankara'da yoğun mesai harcayan AK Parti Bursa Milletvekili Vildan Yılmaz Gürel, AK Parti iktidarının prestij çalışmalarından biri olan Millet Bahçesi'nin İnegöl'e kurulacağını söyledi.

**BURSA, 26 Kasım 2020 Perşembe, 13:31**  
Cumhurbaşkanından tam not alan projeler için kolları sıvayan Vekil Gürel, İnegöl'e kazandırmak istediği projeler için neredeyse her hafta ilgili bakanlıklarla görüşmeler yaptı. Çevre ve Şehircilik Bakanı Murat Kurum, Tarım ve Orman Bakanı Bekir Pakdemirli ve Bilim ve Sanayi Bakanı Mustafa Varank ile düzenli görüşmeler ve istişarelerde bulunan Gürel, AK Parti Grup Toplantısı sonrası Cumhurbaşkanı Recep Tayyip Erdoğan'a gelinen son aşama ile ilgili bilgi verdi, yakın ilgi ve alakasından dolayı teşekkür etti.

> Konuyla alakalı bir açıklama yapan Gürel:  
> “İnegöl için kullandığım ‘kabına sığmayan kent’ tabir vardı. Nitekim bu ruhu yaşatacak büyük projeleri hayata geçirmek istedik. Şahsen İnegöllü olmam hasebiyle İnegöl'ün ihtiyaç ve taleplerini bilerek, gözeterek, hayallerimizi de büyük düşündük. İnegöl'lü vatandaşlarımızın talep ve beklentileri haklı olarak yüksek ve daha fazlasını da gerçekten hak ediyor. Bu noktada sunduğumuz projelerden biri olan Millet Bahçesi projesi gündeme geldi. Malum Millet Bahçesi, uygulandığı her yerin çehresini baştan aşağı değiştiren ve ülkemizin en saygın projelerinden. Cumhurbaşkanımızın himayesinde ilgili bakanlıklarımızın ve belediyelerimizin Millet Bahçeleri halkımızın büyük teveccühünü gördü. Bu noktada İnegöl'ün de bundan istifade etmesi için fikrimizi Sayın Cumhurbaşkanımızla paylaştık, tabi konu Bursa ve İnegöl olunca ne düşündüğünü kestirmek zor değil. Bir an önce bu çalışmaya başlayalım, desteğini aldıktan sonra gerekli çalışmaları yaptık. Sağolsun bakanlarımız da bu konuyu yakından takip ettiler, yasal süreçler ve teknik çalışmaları tamamlayıp Sayın Cumhurbaşkanımıza bilgi verdik. Artık İnegöl'ün prestij projesi için gün sayıyoruz diyebiliriz. Bundan sonra da inşallah aynı gayret ve inançla İnegöl için Sayın Cumhurbaşkanımıza sunumunu gerçekleştirdiğimiz diğer projelerin süreçlerini tamamlayıp, hayat bulmaları İnegöl'ümüzün hizmetine sunmak için var gücümüzle çalışacağız.”