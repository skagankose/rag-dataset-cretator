---
id: 04277ayvalikzeytinha_77947967
url: file://04277_ayvalikzeytinhasatgunleri_com.md
title: 04277 ayvalikzeytinhasatgunleri com
lang: en
created_at: '2025-12-20T00:41:42.564891'
checksum: 4041327e31d102f80d29c56316d25d4021dc78563f38f6ca78a98f7222a0c3c6
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 412
  char_count: 3026
  num_chunks: 4
  num_sections: 1
---
= ZEYTİN VE ZEYTİNYAĞI arşivleri - Sayfa 2 / 4 - Ayvalık Zeytin Hasat Günleri =

Önce siyah, parlak, küçük çekirdekli ve sağlam zeytinler seçilir. Kirlilik durumuna göre birkaç kez yukanır. Susuz olarak pet şişeye doldurulur. Zeytini 5 kilodan hesaplarsak üzerine yarımşar su bardağı kaya tuzu, zeytinyağı ve toz şeker eklenir. Bunlar harmanlanıp karışmaları sağlanır. …Ve sonra 2 ay boyunca pet şişe günde birkaç kez yerde yuvarlanır. Bu sayede karışım homojen […]  

Eğer yeni dikilirse, zeytin ağacı dikim tarihinden 10 yıl sonra ürün verir. Yıllık 50 kilo verime ancak 20 yıl sonra ulaşır. Yağlık zeytinin 5 kilosundan 1 kilo zeytinyağı çıkar. Zeytincilik, Ayvalıkta yapılan en yaygın tarımsal faaliyet. Yörede doğal yayılım gösteren zeytin ağaçlarının tümü yüzyıllarca önce "delice" denilen yabani zeytin ağacından aşılanmış. Bu nedenle çevre koşullarına […]  

Zeytin toplama şekilleri binlerce yıldan bu yana neredeyse hiç değişmedi. Elle toplandı ya da silkme yöntemi kullanıldı. Bir de, yere düşmüş zeytinlerin toplanması var. Hasatta genel tercih silkmeden yana. Elle toplamada sağma veya taraklama yöntemi, yerden toplamada ise merdane veya fırça kullanılır. Günümüzde zeytin hasadında makineden de (sarsma ve yerdeki meyveleri emici ekipmanlarla toplama) yararlanılıyor. […]  

Ayvalık yöresinde tahminen 2.5 milyon zeytin ağacı var. Bu ağaçlardaki "mahsulü" toplamak için kente her yıl binlerce tayfa gelir. Ailece çalışan bu tayfaları kahyalar bulup getirir. Damcısı, traktörcüsü, sepetçisiyle… zeytin tarlaları üç ay boyunca hareketlenir. Tayfalar sabah erken saatlerde işbaşı yapar. Günbatımına kadar her biri 100 kilo zeytin toplar. Zeytin hasadı Kasım ayında başlar, bir […]  

Atatürk, Yalova Millet Çiftliği'ni 1929 yılında ziyaret etti ve yörenin tek geçim kaynağı olan zeytinciliğin geliştirilmesi talimatını verdi. Yine, Atatürk'ün emriyle İtalya'dan getirtilen Petrini adlı bir teknik eleman Bursa ilçelerinde zeytin köylüsü için kurslar açtı. Modern zeytinciliği öğrenmeleri için Nizamettin Turgay, Ferruh Barlas, Kadri Akçal ve Adil Aytuna Atatürk tarafından iki yıllığına İtalya'ya gönderildi. Dönünce Tarım […]  

"Ayvalık'ta ne yana gidersek gidelim, görkemli ağaçlar yalnız bırakmıyor bizleri. Zeytin denizinde yüzer gibiyiz. Bu ağaçlar muhteşem gövdeleri, dört mevsim dökülmeyen gümüşî yaprakları, heybetli dalları ile insanı kendine hayran bırakıyor. İnsan durup durup bakmak; bir daha, bir daha seyretmek istiyor. Henüz tarihin bile hesaplayamadığı zamanlardan gelmeleri de cabası. Masallarda, tüm din kitaplarında, bilinen bütün ritüellerde […]  

Zeytin ağacı kendini yeniler ama yavaş büyür, zahmet ister. Ömrü uzundur. Boyu 10 metreye kadar çıkabilir. Kalkerli, çakıllı, taşlı ve kurak toprakları sever. Yaz sıcağından yakınmaz, ılıman kışı tercih eder. Işıktan hoşlanır, güneşle dosttur. 15 derecenin üstünde, keyfi yerindedir. Mayıs ortasında çiçek açmaya başlar, Haziran başlarında tomurcuğa dönüşür, Temmuz'da zeytinler tomurcuktan çıkıp yeşil zeytin olarak […]  

"Bizi gemiye yükledi