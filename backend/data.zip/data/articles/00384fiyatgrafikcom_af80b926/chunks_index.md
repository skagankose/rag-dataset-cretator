# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                                |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Lead    | Lead         | 0-1000     | Oryantal yaparak, oryantalin bazı özel hareketlerini icra ederek yağ toplanmasının olduğu...           |
| c0001 | Lead    | Lead         | 800-1800   | rumda da vücudun diğer bölgesindeki kaslar görece atıl durumda iken; normalde atıl durumda olan bel... |
| c0002 | Lead    | Lead         | 1600-2600  | Diğer dans tipleri zayıflamak amacıyla kullanıldıkları için eğlenceli olma vasfından...                |
| c0003 | Lead    | Lead         | 2400-3009  | kurtulurken derinin sarkmaması, kaslı bir vücuda sahip olmak gibi ikinci faydalar da söz konusudur.    |