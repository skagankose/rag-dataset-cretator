# Chunks Index

| ID    | Section               | Heading Path          | Char Range | Preview                                                         |
| ----- | --------------------- | --------------------- | ---------- | --------------------------------------------------------------- |
| c0000 | Yatırım kadın işiymiş | Yatırım kadın işiymiş | 0-537      | = Yatırım kadın işiymiş = Borsada kadınlar daha akıllı oynuyor. |