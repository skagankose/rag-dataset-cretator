---
id: 01958thcodexblogspot_b90a3380
url: file://01958_thcodex_blogspot_com.md
title: 01958 thcodex blogspot com
lang: en
created_at: '2025-12-20T00:00:33.532665'
checksum: f8836069a38984eea0d59b48de335d14115bb403fe273629cfcd9ca1d464bf8f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 427
  char_count: 3006
  num_chunks: 4
  num_sections: 1
---
= the Codex: Evrenin Ötesi - Beth Revis Kitap: Evrenin Ötesi Yayıncı: Olimpos Tür: Bilim Kurgu, Distopya, Genç Yetişkin Goodreads | Okuoku | Hepsiburada =

Amy'nin genetik uzmanı annesi ve savaş analizi uzmanı babası yeni bir gezegende insanlığın ilk tohumlarını atmak ve yaşam şartlarını uygun hale getirebilmek üzere Finansal Kaynak Borsası tarafından işe alınır. Yeni gezegene varmak 300 yıl süreceği ve Amy sadece on yedi yaşında olduğu için özel bir izin ile o da bu yolculukta ailesine katılır. Kendilerinin de aralarında bulunduğu 100 kişilik bilim insanı ve savaş uzmanı dondurularak geminin kargo bölümüne 300 yıl sonra yeni gezegene iniş yapıldığında uyandırılmak üzere yerleştirilir.

Ama yüzlerce yıl sürecek olan bu yolculuk için evet demeden önce Amy'nin 50 yıl erken uyandırılacağından haberi yoktu... Üstelik kendi kurallarıyla yaşayan cesur yeni bir dünyaya gözlerini açmayı hiç ummamıştı. Amy uyandırılışının bir teknik arıza olmadığını anladığı andan itibaren onun neredeyse ölümüne sebep olan kişiyi bulmak için zamana karşı bir yarışa girer. Çünkü donma haznesinin fişi çekilmiştir ve şüpheliler listesindeki isimler ise sadece birkaç bin kişilik gemi sakinlerine aittir.

Gemide birisi donma haznelerinin fişlerini çekip kaçıyor ve vaktinde çözüldükleri farkedilmeyen kurbanlar dondurucu sıvıda boğuluyor. Eğer Amy hemen bir şeyler yapmazsa ailesi bir sonraki kurbanlar olabilir. Ama şüpheli listesindeki isimlerden biri Amy için farklı anlamlar ifade ediyor: genç, asi ve zeki Çırak, geminin gelecekteki lideri ve hazırlıksız yakalandığı bir aşk.

Beni en çok etkileyen kitaplardan birini sorsalar sadece ilk 17 sayfasına bakarak Evrenin Ötesi derdim. Bugüne kadar 5 puan verdiğim kitaplar içinde bile bu kadar ilginç bir başlangıç hatırlamıyorum. Kitap 300 yıl sonra tekrar uyandırılmak üzere dondurulacak Amy adlı karakterin dondurulma sırasında yaşadıklarını bize anlatışıyla başlıyor. Yazar öyle etkileyici yazmış ki okurken tüylerim diken diken oldu desem yalan olmaz. Kitabın etkileyici ilk bölümünü okumak için buraya tıkla. Kitap baştan sona çok güzel kurgulanmış. Karakterler, geminin tasarımı, gemideki insanların yaşayış şekli, bilimin nasıl geliştiği, sezon olayı… Her şey çok yaratıcıydı. Ah özellikle de sezon olayı beni çok rahatsız etti. Yazarın anlatımı hem çok akıcı hem de merak uyandırıcıydı.

İlk 150 sayfadan sonra hep yeni bir şeyler öğreniyoruz. Ama her öğrendiğimiz bir öncekini yalanlar nitelikte oluyor. Bu bana çok ilginç geldi. Ayrıca yazar farklı bir teknik uygulamış ve iki karakterin birden bakış açısıyla aktarmış olayları (Amy ve Çırak). Genelde tek bir karakterin (özellikle bu bir kız olur) gözünden aktarılır olaylar ve "acaba erkek bu konuda ne düşünüyor?" diye merak ederiz. Bunda merak etmemize gerek kalmıyor çünkü hemen sonraki bölümde onun gözünden hikayeye kaldığı yerden devam ediyoruz.

Karakterleri çok beğendim. Özellikle de Amy'yi. Güçlü, zeki ama mükemmel de değil. Yazar öyle güzel aktarmış ki duygularını ben okurken hissedebildim.