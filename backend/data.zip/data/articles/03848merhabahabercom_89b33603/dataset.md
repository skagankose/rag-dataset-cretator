# Dataset: 03848 merhabahaber com

Generated on: 2025-12-20T00:34:41.389186
Total questions: 1

| # | Question                                              | Answer                         | Category | Related_Chunk_IDs |
| - | ----------------------------------------------------- | ------------------------------ | -------- | ----------------- |
| 1 | Patlamaya neden olan araçtaki bomba nasıl patlatıldı? | Uzaktan kumandayla patlatıldı. | FACTUAL  | c0000             |