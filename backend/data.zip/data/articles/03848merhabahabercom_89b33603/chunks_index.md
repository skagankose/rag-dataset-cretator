# Chunks Index

| ID    | Section                             | Heading Path                        | Char Range | Preview                                                                      |
| ----- | ----------------------------------- | ----------------------------------- | ---------- | ---------------------------------------------------------------------------- |
| c0000 | Saldırıdan 15 dakikayla kurtuldular | Saldırıdan 15 dakikayla kurtuldular | 0-688      | = Saldırıdan 15 dakikayla kurtuldular = 09:37 02 Kasım 2012 – İskenderun 39. |