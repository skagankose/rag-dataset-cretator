---
id: 03848merhabahabercom_89b33603
url: file://03848_merhabahaber_com.md
title: 03848 merhabahaber com
lang: en
created_at: '2025-12-20T00:34:33.555452'
checksum: 67de32826b20ad9de5faddf31428f01cb572bf152f42dbbbaa34a0cb12b40700
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 85
  char_count: 688
  num_chunks: 1
  num_sections: 1
---
= Saldırıdan 15 dakikayla kurtuldular =

09:37 02 Kasım 2012 – İskenderun 39. Mekanize Piyade Tugay Komutanlığı'na bağlı Şehit Ahmet Tor Kışlası'nın karşısındaki akaryakıt istasyonunun önünde bulunan araçta meydana gelen patlamanın, askeri personelin... Daha önce alınan bir istihbarat nedeniyle askeri personelin çıkış saatlerinin değiştirildiğinin, bugün de 15 dakika önce servis araçlarının kışladan çıktığının hatırlatılması üzerine Vali Lekesiz, “Askeri yetkililer, zaman zaman çıkış saatlerini bu şekilde değiştiriyorlar. Yetkililer doğru karar almışlar” dedi. İçinde bomba bulunan aracın uzaktan kumandayla patlatıldığı, olayla ilgili incelemenin çok yönlü sürdürüldüğü bildirildi.