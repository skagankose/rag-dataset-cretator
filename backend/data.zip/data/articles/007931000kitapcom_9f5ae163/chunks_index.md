# Chunks Index

| ID    | Section       | Heading Path  | Char Range | Preview                                                                            |
| ----- | ------------- | ------------- | ---------- | ---------------------------------------------------------------------------------- |
| c0000 | Kur'an Nedir? | Kur'an Nedir? | 0-1000     | = Kur'an Nedir?                                                                    |
| c0001 | Kur'an Nedir? | Kur'an Nedir? | 800-1127   | tediğini ve neleri emrettiğini okuyuculara anlaşılır bir şekilde vermeye çalışmış. |