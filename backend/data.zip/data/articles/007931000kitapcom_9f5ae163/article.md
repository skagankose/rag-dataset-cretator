---
id: 007931000kitapcom_9f5ae163
url: file://00793_1000kitap_com.md
title: 00793 1000kitap com
lang: en
created_at: '2025-12-19T23:21:53.537917'
checksum: d9768865a20c375067d33db9854cff8c00d871b8a41445e5e6fe71acf7c1bb23
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 125
  char_count: 1127
  num_chunks: 2
  num_sections: 1
---
= Kur'an Nedir? =

İşlemeli mahfazalar içine koyup, odalarımızın duvarlarına astığımız Kurân-ı Kerîm, anlaşılmayı/hayatı anlamlandırmayı bekliyor.

Otomobillerin içini, işyerlerinin duvarlarını, camilerin kubbelerini süsleyen âyet-i kerîmeler, anlaşılmayı/hayatı anlamlandırmayı bekliyor.

O Kitap, insanlığın adresine gönderilen bir mektup. Elde edemedikleriyle, elde ettikleri arasında sıkışan insan, hayata anlam veremeyişinin bedelini ağır ödüyor.

Murad Kur'an Nedir?'i inceledi. Ahmet Nedim Serinsu... Derslerine hep farklı bir heyecanla girdiğim değerli hocam.

Bütün derslerinde dikkat çektiği; insanın hayatını anlamlandırması gerekliliğini bu kitabında hülasa olarak anlatmış.

Amaçsız insan topluluklarının ne kadar tehlikeli olabileceklerinden tutunda, Allah'ın insandan ne gibi şeyler istediğini ve neleri emrettiğini okuyuculara anlaşılır bir şekilde vermeye çalışmış.

Kuran'a modern bir yaklaşım olarak değerlendirebileceğimiz bu kitap bizim düşüncelerimizi, bakış açılarımızı ve olayları anlamlandırmalarımızı yeniden şekillendirebilecek, dine ve hayata bakışımızda bizlere yeni bir perspektif kazandıracaktır.