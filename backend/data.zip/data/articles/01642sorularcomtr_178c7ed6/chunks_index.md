# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                                |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Soru 1  | Soru 1       | 52-466     | == Soru 1 == **Aşağıdakilerden hangisi pozitif ölçek ekonomilerini ortaya çıkaran nedenlerden biri...  |
| c0001 | Soru 2  | Soru 2       | 466-1466   | == Soru 2 == **Her iki girdinin marjinal fiziki ürününün …………… olduğu ve eş ürün eğrisinin eğiminin... |
| c0002 | Soru 2  | Soru 2       | 1266-1538  | min ekonomik bölgesi denir.                                                                            |
| c0003 | Soru 3  | Soru 3       | 1540-2329  | == Soru 3 == **İnsanlar sahip oldukları kaynakları satarak ya da kiralayarak gelir elde ederler.       |
| c0004 | Soru 4  | Soru 4       | 2329-2539  | == Soru 4 == **Bir değişkenin değeri model içinde belirleniyorsa bu değişkene ne ad verilir?** - A.    |
| c0005 | Soru 5  | Soru 5       | 2539-2762  | == Soru 5 == **Bir şeyi seçtiğimizde vazgeçtiğimiz alternatiflerin değerini ifade eden kavram...       |
| c0006 | Soru 6  | Soru 6       | 2762-2862  | == Soru 6 == **Üretim miktarı artıkça maliyeti minimize eden miktarı azalan girdiye ne ad verilir?**   |