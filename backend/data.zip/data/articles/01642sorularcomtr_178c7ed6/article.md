---
id: 01642sorularcomtr_178c7ed6
url: file://01642_sorular_com_tr.md
title: 01642 sorular com tr
lang: en
created_at: '2025-12-19T23:50:01.539303'
checksum: 0932e712e0b9d79a17a1a70ee48998e5417932aa0a603a541f66a1568677c9c7
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 408
  char_count: 2862
  num_chunks: 7
  num_sections: 6
---
= Mikro İktisat Deneme Ara Sınavları - Deneme 26 =

== Soru 1 ==
**Aşağıdakilerden hangisi pozitif ölçek ekonomilerini ortaya çıkaran nedenlerden biri değildir?**  

- B. Girdi bileşenlerinde esneklik  
- C. Büyük ölçekte girdi alımı nedeniyle yapılan iskontolar  
- D. Bazı girdilerin bölünemiyor olması  
- E. Artan iş yükü  

**Doğru Cevap:** "E" – Artan iş yükü, etkinliği ve verimliliği düşürdüğü için pozitif değil negatif ölçek ekonomisine sebep olmaktadır.

== Soru 2 ==
**Her iki girdinin marjinal fiziki ürününün …………… olduğu ve eş ürün eğrisinin eğiminin …………… olduğu bölgeye üretimin ekonomik bölgesi denir. Yukarıdaki ifadeyi doğru kılacak biçimde boş bırakılan yerlere sırasıyla aşağıdakilerden hangisi gelmelidir?**  

- A. çok; az  
- B. az; çok  
- C. negatif; pozitif  
- D. negatif; negatif  
- E. pozitif; negatif  

**Doğru Cevap:** "E" – pozitif; negatif  

Eş ürün eğrilerine ait özelliklerden bir tanesi, eğrilerin negatif eğimli olmasıdır. Bu eğimli aralıkta emek girdisini artırdığımızda aynı üretim düzeyinde kalabilmek için sermaye girdisini azaltmak zorundayız. Bu bölge “üretimin ekonomik bölgesi” olarak adlandırılır.  
Her iki girdinin marjinal fiziki ürününün pozitif olduğu ve eş ürün eğrisinin eğiminin negatif olduğu bölgeye üretimin ekonomik bölgesi denir.  
Pozitif eğimli eş ürün eğrileri ise “ekonomik olmayan bölge” olarak kabul edilir.  
Girdilerden birinin marjinal fiziki ürününün negatif olduğu ve eş ürün eğrisinin eğiminin pozitif olduğu bölge ise “ekonomik olmayan bölge” olarak tanımlanır.

== Soru 3 ==
**İnsanlar sahip oldukları kaynakları satarak ya da kiralayarak gelir elde ederler. Aşağıda verilen kaynak – gelir eşleşmelerinden hangisi doğrudur?**  

- A. Emek – kar  
- B. Sermaye – kar  
- C. Emek – rant  
- D. Girişimci – rant  
- E. Sermaye – faiz  

**Doğru Cevap:** "E" – Sermaye – faiz  

İnsanlar gelirlerini, sahip oldukları kaynakları satarak ya da kiralayarak elde ederler. Topraklarıyla elde ettikleri gelire **rant**, emekleriyle elde ettikleri gelire **ücret**, sermayeleriyle elde ettikleri gelire **faiz**, girişimcilerin gelirine ise **kâr** denir. Kaynaklarını satarak veya kiraya vererek elde ettikleri gelirle mal ve hizmet alabilirler. Üreticiler de sattıkları mal ve hizmetlerin karşılığı olarak bu gelirle üretim faktörlerinin gelirlerini öderler.

== Soru 4 ==
**Bir değişkenin değeri model içinde belirleniyorsa bu değişkene ne ad verilir?**  

- A. Amaç değişkeni  
- B. Kısıt değişkeni  
- C. Marjinal değişken  

**Doğru Cevap:** "C" – İçsel değişken  

== Soru 5 ==
**Bir şeyi seçtiğimizde vazgeçtiğimiz alternatiflerin değerini ifade eden kavram aşağıdakilerden hangisidir?**  

- B. Denge analizi  
- C. Ortalama maliyeti  
- D. Marjinal çıkarım  
- E. Ekonomik etkinlik  

== Soru 6 ==
**Üretim miktarı artıkça maliyeti minimize eden miktarı azalan girdiye ne ad verilir?**