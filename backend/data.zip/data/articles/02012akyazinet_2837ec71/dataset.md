# Dataset: 02012 akyazi net

Generated on: 2025-12-20T00:02:29.031562
Total questions: 1

| # | Question                            | Answer      | Category | Related_Chunk_IDs |
| - | ----------------------------------- | ----------- | -------- | ----------------- |
| 1 | Veysel Sarı kaç yaşında vefat etti? | 84 yaşında. | FACTUAL  | c0000             |