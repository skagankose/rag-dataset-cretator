---
id: 02012akyazinet_2837ec71
url: file://02012_akyazi_net.md
title: 02012 akyazi net
lang: en
created_at: '2025-12-20T00:02:20.504844'
checksum: 5254ca772eddcba9d92afe195f8e6a1331dff54e6f7e334803df083d7620f439
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 50
  char_count: 360
  num_chunks: 1
  num_sections: 1
---
= Veysel Sarı Vefat İlanı =

== Akyazi.Net - Akyazı'nın En Güncel Haber Sitesi ==

Akyazı Altındere Cumhuriyet Mahallesi halkından Eyüp ve Zekeriya Sarı'nın amcaları, İsmail, Recep ve Muharrem Sarı'nın babaları 84 yaşındaki Veysel Sarı vefat etti. Cenazesi hanesinde alınacak helallik ve kılınacak cenaze namazının ardından aile mezarlığında toprağa verilecek.