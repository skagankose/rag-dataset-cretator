# Dataset: 01981 soru doktorsitesi com

Generated on: 2025-12-20T00:01:28.937179
Total questions: 1

| # | Question                       | Answer                 | Category | Related_Chunk_IDs |
| - | ------------------------------ | ---------------------- | -------- | ----------------- |
| 1 | Hangi terapi yöntemi önerildi? | Gottman çift terapisi. | FACTUAL  | c0000             |