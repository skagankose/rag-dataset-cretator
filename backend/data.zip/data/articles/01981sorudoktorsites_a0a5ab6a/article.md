---
id: 01981sorudoktorsites_a0a5ab6a
url: file://01981_soru_doktorsitesi_com.md
title: 01981 soru doktorsitesi com
lang: en
created_at: '2025-12-20T00:01:19.520243'
checksum: 5946551b06e89b5913e5bf95a8a3d4159534eefa0799161ab6c4dbddfe1e2e75
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 103
  char_count: 806
  num_chunks: 1
  num_sections: 1
---
= Kurtarabilir miyiz - 2357787 =

Hocam merhaba, eşimle 13 yıllık bir evliliğimiz ve bu evlilikten 12 yaşında kızımız ve 6 yaşında oğlumuz var. Devamlı tartışmalar ve barışmalar sonucunda artık birbirimize zarar verdiğimiz düşüncesiyle ayrılık kararı almayı düşünüyoruz. Fakat çocuklar... Bu konuda da çok huzursuzuz. Birbirimize defalarca şans verdik ama kendi çabamızla problemleri çözemiyoruz. Destek almayı da denemedik. Destek almayı da düşündük; destekle kendimizi, en önemlisi de çocukları, kurtarabilir miyiz... Teşekkürler.

Merhaba Gökhan Bey, öncelikle ilişkideki sorunun aslında neden kaynaklandığını keşfedip uygun çözüm yöntemleriyle müdahale edildiğinde iyileşme olmaktadır. Gottman çift terapisi ile sizlere yardımcı olmak isterim. Ayrıntılı bilgi için beni arayabilirsiniz. Hayırlı günler.