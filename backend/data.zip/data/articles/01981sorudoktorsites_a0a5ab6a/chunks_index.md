# Chunks Index

| ID    | Section                      | Heading Path                 | Char Range | Preview                                                                                              |
| ----- | ---------------------------- | ---------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Kurtarabilir miyiz - 2357787 | Kurtarabilir miyiz - 2357787 | 0-806      | = Kurtarabilir miyiz - 2357787 = Hocam merhaba, eşimle 13 yıllık bir evliliğimiz ve bu evlilikten... |