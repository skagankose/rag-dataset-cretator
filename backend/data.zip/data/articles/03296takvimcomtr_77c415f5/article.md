---
id: 03296takvimcomtr_77c415f5
url: file://03296_takvim_com_tr.md
title: 03296 takvim com tr
lang: en
created_at: '2025-12-20T00:25:21.538038'
checksum: 9a2c904dcf733573df1be94309ef144404f37ace4bcf524ef2edfb8febac955d
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 406
  char_count: 3151
  num_chunks: 4
  num_sections: 1
---
= Canan Kaftancıoğlu bir neden değil sonuçtur! İşte CHP'nin ve dostlarının PKK sevgisi =

Canan Kaftancıoğlu bir neden değil sonuçtur! İşte CHP'nin ve dostlarının PKK sevgisi - Takvim  
Canan Kaftancıoğlu bir neden değil sonuçtur! İşte CHP'nin ve dostlarının PKK sevgisi Türkiye'nin ana muhalefet partisi ve dostları, Başkan Recep Tayyip Erdoğan karşıtlığının öldürücü rahatlığıyla dolu dizgin yuvarlanıyor. CHP İstanbul İl Başkanı Canan Kaftacıoğlu'nun konuşmasında Atatürk yerine Mustafa Kemal'i ısrarla kullanmasıyla birlikte, CHP'nin ABD destekli terör örgütü PKK'yı ve Suriye ve Irak'taki uzantıları olan YPG ve PYD'yi dost gören açıklamaları tekrar gündeme geldi. Takvim.com.tr'nin özel haberi...

HDP'yi sosyolojik tabanda tüketen üst akıl, ibresini Cumhuriyet Halk Partisi'ne çevirdi. CHP içerisinden de PKK'lı isimleri öven açıklamaların artarak geldiği bu dönemde parti yönetiminden bu isimlere cılız bir tepki bile gelmiyor. Fransa'da öldürülen PKK'nın üst düzey elebaşılarından Sakine Cansız'ın yakın arkadaşı Canan Kaftancıoğlu'nun Atatürk yerine Mustafa Kemal ısrarı eleştirilerin hedefini parti yönetimine doğrulttu. CHP Genel Başkanı Kemal Kılıçdaroğlu'ndan CHP'li yöneticilere, ABD destekli FOX TV'nin eski sunucusu Fatih Portakal'dan Emekli Tuğamiral Türker Ertürk'e kadar öne çıkan muhalif figürlerin, terör örgütü PKK'yı tırnak içinde kutsayan konuşmalarını derledik...

**2014 | ABD'Lİ FOX TV'NİN HABER SUNUCUSU FATİH PORTAKAL:**  
"TÜRKİYE PKK'YA TEŞEKKÜR ETMELİ"  
Irak'ın kuzeyindeki Amerli'de yaşayan Türkmenlerin kurtarılması sonrası bunu PKK'nın başarısıymış gibi göstermeye çalışan Fatih Portakal, "Bugün o Türkmenler kurtulduysa, yatıp kalkıp ABD'ye, Irak hükümetine, Peşmergeye ve PKK'ya da teşekkür etmeliler." sözlerini sarf etmişti.

**2 EYLÜL 2015 | CHP ÇANAKKALE MİLLETVEKİLİ MUHARREM ERKEK:**  
"PYD İLE SINIR OLMAMIZDA HİÇBİR SAKINCA YOK"  
Mardin'de konuşan CHP Çanakkale Milletvekili Muharrem Erkek, "Suriye ve Irak'tan bahsedildi. Biz kardeşsek, sınırımızda başkası olacağına PYD olsun. Bizce hiç bir sakıncası yok." sözlerini kullanmıştı.

**9 ŞUBAT 2016 | CHP İSTANBUL MİLLETVEKİLİ SEZGİN TANRIKULU:**  
"PYD TERÖR ÖRGÜTÜ DEĞİLDİR"  
CHP milletvekillerinden Gürsel Tekin ile "SİHA" lakabıyla bilinen Sezgin Tanrıkulu, İngiltere'de bir toplantıya katıldı. Toplantıya da Sezgin Tanrıkulu'nun terör örgütü PKK'nın uzantısı olan PYD için söyledikleri damga vurdu. Wikileaks belgelerinde adı TR705 olarak geçen, ABD'nin istihbarat örgütü CIA'ya bilgi sağlayan CHP İstanbul Milletvekili Sezgin Tanrıkulu, "PYD, Suriye'de kendi yaşamlarını korumaya çalışan, kendi topraklarını küresel bir vahşet örgütüne karşı korumaya çalışan bir yapılanmadır." demişti.

**7 HAZİRAN 2016 | KEMAL KILIÇDAROĞLU:**  
"BİZ YPG'Yİ TERÖR ÖRGÜTÜ OLARAK GÖRMEYİZ"  
Tarafsız Bölge programına katılan CHP Lideri Kemal Kılıçdaroğlu, "Biz YPG'yi terör örgütü olarak görmeyiz. Yani kendi bulunduğu yerde, kendi halkını savunan bir örgüt olarak görürüz." yorumunda bulunmuştu.

**1 ŞUBAT 2018 | CHP İZMİR MİLLETVEKİLİ SELİN SAYEK BÖKE:**  
"TERÖR ÖRGÜTÜ DİYECEK BİR İSTİHBARATIMIZ YOK"  
Habertürk TV'de Kübra Par'ın konuğu olan CHP İzmir M...