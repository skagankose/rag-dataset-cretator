---
id: 00300eksisozlukcom_0d0f73b4
url: file://00300_eksisozluk_com.md
title: 00300 eksisozluk com
lang: en
created_at: '2025-12-19T23:05:36.555465'
checksum: 1f6efc4a158db91dd1ef7894fa0402535054296a6dc61fdaa977e335f391d7ad
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 233
  char_count: 1789
  num_chunks: 2
  num_sections: 1
---
özellikle kağıt para devrinden önce, alışverişte kullanılan paralar altın ve gümüş içeriyorlardı. her devirde olduğu gibi, o devirde de bulunan bazı düzenbazlar, bu paraları kenarlarından kazıyarak, çok az miktarda da olsa, bu değerli madenleri biriktiriyor, parayı da tekrar kullanabiliyorlardı.

o devirlerde tüccarlar, parayı tartıyorlar ve ağırlığı eksikse kabul etmiyorlardı. tabii, para da elinizde kalıyordu. antik para kataloglarında dikkat ederseniz, paraların büyük bir kısmının tam yuvarlak olmadığını görürsünüz.

bu sorunu çözmek ve halkı eksik paraya karşı korumak için bozuk paraların kenarları tırtırlı yapılmaya başlandı. bu tırtırlar sayesinde paranın kenarının kazındığı hemen belli oluyordu ve kenarı kazınmış parayı kimse almıyordu.

bu adet günümüze kadar devam etti. artık içinde değerli bir maden bulunmamasına rağmen, bozuk paralarımızın kenarlarında ya tırtır ya da bir yazı vardır.

kağıt paraların merkez bankası tarafından basıldığı bilinir de, madeni paraları maliye bakanlığı'nın çıkardığı pek bilinmez.

madeni paraların toplam para stoku içindeki oranı da yaklaşık yüzde 1 civarındadır. hiç dikkat ettiniz mi? insan yüzleri kağıt paralarda önden, madeni paralarda ise yandandır.

madeni paralarda yer çok küçük olduğundan, kabartma tekniği ile bir yüzün tam detayını vermek mümkün olamamaktadır. yandan bir profil kişiyi daha iyi tanınır kılmaktadır.

* 30.01.2009 04:20 maximus decimus meridius 5 entry daha

anket iletişim şeffaflık raporu reklam kariyer kullanım koşulları gizlilik politikamız sss istatistikler sub-etha instagram twitter facebook × çerezleri (3. taraf çerezler dahil), sitemizin temel işlevselliğini sağlamak, kullanımınızın istatistik analizini yapmak ve içeriklerle reklamların kişiselleştirilmesi için kullanıyoruz. daha fazla bilgi