# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                            |
| ----- | ------- | ------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | özellikle kağıt para devrinden önce, alışverişte kullanılan paralar altın ve gümüş içeriyorlardı.  |
| c0001 | Lead    | Lead         | 800-1789   | de değerli bir maden bulunmamasına rağmen, bozuk paralarımızın kenarlarında ya tırtır ya da bir... |