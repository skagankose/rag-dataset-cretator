# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                             |
| ----- | ------- | ------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Fort Knox, Kentucky, ABD, 14 Nisan 1980 7.2/10 (151 Oy) · 565 okunma 7.2/10 (151 Oy) Atiye Atiye... |
| c0001 | Lead    | Lead         | 800-1800   | itabından sıkıldığımda bu kitaba dönüyordum, bundan Aeden kitabına şeklinde gidiyordu ve ilk...     |
| c0002 | Lead    | Lead         | 1600-2600  | diğimizi bize kavuşturacak bir otobüsü, bazen de yeni bir hayata adım atmamızı sağlayan trenin...   |
| c0003 | Lead    | Lead         | 2400-2999  | leyici kaleminden hissetmek mümkün.                                                                 |