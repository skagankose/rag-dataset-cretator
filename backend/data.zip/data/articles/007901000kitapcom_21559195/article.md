---
id: 007901000kitapcom_21559195
url: file://00790_1000kitap_com.md
title: 00790 1000kitap com
lang: en
created_at: '2025-12-19T23:21:47.538779'
checksum: 5033983363b0d34b76cbac3759350d67c0f2e5fb76cb453d0bfb090ee2b9f777
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 404
  char_count: 2999
  num_chunks: 4
  num_sections: 1
---
Fort Knox, Kentucky, ABD, 14 Nisan 1980 7.2/10 (151 Oy) · 565 okunma 7.2/10 (151 Oy)

Atiye Atiye Yitik Kalpler İstasyonu'yu inceledi. @AtiyeAtes·01 Nis 18:15·Kitabı okudu  
10 ayrı hikaye... 10 ayrı yazar... 10 ayrı yaşanmışlık ama aynı terminal...  
İlginçti, farklı olmuş... 2. Dünya Savaşı sonrası insanların neler hissettikleri, umutları, yeni bir hayata adım atışları işlenmiş... Hikaye sevenler için ideal bir kitap...

Neslihan YILMAZ Yitik Kalpler İstasyonu'yu inceledi. @Okuyantarihci·28 Nis 21:32·Kitabı okudu  
Merhaba 1k ailesi! Bugün sizlere Sarah JIO'nun Yitik Kalpler İstasyonu kitabını yorumlayacağım. Kitaba dün başladım bayağı da ilerledim fakat buraya kaydetmeyi unutmuşum o yüzden de böyle bir karışıklık oldu diyebilirim. İki kitabı aynı anda okumak gerçekten çok güzel, Aeden kitabından sıkıldığımda bu kitaba dönüyordum, bundan Aeden kitabına şeklinde gidiyordu ve ilk bitirdiğim kitap Aeden oldu onu da yorumladım zaten.. Gelelim bu kitaba.. Kitap farklı yazarların yazdığı, bazıları kısa bazıları uzun hikayelerden oluşuyor. En beğendiğim hikaye Sarah Jio'nun oldu tabiki. Diğer hikayelerde güzeldi ama eksik bir şeyler vardı diye düşünüyorum. Ama genel olarak iyiydi, kitap beğendim. Çerezlik olarak okumak isterseniz tavsiye ederim, iyi okumalar.

Eda Yitik Kalpler İstasyonu'yu inceledi. @Edlibrary·28 Oca 01:46·Kitabı okudu  
Tren istasyonları, havaalanları, dolmuş durakları... Birçok insana ve onların hikayelerine ev sahipliği yapan bu mekanlar, bulunduğu konumda ne çok hareketlidir değil mi? Ayrılık, kavuşma gibi bir çok güçlü duygulara şahitlik ederler. Bazen sevdiğimizi bize kavuşturacak bir otobüsü, bazen de yeni bir hayata adım atmamızı sağlayan trenin istasyona varmasını, hayallerimize doğru uçan uçağının piste inmesini bekleriz. İşte bu kitapta birbirinden güzel on farklı kalem aynı mekanda yani görkemli bir tren garında geçen on farklı hikaye ile yüreklerimize dokunur.  

"Kalbimde bir kıpırtı hissettim. Sanki bahçende çok güzel bir kelebek bulmuşsun da üç saniye içinde uçup gideceğini biliyormuşsun gibi."  

Kapağında Kristin Hannah ve Sarah Jio'yu görmemle merakla aldığım bu kitap, tüm dünyada çoksatan listelerinde yer alan on yazarın Grand Central Terminal'de geçen hikayelerini ele alıyor. II. Dünya Savaşı sonrası insanların hayatlarına devam etme mücadelelerini ve savaşın geride bıraktığı umutlarına sahip çıkma çabalarını yazarların etkileyici kaleminden hissetmek mümkün. Kitap konu ve zaman dilimi olarak II. Dünya Savaşı'nı ele alsa da bize savaş meydanlarını değil, en az cephelerdeki askerler kadar savaşa göğüs geren kadınları anlatıp tanımamıza yardımcı oluyor. Savaşın geride bıraktıkları ile hayatı devam ettirme mücadelelerini, kayıp giden hayatlar karşısında yeni adımlarını görüyoruz. Bu güçlü kadınlar bombanın yaraladığı topraklara umut ve sevgi ekiyorlar. Savaşa dair kitaplar okuyup, filmler izledim fakat dediğim gibi bu kitap savaş meydanlarını değil, o meydanlar kadar önem taşıyan kadınlar cephesini bize gösteriyor.