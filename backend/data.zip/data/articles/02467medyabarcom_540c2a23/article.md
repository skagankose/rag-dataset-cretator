---
id: 02467medyabarcom_540c2a23
url: file://02467_medyabar_com.md
title: 02467 medyabar com
lang: en
created_at: '2025-12-20T00:11:32.512035'
checksum: 58d817d37a4a6b609e5828f394414c97eef87b9069f6730af4a18d6ac7e31bda
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 174
  char_count: 1264
  num_chunks: 2
  num_sections: 1
---
= İki kardeşe otomobil çarptı! Minı̇k kız yaşam savaşı veriyor =

Karasu'da S.M. ve İ.M. isimli iki kardeşe otomobil çarptı. S.M. yoğun bakımda yaşam mücadelesi verirken diğer küçük çocuğun tedavisinin sürdüğü öğrenildi.

Olay bugün Karasu Yalı Mahallesi Plaj mevkiinde meydana geldi. S.M. ve İ.M. isimli 2 kardeşe otomobil çarptı. Feci kaza sonrasında yaralı küçük kardeşler olay yerine gelen sağlık ekipleri tarafından Karasu Devlet Hastanesine sevk edildi.

Burada yapılan ilk müdahale sonrası S.M. isimli kız çocuğu Yenikent Devlet Hastanesine, kardeş İ.M. ise Sakarya Üniversitesi Eğitim ve Araştırma Hastanesine sevk edildiği bildirildi. S.M. isimli kız çocuğunun yoğun bakımda yaşam mücadelesi verdiği öğrenildi.

Haberi alan baba Bünyamin M. ve ailesi hastaneye giderken, gözyaşları sel oldu aktı. Aile sinir krizleri geçirirken polis kazayla ilgili soruşturma başlattı.

Hatice - allah acil şifalar versin

Yanıtla. 0 Beğen. 0 Beğenme 23 Ağustos 23:21 kertenkele - Çocuklarınızı dizinizin dibinden, gözünüzün önünden ayırmayın veya çocuklarınıza vakit ayırın. Çocukların da enerjilerini atmaya, oynamaya ihtiyaçları var. Kapının önüne, sokağa salıp “oyna” demek ile sorun çözülmez. Eski kafalığı bırakın. Devir değişti. Tek başına çocuk sokağa bırakılmaz.