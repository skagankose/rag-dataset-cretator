# Chunks Index

| ID    | Section                                                      | Heading Path                                                 | Char Range | Preview                        |
| ----- | ------------------------------------------------------------ | ------------------------------------------------------------ | ---------- | ------------------------------ |
| c0000 | İki kardeşe otomobil çarptı! Minı̇k kız yaşam savaşı veriyor | İki kardeşe otomobil çarptı! Minı̇k kız yaşam savaşı veriyor | 0-1000     | = İki kardeşe otomobil çarptı! |
| c0001 | İki kardeşe otomobil çarptı! Minı̇k kız yaşam savaşı veriyor | İki kardeşe otomobil çarptı! Minı̇k kız yaşam savaşı veriyor | 800-1264   | aktı.                          |