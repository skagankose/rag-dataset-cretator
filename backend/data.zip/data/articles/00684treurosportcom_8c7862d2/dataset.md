# Dataset: 00684 tr eurosport com

Generated on: 2025-12-19T23:18:24.414699
Total questions: 1

| # | Question                                                                                   | Answer                                 | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------ | -------------------------------------- | -------- | ----------------- |
| 1 | HC Erlangen ile TVB 1898 Stuttgart arasındaki karşılaşma hangi tarih ve saatte başlayacak? | 29 Ağustos 2019 tarihinde, saat 20:00. | FACTUAL  | c0000             |