# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                           |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-849      | 23 Ağustos 2021, Pazartesi 13:05 Son Güncelleme: 23.08.2021 13:37 Navarra'daki yarışları canlı... |