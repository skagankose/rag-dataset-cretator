# Dataset: 01632 fanatik com tr

Generated on: 2025-12-19T23:49:51.882303
Total questions: 1

| # | Question                                    | Answer | Category | Related_Chunk_IDs |
| - | ------------------------------------------- | ------ | -------- | ----------------- |
| 1 | Bu sonuçla Razgatlıoğlu'nun puanı kaç oldu? | 311    | FACTUAL  | c0000             |