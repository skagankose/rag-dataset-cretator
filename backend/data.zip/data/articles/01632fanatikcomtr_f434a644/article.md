---
id: 01632fanatikcomtr_f434a644
url: file://01632_fanatik_com_tr.md
title: 01632 fanatik com tr
lang: en
created_at: '2025-12-19T23:49:40.541303'
checksum: 98f886a267d14c4b076d010bca4bdce69f582a57e2a1fba076937a14502c80d0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 103
  char_count: 849
  num_chunks: 1
  num_sections: 1
---
23 Ağustos 2021, Pazartesi 13:05  
Son Güncelleme: 23.08.2021 13:37  

Navarra'daki yarışları canlı yayımlayan İspanyol devlet televizyonu RTVE, internet sitesinde "Razgatlıoğlu ulaşılamaz" ifadesini kullanarak, Türk motosikletçinin genel klasmanda liderliğe çıktığını vurguladı. "Razgatlıoğlu, Redding'i frenledi ve Rea ile liderliği paylaştı." başlığını atan Marca gazetesi de "Yamaha pilotu, hatasız bir yarış çıkararak Redding veya Rea'nın kendisini geçmelerine izin vermedi. Bu sonuçla puanını 311'e çıkaran Razgatlıoğlu, İngiliz Rea ile puanını eşitledi." diye yazdı.  

El Mundo deportivo gazetesi ise "Razgatlıoğlu, Navarra'da kazandı ve Rea ile liderliğe ulaştı." başlığı altında verdiği haberde, "Türk pilot, Scott Redding'in son 3 yarıştır elde ettiği zaferi sonlandırdı. Razgatlıoğlu, Navarra'dan güçlenerek çıktı." ifadelerini kullandı.