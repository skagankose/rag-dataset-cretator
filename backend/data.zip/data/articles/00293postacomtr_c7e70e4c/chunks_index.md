# Chunks Index

| ID    | Section                                        | Heading Path                                   | Char Range | Preview                                                                                             |
| ----- | ---------------------------------------------- | ---------------------------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Sokak köpeklerine evinin yanında barınak yaptı | Sokak köpeklerine evinin yanında barınak yaptı | 0-1000     | = Sokak köpeklerine evinin yanında barınak yaptı = Muş'ta özel proje danışmanlığı yapan Fatih...    |
| c0001 | Sokak köpeklerine evinin yanında barınak yaptı | Sokak köpeklerine evinin yanında barınak yaptı | 800-1011   | te köpekleri besleyen 5 yaşındaki Zeynep Oğuzhan, babasından eve daha çok köpek getirmesini istedi. |