---
id: 00293postacomtr_c7e70e4c
url: file://00293_posta_com_tr.md
title: 00293 posta com tr
lang: en
created_at: '2025-12-19T23:05:23.563170'
checksum: 4d5c5400be379f7bc5aab00a9cd7f5188cb852d8523ef91724afe01bb0fec1fb
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 134
  char_count: 1011
  num_chunks: 2
  num_sections: 1
---
= Sokak köpeklerine evinin yanında barınak yaptı =

Muş'ta özel proje danışmanlığı yapan Fatih Oğuzhan, evinin yanına yaptırdığı barınakta 12'si yavru olmak üzere 20 sokak köpeğine sahip çıktı. Belediyeden köpek barınak merkezi açmalarını isteyen Oğuzhan, bu konuda hayvanseverleri de göreve davet etti.

Sarah Mahallesi'ndeki evinin yanındaki kümesi hayvan barınığına çevirerek köpekleri burada topladığını anlatan Oğuzhan, köpekleri dört kızı ile birlikte beslediğini söyledi. Oğuzhan, "Kar fazla, ısı sıfırın altında 25 dereceye kadar düşüyor. Sokak hayvanlar zor günler geçiriyor. Biz kendi olanaklarımızla 20 köpeğe ev yaptık. Diğer yardıma muhtaç köpeklerin de imdadına yetişmemiz gerek. Bu konuda valilik, belediye ve hayvanseverleri göreve davet ediyorum" dedi.

Babası ve ablaları ile birlikte köpekleri besleyen 5 yaşındaki Zeynep Oğuzhan, babasından eve daha çok köpek getirmesini istedi. Günün büyük bir bölümünü köpeklerle ilgilenerek geçiren minik Zeynep, onlara elleriyle yemek verdiğini söyledi.