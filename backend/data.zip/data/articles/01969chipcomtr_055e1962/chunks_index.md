# Chunks Index

| ID    | Section                                   | Heading Path                              | Char Range | Preview                                                                                         |
| ----- | ----------------------------------------- | ----------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | 2005 Internet Telephony Mükemmellik Ödülü | 2005 Internet Telephony Mükemmellik Ödülü | 0-1000     | = 2005 Internet Telephony Mükemmellik Ödülü = 1998'den beri VoIP alanında sektörün en önemli... |
| c0001 | 2005 Internet Telephony Mükemmellik Ödülü | 2005 Internet Telephony Mükemmellik Ödülü | 800-1658   | zarında abartılı reklamları görmek mümkün.                                                      |