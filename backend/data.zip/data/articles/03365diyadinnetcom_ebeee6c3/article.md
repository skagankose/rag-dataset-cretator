---
id: 03365diyadinnetcom_ebeee6c3
url: file://03365_diyadinnet_com.md
title: 03365 diyadinnet com
lang: en
created_at: '2025-12-20T00:26:30.543095'
checksum: 27e96348a70d221625cdaf27da64dd1de8de241b6858212323d7c62fdbab18b6
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 374
  char_count: 3010
  num_chunks: 4
  num_sections: 1
---
= "yüzyıllık marka olmak" araştırması tamamlandı =

**Ekonomi Haberleri** | Sitede 6002 kişi var | 12 Ekim 2021 Salı - 12:24 / Güncelleme: 12 Ekim 2021 Salı

İSTANBUL(AA) – Akbank, Deloitte, Sabancı Üniversitesi Yönetici Geliştirme Birimi EDU ve Yüzyıllık Markalar Derneği'nin birlikte yürüttüğü “Yüzyıllık Marka Olmak” araştırması tamamlandı. Deloitte Türkiye'den yapılan açıklamaya göre, “Yüzyıllık marka olmak nasıl mümkün?” sorusuna yanıt veren araştırma, markaların kuruluş ve logo hikayelerinden dijital dönüşüme bakış açılarına kadar yüzyılı aşan yönetim süreçlerindeki dönüm noktalarını ortaya koyuyor.

Türkiye'deki köklü 32 markanın son kuşak temsilcileri ve üst yöneticileri, uzun ömürlerinin sırrını anlatırken ağırlıklı olarak “itibar yönetimi, sahici, şeffaf ve samimi olmak” üzerinde duruyor. Araştırma, marka kavramının köklü markalar nezdinde nasıl geliştiğini göstermesinin yanı sıra günümüz ile gelecek arasında önemli bir köprü de kuruyor.

Çalışmaya katılan markaların yüzde 80'ini aile şirketleri oluşturuyor ve bu şirketler ağırlıklı olarak dördüncü ve beşinci nesil tarafından temsil ediliyor. 32 markanın son kuşak temsilcileri ve üst düzey yöneticileri ile yapılan derinlemesine görüşmelerde “marka” kavramının en çok itibar ile ilişkilendirildiği, itibar ve güven ilişkisine dikkat çekilerek güven ilişkisinin tüm paydaşlar nezdinde önemli olduğunun vurgulandığı görülüyor.

Açıklamada görüşlerine yer verilen Akbank Perakende Bankacılık Genel Müdür Yardımcısı Bülent Oğuz, aile şirketlerinin ülke ekonomisi için çok önemli değerler olduğunu belirterek, “Sabancı Üniversitesi, EDU ile birlikte 2014 yılından itibaren ‘Akbank Aile Şirketleri Akademisi’ programını başarıyla yürütüyoruz. Diğer taraftan 2016 yılında, aile şirketlerine ‘ayakta kalma, sürdürülebilirlik’ gibi konularda kılavuzluk eden ‘Aile Şirketlerinde Sürdürülebilir Başarının Anahtarları’ raporumuzu yayınladık. Bu sene de Sabancı Üniversitesi, EDU, Deloitte ve Yüzyıllık Markalar Derneği ile iş birliğimiz kapsamında kurumsal dönüşüm sürecinde çok önemli olduğuna inandığımız marka konulu bir çalışma hazırladık. Osmanlı döneminde filizlenip, Cumhuriyet'in kuruluşuna tanıklık eden aile şirketlerinin başarı ile yönettikleri marka olma süreçlerine ve tecrübelerine yer verdiğimiz “Yüzyıllık Marka Olmak” adlı bu ikinci araştırma raporumuzda bir asırlık deneyimleriyle markaları ele aldık. Araştırmadan yola çıkarak oluşturulan ve benzersiz kuruluş hikayelerini içeren ‘Yüzyıllık Marka Olmak’ kılavuz kitabının yeni girişimciler için de ilham verici bir çalışma olacağına inanıyoruz.” ifadelerini kullandı.

Deloitte Türkiye Ortağı ve Denetim Hizmetleri Lideri Ali Çiçekli de Yüzyıllık Markalar Derneği, Akbank ve Sabancı Üniversitesi Yönetici Geliştirme Birimi EDU ile Türkiye'nin değerleri haline gelmiş ve yüzyılı aşkın süredir faaliyet gösteren markaların uzun süreli başarılarını analiz ettiklerini kaydetti. Çiçekli, şu değerlendirmelerde bulundu: “Yaptığımız bu çalışmada amacımız, köklü firmalarımızın neyi d