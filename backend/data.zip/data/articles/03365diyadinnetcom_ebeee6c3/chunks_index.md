# Chunks Index

| ID    | Section                                        | Heading Path                                   | Char Range | Preview                                                                                                |
| ----- | ---------------------------------------------- | ---------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | "yüzyıllık marka olmak" araştırması tamamlandı | "yüzyıllık marka olmak" araştırması tamamlandı | 0-1000     | = "yüzyıllık marka olmak" araştırması tamamlandı = **Ekonomi Haberleri** | Sitede 6002 kişi var |...   |
| c0001 | "yüzyıllık marka olmak" araştırması tamamlandı | "yüzyıllık marka olmak" araştırması tamamlandı | 800-1800   | uruyor.                                                                                                |
| c0002 | "yüzyıllık marka olmak" araştırması tamamlandı | "yüzyıllık marka olmak" araştırması tamamlandı | 1600-2600  | si, EDU ile birlikte 2014 yılından itibaren ‘Akbank Aile Şirketleri Akademisi’ programını başarıyla... |
| c0003 | "yüzyıllık marka olmak" araştırması tamamlandı | "yüzyıllık marka olmak" araştırması tamamlandı | 2400-3010  | a çıkarak oluşturulan ve benzersiz kuruluş hikayelerini içeren ‘Yüzyıllık Marka Olmak’ kılavuz...      |