# Dataset: 02647 babil com

Generated on: 2025-12-20T00:14:43.568835
Total questions: 1

| # | Question                                | Answer | Category | Related_Chunk_IDs |
| - | --------------------------------------- | ------ | -------- | ----------------- |
| 1 | Bu kitapta kaç orman öyküsü yer alıyor? | On bir | FACTUAL  | c0000             |