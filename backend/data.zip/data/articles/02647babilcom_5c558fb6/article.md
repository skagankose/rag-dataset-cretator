---
id: 02647babilcom_5c558fb6
url: file://02647_babil_com.md
title: 02647 babil com
lang: en
created_at: '2025-12-20T00:14:32.518538'
checksum: 07939d80198a988b436d40573db9d1e2ef75572178feaf237d1e16e245e6a17b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 67
  char_count: 450
  num_chunks: 1
  num_sections: 1
---
= Gemma Barder | Babil =

== Gemma Barder Eserleri Katkıda Bulunduğu Ürünler ==

=== Orman Öyküleri - İlk Kitabım ===

Tam on bir muhteşem orman öyküsüyle birlikte müthiş bir eğlence sizi bekliyor. Tatlı köpek Biber'e görevinde yardımcı olun, Penguen Pırtık'ın uçmak için ne yaptığını keşfedin, kendini maymun sanan Fil Limon'la tanışın ve daha bir sürü maceraya atılın. Büyüleyici çizimlerle ve sevimli karakterlerle dolu bu öykülere bayılacaksınız.