---
id: 00570bursadabuguncom_73ec5f3b
url: file://00570_bursadabugun_com.md
title: 00570 bursadabugun com
lang: en
created_at: '2025-12-19T23:14:27.536053'
checksum: 0b5940f6a9e577b294d10a995dae5c6b8804904e7f5149a4613b723e640a82a8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 388
  char_count: 2821
  num_chunks: 4
  num_sections: 1
---
= Bir saatte 1 milyonluk vurgun yaptılar! =

Ankara Polatlı'da Koç ailesine ait üç katlı apartman, gündüz saatlerinde doğal gaz görevlileri gibi eve giren hırsızlar tarafından bir saat içerisinde soyuldu. 13 Kasım 2018 Salı, 07:31 tarihinde ailenin 15 yıllık birikimini bir saatte çalan şüphelilerin toplam 1 milyon lira değerinde bir vurgun gerçekleştirdiği öğrenilirken, yeğen Cengiz Çakır olayın kendilerini yakından tanıyan birileri tarafından yapıldığını ileri sürdü.

Çakır, “Evin içerisinde yer alan kasaların yerini nereden bilecekler. Kasaları gizli bölmelerinden nasıl çıkaracaklar da yapacaklar. Muhtemelen bu işi kendisi de yapmadı. Bir ekip gönderdi. Bütün planı verdi. Olayları bu kişilere gerçekleştirdi” dedi.

Olay Polatlı Gülveren Mahallesi'nde Fehmi Koç ailesine ait üç katlı bir apartmanda meydana geldi. Ailesiyle birlikte Ankara merkezine bir nişan davetine giden Koç ailesi eve döndüğünde şok tabloyla karşı karşıya kaldı. Nişanda bir saat durduktan sonra evlerine döndüklerinde karşılaştıkları tablo karşısında ne yapacaklarını şaşıran Koç ailesi durumu hemen polise bildirdi. Evlerinde gizli bölmelerde yer alan altın ve para olmak üzere iki ayrı kasanın delik deşik olduğunu gören aile, 15 yıllık birikimlerinin ortadan kaybolduğunu gördü.

Olayla ilgili Milliyet'e konuşan Koç ailesinin yeğeni Cengiz Çakır, “Birinci katın arka bölümünden girmişler. İkinci katta kasa olduğunu biliyorlarmış. Oradaki gizli bölmeden kasaları çıkarmışlar. Kasayı delik deşik etmişler. Yüklü miktarda altın ve ziynet eşyasıyla para almışlar. 370 bin lira değerinde altın ve ziynet eşyasını almışlar. Bunun yanı sıra para kasasında da ABD Doları ve Türk Lirası olmak üzere toplam değeri 600 bin lirayı bulan para çalmışlar. Anlayacağınız, yaklaşık 1 milyon lira değerinde para ve ziynet eşyaları yok oldu. Ziynet eşyalarının içerisinde bilezikler, çeyrek, gram, yarım ve tam altın var. Yengem bu altınları 29 yaşında bekar bir oğlu var, onun düğünü için saklıyordu. 15 yıllık birimler şu anda sıfırlandı. Evlerinde yaptıkları tüm birikim sıfırlandı” dedi.

“Eve 7 kişi girdiğini düşünüyoruz.” Polatlı’da soğan alım ve satışı ile uğraştığını ve dayısının kendisine ait deposu, iş yeri ve kamyonları bulunduğunu dile getiren Çakır, “Eve tahminen 7 kişi girdiği düşünülüyor. Hilti ile girmişler, kapıları balyozla kırmışlar. Güvenlik kamera görüntüleri evin biraz uzağındaki bölümde bulunuyor. Emniyet görevlileri de şu anda bu konuyu araştırıyor. Bazı görgü tanıkları varmış. Doğal gaz görevlileri yazan bir araçla gelmişler. Üzerlerinde tulum varmış. Saat 15.00 gibi evin o taraflarında görmüşler. Parmak izleri çıkmasın diye eldiven kullanmışlar” diye konuştu.

Dayısının eve geldiğinde avlunun demir kapılarının açık olduğunu fark ettiğini dile getiren Çakır, “Eve giriş kapısının açık olduğunu görüyorlar. Kapın…”