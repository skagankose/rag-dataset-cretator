# Chunks Index

| ID    | Section                                 | Heading Path                            | Char Range | Preview                                            |
| ----- | --------------------------------------- | --------------------------------------- | ---------- | -------------------------------------------------- |
| c0000 | Bir saatte 1 milyonluk vurgun yaptılar! | Bir saatte 1 milyonluk vurgun yaptılar! | 0-1000     | = Bir saatte 1 milyonluk vurgun yaptılar!          |
| c0001 | Bir saatte 1 milyonluk vurgun yaptılar! | Bir saatte 1 milyonluk vurgun yaptılar! | 800-1800   | partmanda meydana geldi.                           |
| c0002 | Bir saatte 1 milyonluk vurgun yaptılar! | Bir saatte 1 milyonluk vurgun yaptılar! | 1600-2600  | ışlar.                                             |
| c0003 | Bir saatte 1 milyonluk vurgun yaptılar! | Bir saatte 1 milyonluk vurgun yaptılar! | 2400-2821  | iyet görevlileri de şu anda bu konuyu araştırıyor. |