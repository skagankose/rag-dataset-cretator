---
id: 00531haberlercom_d4b04953
url: file://00531_haberler_com.md
title: 00531 haberler com
lang: en
created_at: '2025-12-19T23:13:09.530136'
checksum: 3efc4ad45d99d5853a51ab509b31633be7153f0ebb4032a2fa3754ee87d76cad
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 158
  char_count: 1220
  num_chunks: 2
  num_sections: 1
---
= Çay işçiliğinin yevmiyesi artınca bahçelerde çalışma talebi çoğaldı =

**Haberler Ekonomi | 01.05.2020 10:50**  
Son Güncelleme: 01.05.2020 10:51  

Çay Üreticileri Dayanışma Derneği (ÇAYÜDAD) Başkanı Mustafa Mavi, yevmiye ücretlerinin artmasıyla Türkiye’nin dört bir yanından insanların Rize’ye çay toplamak için gelmek istediğini belirtti. “İl dışındaki vatandaşlar tarafından sanki orada iş hazır, gideyim çalışayım gibi bir algı oluştu. İzmir’den, bu sabah Gaziantep’ten, Antalya’dan arayanlar var. Zannediyorlar ki biz şimdi Rize’ye gidip hemen başlayacağız, 7 bin 500 lira maaş alacağız. Ben o insanlara zorlukları, çayı toplamasını bilip bilmediklerini soruyorum, bilmiyoruz diyor. Rize’ye daha önce geldiniz mi diyorum, gelmedik diyor. Ama bu haberi duyunca ‘zaten çiftçiyiz’ diyerek bunu da yapabileceklerini söylüyorlar” dedi.

250 liralık yevmiye ücretini vermenin önemli olmadığını, çaylığa girecek kişinin çay toplamayı bilmesi gerektiğini dile getiren müstahsil Süleyman Hanoğlu da, “Çayı herkes toplayamaz. 250 lira yevmiye vermek bir şey değil, bileni çalıştıracaksın. Bilmedikten sonra adamı almışsın, çaylığa ne olacak? Kafası çalışıyorsa, bir günde öğrenir; yoksa 6 ayda öğrenemez” şeklinde konuştu.