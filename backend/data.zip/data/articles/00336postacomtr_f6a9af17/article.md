---
id: 00336postacomtr_f6a9af17
url: file://00336_posta_com_tr.md
title: 00336 posta com tr
lang: en
created_at: '2025-12-19T23:06:49.528052'
checksum: 66496e51cd391652a8f3e40683cf991b346c9b284d2d013266f28826d043e89e
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 173
  char_count: 1368
  num_chunks: 2
  num_sections: 1
---
Cumhurbaşkanımız dün muhtarlar toplantısında dedi ki: "Gençlerimize 18 yaşında seçilme hakkı geliyor... 'Askerlik ne olacak?' diyorlar. Allah Allah. Sanki Türkiye'de 7 milyon gencin 7 milyonu da milletvekili oluyor. Parlamentoya kaç kişi girecek? 10-15 kişi girdiğini düşünürsen bunları askerlikten muaf tutarsın olur biter. Tecil demiyorum, muaf."

Seçilme yaşının düşürülmesi de dahil gençlerin siyasette önünün açılmasına yönelik her icraatı, fikri sonuna kadar desteklerim. Ama milletvekili olacak gençlerin askerlikten muaf tutulması fikri bambaşka bir iş.

Cumhurbaşkanımız önerisini "Parlamentodan daha önemli görev olabilir mi? Bu genç parlamentoya gelip vatanına milletine hizmet edecek..." diyerek izah etti. Parlamento görevi şüphesiz çok önemli bir vatani hizmet.

Peki, doktorluk değil mi? Öğretmenlik değil mi? Boğaziçi Üniversitesi Genetik Mühendisliği'nde, ODTÜ Bilgisayar Mühendisliği'nde, Hacettepe Tıp Fakültesi'nde okuyan çocuğu hayatının en verimli çağında "vatan hizmeti" diyerek askere alacaksın ama sırf Meclis'te elini kaldırıp indirecek diye ötekine "Senin askere gitmene gerek yok" diyeceksin.

Gençlerin siyasette daha etkin rol almaları için atılan her adıma varım. Gerekirse zorunlu askerlik uygulamasının tartışılmasına da varım. Ama milletvekillerine yapılan onca kıyağın yanına -bu maksatla veya değil—bir yenisini daha eklemeye yokum.