# Chunks Index

| ID    | Section                       | Heading Path                  | Char Range | Preview                                                                                             |
| ----- | ----------------------------- | ----------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Urfa'da bir gecede 2 etkinlik | Urfa'da bir gecede 2 etkinlik | 0-381      | = Urfa'da bir gecede 2 etkinlik = Urfa'da bir gecede 2 etkinlik Şanlıurfa Büyükşehir Belediyesi,... |