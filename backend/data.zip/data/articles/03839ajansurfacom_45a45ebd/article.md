---
id: 03839ajansurfacom_45a45ebd
url: file://03839_ajansurfa_com.md
title: 03839 ajansurfa com
lang: en
created_at: '2025-12-20T00:34:24.535697'
checksum: ccda46f0bbf01b60ff525e6eec43ee3833c894e4c6b385d94817cdeff67b179e
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 55
  char_count: 381
  num_chunks: 1
  num_sections: 1
---
= Urfa'da bir gecede 2 etkinlik =

Urfa'da bir gecede 2 etkinlik Şanlıurfa Büyükşehir Belediyesi, Arkeoloji Müzesi önünde kurduğu dev ekranda aynı gecede iki ayrı etkinliğe imza attı. 'Açık Havada Arabada Sinema Etkinliğinde "Selvi Boylum Al Yazmalım" filmini izleyen vatandaşlar ardından A Milli Takımımız ile Rusya arasında oynanan milli maçı, dev ekrandan izleme şansı yakaladı.