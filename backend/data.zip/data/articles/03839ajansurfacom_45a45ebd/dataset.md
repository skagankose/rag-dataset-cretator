# Dataset: 03839 ajansurfa com

Generated on: 2025-12-20T00:34:31.779759
Total questions: 1

| # | Question                                                       | Answer                   | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------------- | ------------------------ | -------- | ----------------- |
| 1 | Açık Havada Arabada Sinema Etkinliğinde hangi filmi izlediler? | Selvi Boylum Al Yazmalım | FACTUAL  | c0000             |