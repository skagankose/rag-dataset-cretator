# Chunks Index

| ID    | Section          | Heading Path     | Char Range | Preview                                                                                            |
| ----- | ---------------- | ---------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Koç (Mayıs 2016) | Koç (Mayıs 2016) | 48-622     | == Koç (Mayıs 2016) == Her türlü mali sorunu çözüme kavuşturacağınız bir aydasınız.                |
| c0001 | Boğa             | Boğa             | 622-1622   | == Boğa == 6 Mayıs 19:30’da Boğa burcunda gerçekleşecek yeni ay enerjisi ile hayatınızın aşk’la... |
| c0002 | Boğa             | Boğa             | 1422-2422  | türn etkisi alt batınla ilgili organlarda hastalıklara yol açabilir.                               |
| c0003 | Boğa             | Boğa             | 2222-2973  | ızlıkların yarım kalmışlıkların karşılığını fazlasıyla alacaksınız.                                |