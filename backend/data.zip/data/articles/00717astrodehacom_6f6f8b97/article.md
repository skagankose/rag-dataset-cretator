---
id: 00717astrodehacom_6f6f8b97
url: file://00717_astrodeha_com.md
title: 00717 astrodeha com
lang: en
created_at: '2025-12-19T23:19:21.538261'
checksum: 4b5baa6c5bd81041e705013ec7d93fd0b71582f7ae73a75820ae03a55e6e5196
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 386
  char_count: 2973
  num_chunks: 4
  num_sections: 2
---
= 2016 Mayıs Ayı Burç Yorumlarım - AstrodehA =

== Koç (Mayıs 2016) ==

Her türlü mali sorunu çözüme kavuşturacağınız bir aydasınız. Şansınız size destek olacak ve size gelirlerinizle ilgili her konuda fırsatlar getirecek. Bu ay önemli bir servet birikimi ile ilgili karşı karşıya kalabilirsiniz. Bu durumdan rahatsız olan kişilerin engelleri ile karşılaşabilirsiniz. Jüpiter direkt olarak 11. evinizi güçlendiriyor. Bu size gelir kaynaklarınızı artırmak ve para toplamak için çeşitli fırsatlar sağlayacaktır. Ayın 2’nci yarısı yeni bir şeylere başlamayın. Eve ait konular ya da mülkiyet gibi konularda yatırım yapmayın.

== Boğa ==

6 Mayıs 19:30’da Boğa burcunda gerçekleşecek yeni ay enerjisi ile hayatınızın aşk’la taçlandırabilirsiniz. Özel yaşamınızda her şey yerli yerine oturmaya başlıyor. Ruhunuz aşkın gücü ile arınıp güçleniyor. Geçmişin olumsuzluklarını ardınızda bırakın ve aşkın muhteşemliğine “hoş geldin” deyin. İş hayatınızda ise son derece dikkatli ve hassasiyet göstermeniz gereken bir süreçteyken gizliliğe önem vermelisiniz. Boğa burcunda geri hareketine devam eden Merkür transiti ve 21 Mayıs 22:14’te ♐ Yay burcunda gerçekleşecek dolunay enerjisi ile, kişisel konularda ay sonuna kadar gizliliğe önem vermeniz, sırlarınızı başkaları ile paylaşmamanız için sizi uyarıyor.

Mayıs Boğa 2015 (Bu ay her zamankinden dikkatli ve detaycı olmalısınız). Yıldızların öğretmeni Satürn 7. evinizde transitte. Satürn etkisi alt batınla ilgili organlarda hastalıklara yol açabilir. 7. ev eşin evi anlamına geldiği gibi, eşinizin sağlığı ile ilgili konularda da dikkatli olması gerektiği konusunda uyarıcı. Yönetici gezegeniniz Venüs’ün konumu da bu ay için sağlığınızla ilgili konularda uygun değildir. Venüs, Merkür ve Güneş aynı evde; bu yüzden bu ay dinlenmeye vakit ayırmalı, rutin bir sağlık kontrolünden geçmelisiniz.

6 Mayıs 19:30’da Yeni Ay ♉ burcunuzda gerçekleşecek ve yaşadığınız maddi-manevi her türlü olumsuzluğun olumluya dönüşümüne vesile olacak. Özellikle Boğa burcunun 2’nci 10 gününde doğanlar, maddi zorluklar, duygusal konularda yaşanan hayal kırıklıkları, üzüntüler, hastalıklar yerini kazanç, başarı ve aşka bırakacak. Aşk hayatınızda emeğin, gözyaşının, sabrın mükafatını, uğradığınız haksızlıkların yarım kalmışlıkların karşılığını fazlasıyla alacaksınız.

21 Mayıs 22:14’te ♐ Yay burcunda gerçekleşecek dolunay enerjisi ile, iş hayatınızda yılbaşından bu yana devam eden engelleri aşacak imkanlara kavuşacak ve doğru stratejilerle istediğiniz başarıyı yakalayabileceksiniz. Yıldızların öğretmeni Satürn, meslek çıkarları için ahlaksız insanlarla karşılaşıp mücadele etmeniz gereken zorlukları da çıkaracak. Ancak amaçlarına erişemeyecekler; finans ve yatırımlarla ilgili güçlü karar verme yetiniz nedeniyle siz kazanacak olacaksınız. Mars’ın retro geri hareket döngüsü işbirlikleri ya da özellikle Nisan-Mayıs dönemlerinde sözleşmeleri mahvedebilir; dikkatli davranmalısınız. Özel yaşamınızda ise eş ya da sevgilinizin baskın tavırları...