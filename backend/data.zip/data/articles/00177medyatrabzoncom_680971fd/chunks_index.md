# Chunks Index

| ID    | Section                       | Heading Path                  | Char Range | Preview                                                                                       |
| ----- | ----------------------------- | ----------------------------- | ---------- | --------------------------------------------------------------------------------------------- |
| c0000 | Boğa 4 Kişiyi Hastanelik Etti | Boğa 4 Kişiyi Hastanelik Etti | 0-1000     | = Boğa 4 Kişiyi Hastanelik Etti = 24.09.2015 12:17 Başkentte kurban edileceği sırada ipini... |
| c0001 | Boğa 4 Kişiyi Hastanelik Etti | Boğa 4 Kişiyi Hastanelik Etti | 800-1374   | dından uyuşturucu iğneyle vurularak sakinleştirildi.                                          |