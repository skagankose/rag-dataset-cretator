---
id: 00177medyatrabzoncom_680971fd
url: file://00177_medyatrabzon_com.md
title: 00177 medyatrabzon com
lang: en
created_at: '2025-12-19T23:01:34.562178'
checksum: 92ddf009d6c82434757feca40c55914d6fb60cb8d4209feec05196f2cd4ef2fa
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 181
  char_count: 1374
  num_chunks: 2
  num_sections: 1
---
= Boğa 4 Kişiyi Hastanelik Etti =

24.09.2015 12:17  

Başkentte kurban edileceği sırada ipini kopararak kaçan boğa, 3.5 saatlik kovalamaca sırasında 4 kişiyi hastanelik etti. Başkentte kurban edileceği sırada ipini kopararak kaçan boğa, 3.5 saatlik kovalamaca sırasında 4 kişiyi hastanelik etti.  

Uyuşturucu iğneyle sakinleştirilen boğa sahiplerine teslim edildi. Olay, sabah saatlerinde Çankaya ilçesi Öveçler Mahallesi'nde meydana geldi.  

Kurban edileceği sahiplerinin ipini koparan boğa Lizbon Caddesi üzerinde trafiği altüst etti. İhbar üzerine olay yerine gelerek boğa sahipleriyle beraber kaçan boğanın peşine düşen polisler ekipleri 3.5 saat ter döktü.  

Yakalamak için önünü kesen vatandaşlara da saldıran boğa, olay yerine gelen kurban yakalama timi tarafından uzun süren çalışmanın ardından uyuşturucu iğneyle vurularak sakinleştirildi. Uzun süren koşuşturmanın sırasında 1'i polis 4 kişiyi yaralayan boğa, sahiplerine teslim edildi.  

Kurbanlık boğanın ortaklarından Şentürk Acar, sabah namazının ardından kurbanı pazardan alarak getirdiklerini belirtti. Acar, "Demire bağladık ancak ipi kopardı gitti. Garaj çıkışında barikat kurduk ama bariyeri de kırarak kaçtı. Cadde üzerinde bir aşağı bir yukarı gitti. Yoldan geçen 4 kişiyi hafif şekilde yaraladı. Bir tane de polis yaralandı. Belediye ekipleri geldi ve hayvanı uyuşturdu. Sonunda da yakaladık" dedi.