---
id: 01825elbistaninsesic_df9bb0ee
url: file://01825_elbistaninsesi_com.md
title: 01825 elbistaninsesi com
lang: en
created_at: '2025-12-19T23:56:06.539077'
checksum: 0919b2a4049a4ef6a00fb686b79a4267acc4b3ee6419a781e087b26a7db262d9
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 284
  char_count: 2283
  num_chunks: 3
  num_sections: 1
---
= Elbistan Adliyesine Temizlik Personeli Alınacak =

Adalet Bakanlığı, temizlik personeli görevi için 1287 kişilik alım gerçekleştirecek. KPSS şartının aranmayacağı personel alımında Elbistan Adliyesi'ne 4 kişi alınacak. Adalet Bakanlığı Personel Genel Müdürlüğü taşra teşkilatında görevlendirilmek üzere 1287 temizlik görevlisi alınacak.

Resmi Gazete'de yayımlanan ilana göre, başvurular 8 Mart'a kadar Türkiye İş Kurumu’nun (İŞKUR) internet sitesi üzerinden gerçekleştirilecek. Adaylar, İŞKUR tarafından yayımlanan listeden sadece bir il için başvuru yapabilecek. İlan edilen temizlik görevlisi kadrosuna sadece bu illerde ikamet edenler başvuru yapabilecek.

İŞKUR tarafından gönderilen listede yer alan adayların kura çekimi 17 Mart Çarşamba günü saat 11.00'de Adalet Bakanlığı Personel Genel Müdürlüğü Toplantı Salonu'nda noter huzurunda gerçekleştirilecek. Adaylar, Türkiye'yi de etkisi altına alan yeni tip koronavirüs (Covid‑19) salgını nedeniyle kura çekimine katılamayacak. Kura çekilişi, Adalet Bakanlığı Personel Genel Müdürlüğünün sosyal medya sayfasından canlı olarak yayınlanacak ve görüntüleri kayda alınacak.

Adalet Bakanlığı, Kahramanmaraş genelindeki adliyeler için toplam 12 personellik kadro ayırdı. Elbistan Adliyesi'ne 4, Afşin Adliyesi'ne 2, Andırın Adliyesi'ne 2 ve Kahramanmaraş Adliyesi'ne de 4 temizlik personeli alınacak.

Başvuru yapan adaylardan ise, ilan tarihi itibarıyla 18 yaşını tamamlamış olmak, herhangi bir sosyal güvenlik kurumundan emeklilik, yaşlılık veya malullük aylığı almamış olmak, affa uğramış olsa bile devletin güvenliğine karşı suçlar, anayasal düzene ve bu düzenin işleyişine karşı suçlar, millî savunmaya karşı suçlar, devlet sırlarına karşı suçlar ve casusluk, zimmet, irtikâp, rüşvet, hırsızlık, dolandırıcılık, sahtecilik, güveni kötüye kullanma, hileli iflas, ihaleye fesat karıştırma, edimin ifasına fesat karıştırma, suçtan kaynaklanan malvarlığı değerlerini aklama veya kaçakçılık suçlarından mahkûm olmamak, kamu kurum ve kuruluşlarından herhangi bir sebeple görevinden veya mesleğinden ihraç edilmemiş olmak, ilan tarihi itibarıyla başvuru yapılan ilde ikamet ediyor olmak şartları istenecek. Ayrıca, en az ilköğretim ve dengi okul mezunu, ilan tarihi itibarıyla 35 yaşını bitirmemiş olanların başvurusu kabul edilecek.