# Chunks Index

| ID    | Section                                         | Heading Path                                    | Char Range | Preview                                                                                             |
| ----- | ----------------------------------------------- | ----------------------------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Elbistan Adliyesine Temizlik Personeli Alınacak | Elbistan Adliyesine Temizlik Personeli Alınacak | 0-1000     | = Elbistan Adliyesine Temizlik Personeli Alınacak = Adalet Bakanlığı, temizlik personeli görevi...  |
| c0001 | Elbistan Adliyesine Temizlik Personeli Alınacak | Elbistan Adliyesine Temizlik Personeli Alınacak | 800-1800   | dürlüğü Toplantı Salonu'nda noter huzurunda gerçekleştirilecek.                                     |
| c0002 | Elbistan Adliyesine Temizlik Personeli Alınacak | Elbistan Adliyesine Temizlik Personeli Alınacak | 1600-2283  | zene ve bu düzenin işleyişine karşı suçlar, millî savunmaya karşı suçlar, devlet sırlarına karşı... |