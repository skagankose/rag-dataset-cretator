---
id: 03955futbolarenacom_c5029a23
url: file://03955_futbolarena_com.md
title: 03955 futbolarena com
lang: en
created_at: '2025-12-20T00:36:20.555029'
checksum: 248bf0bf0c41ed091381f27d09cc4d627be9c6c73326c22839602162ef4891e3
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 92
  char_count: 656
  num_chunks: 1
  num_sections: 1
---
= Celtic'in eski hocasından Fenerbahçe yorumu =

09 Eylül 2015, Çarşamba 09:18

Celtic'in eski teknik direktörlerinden Neil Lennon, İskoç ekibinin Avrupa Ligi'ndeki grubunu değerlendirdi. FutbolArena - UEFA Avrupa Ligi'nde Fenerbahçe ile aynı grupta mücadele edecek olan Celtic'in eski hocası Neil Lennon grubu yorumladı.

"Fenerbahçe önemli yatırımlar yaptı" Sabah Gazetesi'ne konuşan Lennon, "Celtic için ağız sulandıran bir grup. Bu Ronny Deila ve futbolcuları için iyi bir şey. Celtic'in üst tura çıkma şansı yüksek. Ajax eskisi kadar güçlü değil. Fenerbahçe önemli yatırımlar yaptı. Molde ise hem içeride hem de dışarıda yenilebilecek bir takım" dedi.