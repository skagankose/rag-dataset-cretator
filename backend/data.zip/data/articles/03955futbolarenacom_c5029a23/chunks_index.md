# Chunks Index

| ID    | Section                                     | Heading Path                                | Char Range | Preview                                                                                                |
| ----- | ------------------------------------------- | ------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Celtic'in eski hocasından Fenerbahçe yorumu | Celtic'in eski hocasından Fenerbahçe yorumu | 0-656      | = Celtic'in eski hocasından Fenerbahçe yorumu = 09 Eylül 2015, Çarşamba 09:18 Celtic'in eski teknik... |