# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                            |
| ----- | ------- | ------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Ahu Kız Almanya'dan bildiriyor: Gittim: Münih, arkadaşlarımın düğünü 25 Mayıs 2013 gününü düğün... |
| c0001 | Lead    | Lead         | 800-1800   | n fotoğrafı vardı.                                                                                 |
| c0002 | Lead    | Lead         | 1600-2600  | .                                                                                                  |
| c0003 | Lead    | Lead         | 2400-3014  | alarını bulduktan sonra puzzle'yi tamamladıktan sonra böylece balayına gitmek istedikleri...       |