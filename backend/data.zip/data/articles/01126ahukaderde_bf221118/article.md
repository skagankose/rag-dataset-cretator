---
id: 01126ahukaderde_bf221118
url: file://01126_ahukader_de.md
title: 01126 ahukader de
lang: en
created_at: '2025-12-19T23:32:48.538353'
checksum: e882661a7804489b2935be7caa3168ad045c52c29e6c1046b855111137bce45f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 396
  char_count: 3014
  num_chunks: 4
  num_sections: 1
---
Ahu Kız Almanya'dan bildiriyor: Gittim: Münih, arkadaşlarımın düğünü 25 Mayıs 2013 gününü düğün günü olarak seçen arkadaşlarımız düğünü Münih'te gerçekleştirdi. Cumartesi sabah yediyi çeyrek gece araba ile yola çıktık. Trafik fazla sıkışık değildi. Yer yer tıkanıklıklar oldu, bu da şampiyonlar liginin final maçını Münih'te seyretmek için giden futbolseverlerdi.

Yolda iki kere mola verip kahve ihtiyacımızı giderdik ve 11'de oteldeydik. Check‑in yaptık ve herkes hazırlanmaya başladı. Çünkü saat ikide kilisede olmamız gerekiyordu. Arkadaşlarımızın dini nikâhı kıyılacaktı. Otel odam harikaydı. Düğünden sonra harika bir uyku çektim, iki saatçik olsa bile.

Kilisede nikah kıyıldıktan sonra herkes kutlamanın olacağı restorana geçti ve orada elimize ufak balonlar verdiler. Balonların ucunda çiftin fotoğrafı vardı. Havanın soğuk olmasına rağmen mantarların verdiği sıcaklık sayesinde restoran bahçesinde ayakta sohbet edildi. Sonra hepimiz birlikte sokağa çıkıp elimizdeki balonları gökyüzüne bıraktık ve çiftimiz için güzel dileklerde bulunduk.

Çiftimiz Alman geleneklerine göre büyük bir kumaşın üzerine kalp şekli dikiliyor ve kalbin içine çiftin adı ve düğün tarihi yazılıyor, sonra bu kalbi çift birlikte kesiyor. Kim kendi yarımını daha çabuk bitirirse kazanıyor. Sonra çift kalbin içinden geçiyor. Uğur getirdiğine inanılıyor. Fotoğraflardan da anlaşılacağı üzere gelin kendi yarımını daha çabuk keserek kazandı.

Bütün bu etkinliklerden sonra restorana geçtik ve çiftimiz pastasını kesti ve ayakta kahve eşliğinde pasta yedik. Pastadan sonra akşam yemeği için düzenlenmiş masalara geçtik. Masalar çok güzel süslenmişti. Masalarda camlar vardı. Çamların içinde su vardı ve taze güller. Her yer çok güzel kokuyordu.

Alman düğünlerinde sevdiğim bir özellik ise nerede oturacağınızın belli olması. Çünkü çift, kimin kiminle bir arada oturması gerektiğine karar veriyor ve böylece genellikle tanıdığınız arkadaşlarınızın yanına düşüyorsunuz. İsimler güzel kurdaleler üzerine yazılmıştı ve bunlar da şarap bardaklarımıza yerleştirilmişti. Hatıra olarak kurdalemi aldım tabi ki.

Hepimizin önünde ufak bir kese vardı. Kesenin içinde puzzle parçaları vardı ve herkes puzzle parçalarını birleştirip büyük bir puzzle'yi tamamladı. Bittiğimizde sonunda sadece iki parça vardı ve bu parçalar Susanne ve Philipp'e aitti. Bu parçacıkları bulmak zorundaydılar. Çamların önünde bulunan bir saksıda parçalarını bulduktan sonra puzzle'yi tamamladıktan sonra böylece balayına gitmek istedikleri Amerika’dan bir tabloya sahip oldular.

Bir gün Amerika'ya muhakkak gitmek istedikleri için bunun için para biriktiren çifte biz de arkadaşlar ile birlikte bir cam kasenin içinde hamurdan ada yaptık ve onlara hediye edeceğimiz paralar ile bu kaseyi süsledik. Sandallar, palmiyeler, şemsiyeler yaptık. Çok tatlı oldu.

Yemekler de harikaydı. Davetiyelerini gönderdiklerinde nasıl yemek tercih ettiğimizi de soran arkadaşlarıma vejetaryen yemekleri istediğimi bildirmiştim. Böylece domuz eti sunulmayacağından emin oldum ve ma