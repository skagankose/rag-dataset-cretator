# Dataset: 03239 teknoblog com

Generated on: 2025-12-20T00:24:30.395165
Total questions: 1

| # | Question                                                        | Answer         | Category | Related_Chunk_IDs |
| - | --------------------------------------------------------------- | -------------- | -------- | ----------------- |
| 1 | Carl Pei'nin yeni girişimi için sağladığı kaynak miktarı nedir? | 7 milyon dolar | FACTUAL  | c0000             |