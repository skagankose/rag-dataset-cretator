---
id: 03239teknoblogcom_54ef2120
url: file://03239_teknoblog_com.md
title: 03239 teknoblog com
lang: en
created_at: '2025-12-20T00:24:24.578194'
checksum: c607eb8630411321329338648854d53b6335db724b25215496582efa6d8e98dc
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 148
  char_count: 1013
  num_chunks: 1
  num_sections: 1
---
= OnePlus kurucusu yeni girişimi için 7 milyon dolar topladı - Teknoblog =

== OnePlus kurucusunun yeni girişimi önemli isimlerden destek aldı ==

10 Aralık 2020 10:28

OnePlus kurucularından CarlPei bundan yaklaşık iki ay önce yeni bir donanım girişimini hayata geçirmek için şirketten ayrılmıştı. Pei'nin yeni girişimi için işler oldukça hızlı ilerliyor gibi görünüyor.

Carl Pei, yeni girişimi için şimdiden 7 milyon dolar kaynak sağladı. Pei'nin girişiminin destekçileri arasında teknoloji dünyasının yakından tanıdığı isimler de bulunuyor. Bu tanınmış isimler şu şekilde sıralanıyor: Tony Fadell – Future Shape kurucusu ve iPod'un mucidi Kevin Lin – Twitch kurucusu Steve Huffman – Reddit CEO'su Liam Casey – PCH kurucusu ve CEO'su Paddy Cosgrave – Web Summit kurucusu Josh Buckley – Prodcut Hunt CEO'su

OnePlus kurucusunun yeni girişimi, Londra'da bir ofis açacak. Mevcutta 10 çalışanı olan şirket yeni personel alımı da yapacak. Projenin teknik detayları konusunda ise şimdilik somut bir bilgi bulunmuyor.