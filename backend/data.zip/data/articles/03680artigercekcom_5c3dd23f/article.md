---
id: 03680artigercekcom_5c3dd23f
url: file://03680_artigercek_com.md
title: 03680 artigercek com
lang: en
created_at: '2025-12-20T00:31:45.551638'
checksum: 2f531db3f7341ff544e66a572310ef4ff5d5032a636e1b4eb2e0e2f208218f53
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 186
  char_count: 1355
  num_chunks: 2
  num_sections: 1
---
= Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı =

*Artı Gerçek 07.08.2020 - 15:43 - 'Bildiğinizden daha fazlası'*

Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı. Akit TV ekranından hilafet çağrısı yapıldı. 12.07.2020 - 16:45 Güncelleme: 12.07.2020 - 16:45. 2020-07-12 16:45:50 Danıştay 10. Dairesi, Ayasofya'nın camiden müzeye dönüştürülmesine dair 24 Kasım 1934 tarihli Bakanlar Kurulu kararını iptal etti. 24 Temmuz'da ilk kitlesel namazın kılınacağı açıklanırken, Akit TV'den hilafet ilanı çağrısı geldi. 'BUNUN ARKASINA BİR HİLAFET GELMELİ' Akit TV'de Fatin Dağıstanlı'nın sunduğu Pazar Manşeti programında ise dikkat çeken sözler sarf edildi. Musa Biçkioğlu'nun konuk edildiği programda Ayasofya konusu ele alındı. Fatin Dağıstanlı, Ayasofya ile ilgili olarak, "Şu mesaj önemliydi. Bunun arkasına bir Hilafet gelmeli. Ben bunu önemsiyorum çünkü. Ki siz çok iyi analiz ettiniz. 'KURTULMANIN ZAMANI GELDİ' Bunun hem siyasal hem ekonomik çok büyük bir getirisi de olacak. Hem de ümmet için de önemli bir gelişme olacak" ifadelerini kullanırken, Musa Biçkioğlu ise, "Bir Hilafet müessesemiz vardı, der Müslümanlar bizimle karşılaştıklarında. Siz bu Hilafet müessesesini evet taşıdınız, hakkını verdiniz ama yok ettiniz, ortadan kaldırdınız diye bir suçlama da var bize yönelik. Bu suçlamadan kurtulmanın zamanı da geldi" diye belirtti.