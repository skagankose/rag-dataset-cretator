# Chunks Index

| ID    | Section                                                | Heading Path                                           | Char Range | Preview                                                                                         |
| ----- | ------------------------------------------------------ | ------------------------------------------------------ | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı | Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı | 0-1000     | = Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı = *Artı Gerçek 07.08.2020 - 15:43 -... |
| c0001 | Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı | Akit'i Ayasofya kararı kesmedi hilafet çağrısı yapıldı | 800-1355   | iydi.                                                                                           |