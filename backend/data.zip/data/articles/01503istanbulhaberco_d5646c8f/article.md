---
id: 01503istanbulhaberco_d5646c8f
url: file://01503_istanbulhaber_com_tr.md
title: 01503 istanbulhaber com tr
lang: en
created_at: '2025-12-19T23:45:22.574643'
checksum: 813f794328f6dcddf0f3f68d9fd09e63135e0559e6263d7d0a7001d5a44824ca
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 208
  char_count: 1657
  num_chunks: 2
  num_sections: 1
---
Fenerbahçe'de gündem derbi değil, kokoreç. F.Bahçe Başkanı, her zaman gittiği kokoreççiye bu kez oyuncuları götürdü. Kuyt, daha önce hiç yemediği kokoreçe bayıldığını söyleyince arkadaşları, "Avrupa Birliği milli yiyeceğimize artık itiraz edemez" diye espri yaptı.

Fenerbahçe Başkanı Aziz Yıldırım, Çengelköy esnafının isteğini kıramayarak futbolcuları ile birlikte önceki akşam Çengelköy'de kokoreç yedi. Samandıra'ya giderek isteyen futbolcunun gelebileceğini söyleyen Yıldırım'ın davetine, Volkan, Emre, Kuyt, Mehmet Topuz, Selçuk'un yanı sıra teknik direktör Ersun Yanal ve menajer Hasan Çetinkaya da katıldı…

Çengelköy kokoreççisinde gözler Kuyt'ın üzerindeydi. AB Birliği'ne giriş sürecinde tartışması yapılan kokoreci tadan Kuyt beğenisini dile getirdi. NEŞELİ AKŞAM Kuyt kokoreçi beğenmekle kalmadı, paket yaptırarak ailesine de götürdü. Kuyt'ın kokoreci bu kadar sevmesi, "Kokoreç sonunda Avrupa Birliği'ne girdi" esprilerine neden oldu.

Sarı lacivertli futbolcular kokoreç yedikten sonra Çengelköy Sütiş'e giderek tatlı yediler. Son derece neşeli geçen akşamda futbolcular ve başkan Aziz Yıldırım yapılan esprilerle sık sık kahkahalar attı. F.Bahçeliler daha sonra Çengelköy sahilinde çay içti.

Gittikleri kokoreççide kaptan Emre ile birlikte poz veren başkan Aziz Yıldırım gece boyunca futbolcuları ile yakından ilgilendi. Sürekli, "doydunuz mu, beğendiniz mi?" diye soran başkan Yıldırım'ın babacan tavırları, oldukça neşeli bir akşam yaşanmasını sağladı.

Etiketler: kuyt, kokoreç, fenerbahçe, derbi, gündem Sneijder'e milli takımda jübile maçı. Bir dönem Galatasaray'da da görev yapan Hollandalı Sneijder, milli takımda jübilesini yapacak.