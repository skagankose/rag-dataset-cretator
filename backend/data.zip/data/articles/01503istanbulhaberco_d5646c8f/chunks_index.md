# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                        |
| ----- | ------- | ------------ | ---------- | ---------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Fenerbahçe'de gündem derbi değil, kokoreç.     |
| c0001 | Lead    | Lead         | 800-1657   | kalmadı, paket yaptırarak ailesine de götürdü. |