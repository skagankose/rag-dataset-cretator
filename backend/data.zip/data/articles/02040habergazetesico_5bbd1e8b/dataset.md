# Dataset: 02040 habergazetesi com tr

Generated on: 2025-12-20T00:03:26.596717
Total questions: 1

| # | Question                                                                                                 | Answer                                                                                      | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | -------- | ----------------- |
| 1 | Semih Yalçın bir seçim azınlık hükümetine hangi koşullar gerçekleşirse destek verebileceklerini söyledi? | Koalisyon alternatifleri tamamen tükenirse ve Kasım ayında erken seçim yapılması koşuluyla. | FACTUAL  | c0000             |