# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                             |
| ----- | ------- | ------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-719      | 04 Ağustos 2015 03:56 Reuters'ın sorularını yanıtlayan MHP Genel Başkan Yardımcısı Semih Yalçın,... |