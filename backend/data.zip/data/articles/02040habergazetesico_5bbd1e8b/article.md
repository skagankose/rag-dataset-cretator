---
id: 02040habergazetesico_5bbd1e8b
url: file://02040_habergazetesi_com_tr.md
title: 02040 habergazetesi com tr
lang: en
created_at: '2025-12-20T00:03:17.558202'
checksum: 8f4bd064eb29052802e50128c1b4b3156d7fcaee84234ebe3f9b7551ee4790e5
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 95
  char_count: 719
  num_chunks: 1
  num_sections: 1
---
04 Ağustos 2015 03:56 Reuters'ın sorularını yanıtlayan MHP Genel Başkan Yardımcısı Semih Yalçın, AKP'nin alelade kuracağı bir azınlık hükümetine destek vermeyeceğiz ama eğer burada seçim azınlık hükümetini kastediyorlarsa, bu durumda da seçim tarihinin görülmesi lazım. Kasım da ya da başka tarihte seçim yapılıp yapılmayacağının baştan belirlenmesi gerekiyor dedi ve şöyle devam etti: Bu teklifi görmeden destek yaklaşımı doğru olmaz. Koalisyon alternatifleri tamamen tükenirse, Kasım ayında erken seçim yapılması koşuluyla bir seçim azınlık hükümetine destek verebiliriz. MHP, Kasım ayına sıcak bakar. samsun samsun haber samsunspor haber gazetesi samsunhaber mhp genel başkan yardımcısı semih yalçın azınlık hükümeti