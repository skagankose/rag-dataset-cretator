# Chunks Index

| ID    | Section                                                   | Heading Path                                              | Char Range | Preview                                                                                          |
| ----- | --------------------------------------------------------- | --------------------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------ |
| c0000 | Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da | Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da | 0-1000     | = Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da = 25 Nisan 2018, Çarşamba 14:50 –... |
| c0001 | Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da | Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da | 800-1065   | uz.                                                                                              |