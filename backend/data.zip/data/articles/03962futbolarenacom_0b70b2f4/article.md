---
id: 03962futbolarenacom_0b70b2f4
url: file://03962_futbolarena_com.md
title: 03962 futbolarena com
lang: en
created_at: '2025-12-20T00:36:27.548950'
checksum: 9aa1585f360768a09e33da29455333f157e4614cf267f51f7d11a95496d4ad36
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 129
  char_count: 1065
  num_chunks: 2
  num_sections: 1
---
= Trabzonspor'da Önder Bülbüloğlu, şike davası için FIFA'da =

25 Nisan 2018, Çarşamba 14:50 – Trabzonspor Başkan Yardımcısı Önder Bülbüloğlu, FIFA'da devam eden şike davasıyla ilgili Zürih'e gitti.

FutbolArena – Trabzonspor Başkan Yardımcısı Önder Bülbüloğlu, FIFA'da devam eden şike davasıyla ilgili Zürih'e gitti.

Bülbüloğlu, FIFA'daki temaslarının ardından Trabzonsporlu taraftarlarla sohbet etti.

Önder Bülbüloğlu'nun FIFA'ya yaptığı ziyaret kapsamında, FIFA merkezine giderek şike davasıyla ilgili çeşitli temaslarda bulundu.

Bülbüloğlu, temaslarının sonrasında FIFA genel merkezinin karşısında “Adalet Nöbeti” tutan taraftarlarımızla da sohbet etti.

Önder Bülbüloğlu, “Trabzonspor Kulübü olarak hukuk mücadelemizi sürdüreceğiz. Dosyamız şu anda FIFA'da. Bir an önce sonuçlanmasını istiyoruz. Çünkü adalet bekleyen ve Türkiye'de temiz futbolu özleyen bir camia var” dedi.

FIFA binasının önünde bekleyen taraftarları da vurgulayan Bülbüloğlu, “Taraftarlarımız mücadelemizde güçlü ve kararlı. Kendilerine teşekkür bir borç biliyoruz” ifadelerini kullandı.