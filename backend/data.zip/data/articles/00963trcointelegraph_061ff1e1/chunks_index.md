# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                            |
| ----- | ------- | ------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | BTC ₺351.832 ETH ₺20.388 UNI ₺92,41 YFI ₺109.070 BAND ₺23,34 SNX ₺45,21 BTC ₺351.832 +1,42% ETH... |
| c0001 | Lead    | Lead         | 800-1624   | anlandığını açıkladı: "Yasa dışı finansla mücadele, ekonomik suçları azaltma ve işletmelerin...    |