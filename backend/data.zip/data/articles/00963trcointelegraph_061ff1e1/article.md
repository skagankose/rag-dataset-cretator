---
id: 00963trcointelegraph_061ff1e1
url: file://00963_tr_cointelegraph_com.md
title: 00963 tr cointelegraph com
lang: en
created_at: '2025-12-19T23:27:34.536973'
checksum: 8345fa19ca9cf513823dcc7ae9e57aaa1c03a3a66d39d5ff432378a1c7571f6a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 203
  char_count: 1624
  num_chunks: 2
  num_sections: 1
---
BTC ₺351.832 ETH ₺20.388 UNI ₺92,41 YFI ₺109.070 BAND ₺23,34 SNX ₺45,21  
BTC ₺351.832 +1,42% ETH ₺20.388 +4,31% BNB ₺4.108 +3,76% SOL ₺628 +2,81% XRP ₺5,71 +2,75% DOGE ₺1,18 +2,46%

Birleşik Krallık Hazine Bakanlığı, iddiaya göre stablecoin'leri yasal ödeme aracı olarak düzenleme kararı aldı. Birleşik Krallık Hazine Bakanlığı, iddiaya göre stablecoin'leri yasal ödeme aracı olarak düzenleme kararı aldı. Bu karar kripto topluluğunda hoş karşılansa da, en popüler algoritmik stablecoin'lerden biri olan TerraUSD'nin (UST) çöküşüne yakıınlığı nedeniyle şok etkisi yarattı.

The Telegraph'ın haberine göre Prens Charles, çeşitli sektörlerde stablecoin'leri düzenlemek için getirilecek yeni yasalar ile bölgenin yaşam standarlarını iyileştirecek ekonomik büyümeyi destekleyecek önlemler alınmasının planlandığını açıkladı: "Yasa dışı finansla mücadele, ekonomik suçları azaltma ve işletmelerin büyümesine yardımcı olma gücümüzü daha da artırmak için yeni bir yasa getirilecek."

Bakanlık, 4 Nisan'da mevcut yasal çerçeveleri güncelleyerek stablecoin'leri de ödeme aracı olarak dahil edeceğinin sinyallerini vermişti. Terra ekosisteminde LUNA ve UST fiyatlarının toparlanamayacak ölçüde düşmesine yol açan çöküşün düzenleyicileri tedirgin etmesi beklenirken, Birleşik Krallık Hazine Bakanlığı "ülkenin finansal hizmetler sektörünün her zaman teknoloji ve inovasyonun ön saflarında yer alabilmesini sağlamak" için planına devam ediyor.

Diğer yandan bakanlık, algoritmik stablecoin'leri yasallaştırmayı planlamıyor ve bunun yerine Tether (USDT) veya USD Coin (USDC) gibi 1:1 desteklenen stablecoin'leri tercih etmeyi düşünüyor.