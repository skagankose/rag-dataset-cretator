---
id: 01719emlakkulisicom_ff69c8db
url: file://01719_emlakkulisi_com.md
title: 01719 emlakkulisi com
lang: en
created_at: '2025-12-19T23:52:35.541218'
checksum: a79b2220ee5994c2f31a9b1ec2dfc214d5a34c6e7d2769a182a7cd24d2507d9e
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 339
  char_count: 2590
  num_chunks: 3
  num_sections: 1
---
= Marmara Park AVM Beylikdüzü'nde inşa ediliyor! =

İstanbul'un Avrupa yakasında Avrupa'nın en büyük AVM'lerinden biri yükseliyor – ECE Türkiye'nin gerçekleştirdiği projenin hacmi 220 milyon Euro. Galaksi; yepyeni ve benzersiz bir alışveriş konsepti. Marmara Park ile İstanbul ilk galaksi temalı alışveriş merkezine sahip olacak.

Yaklaşık 100.000 metrekarelik brüt kiralanabilir alan ve ortalama 4.000 araçlık otoparkı ile Marmara Park Alışveriş Merkezi (AVM), İstanbul'un Beylikdüzü / Esenyurt bölgesinde inşa edilecek. Tanınmış Türk markaları ve uluslararası markalara ev sahipliği yapacak alışveriş merkezinde 250'den fazla mağaza, dev bir hipermarket, bir yapı market, çok büyük bir elektronik mağazası, sinema, eğlence parkı ve hazır giyim mağazaları bulunacak.

Ocak 2011'de ECE Türkiye'nin inşaatına başlayacağı Marmara Park Alışveriş ve Eğlence Merkezi, İstanbul'un en işlek karayollarından biri olan E‑5 karayolu üzerinde konumlanıyor. Alışveriş merkezi, tüm hedef kitlelere uygun oluşturulan perakende mağaza karması ve farklı eğlence olanakları ile hem çocuklara hem de yetişkinlere ulaşmayı hedefliyor.

ECE Türkiye Genel Müdürü Andreas Hohlmann, “Marmara Park AVM sadece Türkiye'de değil tüm Avrupa'da örnek bir alışveriş merkezi projesi olacak. Galaksi ile yeni bir alışveriş merkezi teması sunuyoruz. Marmara Park'ta ‘Lunaryum’, ‘Solaryum’ ve ‘Galaksi Köprüsü’ olarak adlandırılan çeşitli bölümler bulunacak.” şeklinde konuştu. AVM'nin açılışı 2012 sonbaharında gerçekleşmesi planlanıyor.

Basın toplantısında konuşan İş GYO Genel Müdürü Turgay Tanes, kurum kültürlerinin büyük uyum içinde olduğu ECE Türkiye ile çok önemli bir proje geliştirdiklerini belirterek, “Beylikdüzü / Esenyurt bölgesindeki artan nüfusun ihtiyaçlarının karşılanması ve istihdam sağlanması gibi konularda rol oynayacağına inandığımız böyle bir projenin parçası olmak da bizi mutlu ediyor.” dedi.

“AVM'nin mükemmel konum ve erişimi ile müşterilerin bölgeyi çok iyi tanıması da bu eşsiz projede bizim için başarıyı garantileyen unsurlardan.” diyerek sözlerini sürdüren Hohlmann, Türkiye'de bir on yıl daha değil, sürekli olarak kalmak istediklerini, Türkiye'nin 72 milyon nüfusuna her yıl eklenen 500 bin kişi ile AVM yatırımları için son derece cazip bir pazar olduğunu ifade etti. Her binanın AVM olamayacağını, bunun için belli bir kaliteyi tutturmanın önemine de dikkat çeken Hohlmann, her şehire AVM yapılmak zorunda olmadığını, İstanbul'dan Van'a, Antalya'dan Kayseri'ye bütün şehirlerin dinamiğinin farklı olduğunu, yatırım için her birinin ayrıca analiz edilmesi gerektiğini sözlerine ekledi.