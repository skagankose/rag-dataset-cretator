# Chunks Index

| ID    | Section                                        | Heading Path                                   | Char Range | Preview                                                                                                |
| ----- | ---------------------------------------------- | ---------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | 0-1000     | = Marmara Park AVM Beylikdüzü'nde inşa ediliyor!                                                       |
| c0001 | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | 800-1800   | şaatına başlayacağı Marmara Park Alışveriş ve Eğlence Merkezi, İstanbul'un en işlek karayollarından... |
| c0002 | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | Marmara Park AVM Beylikdüzü'nde inşa ediliyor! | 1600-2590  | çinde olduğu ECE Türkiye ile çok önemli bir proje geliştirdiklerini belirterek, “Beylikdüzü /...       |