# Dataset: 02917 kadinlarkulubu com

Generated on: 2025-12-20T00:19:09.122428
Total questions: 1

| # | Question                                                                                 | Answer                           | Category | Related_Chunk_IDs |
| - | ---------------------------------------------------------------------------------------- | -------------------------------- | -------- | ----------------- |
| 1 | Kadınlar Kulübü'nün metinde en beğendikleri çift isimli kız bebek isimleri hangileridir? | Işık Ada, Elif Ece, Zeynep Defne | FACTUAL  | c0000             |