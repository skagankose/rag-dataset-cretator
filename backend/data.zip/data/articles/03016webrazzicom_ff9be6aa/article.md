---
id: 03016webrazzicom_ff9be6aa
url: file://03016_webrazzi_com.md
title: 03016 webrazzi com
lang: en
created_at: '2025-12-20T00:20:41.552291'
checksum: c2b6fe298d4538746310ea09600f800860e0ad69f0f533fbe16562eefd56547c
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 256
  char_count: 1997
  num_chunks: 3
  num_sections: 1
---
= Obama, dijital devlet için gözünü Silikon Vadisi yeteneklerine çevirdi =

Silikon Vadisi'nin doğduğu topraklarda da halen bürokrasi var ve devlete bağlı işlerde yeterli dijital dönüşüm tam anlamıyla sağlanmış değil. Ancak ABD Başkanı Barack Obama, devletin dijital servislerini daha iyi bir noktaya getirmek için Silikon Vadisi'nin büyük teknoloji şirketlerinden yetenekleri bünyesine katmak isediğini bir kez daha dile getiriyor.

United States Digital Service (USDS), ABD'de devlet hizmetlerin dijital dönüşümünü sağlayan kurum olarak biliniyor ve Obama'nın dijital dönüşüme gösterdiği ilgiyle USDS tarafında projeler daha hızlı ilerliyor. Silikon Vadisi'nde deneyim sahibi olan CTO'larla (teknoloji danışmanlarıyla) çalışan Obama, Fast Company'ye verdiği röportajda bu dönüşümü hızlandırmak istediğini söylüyor.

Obama'nın gözü yetenekli Facebook, Google ve Twitter çalışanlarında Obama, işe alım stratejisi hakkında 'hem teknolojiyi hem de bürokrasiyi kıracak (hack'leyecek) isimlere önem verdiğini söylüyor. Facebook, Google ve Twitter'da gerçekten yetenekli kişilerin olduğunu, bu kişileri önemsediğini ve onların da devletin dijital dönüşümünde yer almak isteyen kişiler olduğunu paylaşıyor.

Hali hazırda Obama'nın teknoloji danışmanlığını da eski Google üst düzey yöneticisi olan Megan Smith yürütüyor. Smith, Google X özel proje biriminde başkan yardımcılığını yürütmüş bir isim ve Smith Obama'nın Silikon Vadisi'nden yaptığı son transfer gibi görünmüyor.

Obama'nın seçim kampanyalarında dijital dünyayı ne kadar iyi kullandığı da konuyla ilgilenenler tarafından pekala iyi biliniyor ve Silikon Vadisi'nin yetenekli isimlerine yeni bir kapı daha açmış oluyor ama tersine transferler olduğunu da belirtmek lazım. ABD eski Dışişleri Bakanı Condoleezza Rice'ın Dropbox yönetim kurulu üyesi olması da sanırım bu konuda gösterilebilecek en iyi örnek.

USDS'nin dijital dönüşümüne katkı sağladığı healthcare.gov farklı sağlık sigortası sağlayıcıları için bir pazar yeri özelliği de sunuyor.