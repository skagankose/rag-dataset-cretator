# Chunks Index

| ID    | Section                         | Heading Path                    | Char Range | Preview                                                                                              |
| ----- | ------------------------------- | ------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Karasu’da Gaziler Günü Kutlandı | Karasu’da Gaziler Günü Kutlandı | 0-1000     | = Karasu’da Gaziler Günü Kutlandı = 19 Eylül Perşembe günü, Karasu Hükümet Konağı'nda düzenlenen...  |
| c0001 | Karasu’da Gaziler Günü Kutlandı | Karasu’da Gaziler Günü Kutlandı | 800-1800   | karşı, 3 kıtada kılıç sallamış, zaferden zafere atlamış, Anadolu'da, Kore'de, Kıbrıs'ta canlarını... |
| c0002 | Karasu’da Gaziler Günü Kutlandı | Karasu’da Gaziler Günü Kutlandı | 1600-2600  | zi burada onurlandıran kahraman gazilerimizin huzurunda saygıyla eğilerek şükranlarımı sunuyorum”... |
| c0003 | Karasu’da Gaziler Günü Kutlandı | Karasu’da Gaziler Günü Kutlandı | 2400-2996  | uğratmıştır.                                                                                         |