---
id: 03823haberlisincom_183416af
url: file://03823_haberlisin_com.md
title: 03823 haberlisin com
lang: en
created_at: '2025-12-20T00:34:08.541670'
checksum: b7c720d200006bf6009c9f51a1db0d8fa15b29e34d7b0c85f49bc53a0c7c401d
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 401
  char_count: 2996
  num_chunks: 4
  num_sections: 1
---
= Karasu’da Gaziler Günü Kutlandı =

19 Eylül Perşembe günü, Karasu Hükümet Konağı'nda düzenlenen çelenk töreni ile Gaziler Günü kutlandı. Saygı duruşu ve İstiklal Marşı'nın okunmasının ardından Karasu Kaymakamı Aziz Mercan, Karasu Belediye Başkanı İshak Sarı ve Türkiye Muharip Gaziler Derneği Karasu Şubesi Başkanı Enver Yıldız, Atatürk Heykeli'ne çelenk bıraktı ve saygı duruşunda bulundu.

Çelenk törenine, siyasi parti temsilcileri, sivil toplum kuruluşu temsilcileri, resmi daire amirleri, askeri erkân ve gaziler katıldı. Günün anlam ve önemini belirten ilk konuşmayı Jandarma Uzman Onbaşı Eray Ergin yaptı.

Ergin konuşmasında; “Tarih boyunca hür ve bağımsız yaşamış Türk Milleti, işgal ve esarete alışık olmayan asil ve büyük bir millettir. Bu uğurda, kendisini çepeçevre sarmış düşmanlarına karşı, 3 kıtada kılıç sallamış, zaferden zafere atlamış, Anadolu'da, Kore'de, Kıbrıs'ta canlarını hiçe sayarak vatan millet bayrak aşkıyla tarihinde birçok savaşa girerek yüzünün akıyla çıkmıştır. Ben, ülkemizi bir çadır gibi görüyorum. Direği şehitlerimiz ve gazilerimiz, örtüsü ise onlardan güç alan Türk ordusudur. Her kim ki bu çadırı yıkmaya yeltenecek olsa, damarlarındaki asil kandan güç alan bu millet topyekûn ona karşı koyacak, bu uğurda gerekirse şehit ve gazi olmayı sizler gibi şeref sayacaktır. Değerli gazilerimiz, unutmayınız ki emanetiniz emanetimizdir. Sizlerin bu vatana sahip çıktığı gibi bizlerde sahip çıkacağız. Başta Gazi Mustafa Kemal Atatürk ve onun silah arkadaşları olmak üzere, bu vatan için toprağa düşmüş şehitlerimizin, ebediyete intikal etmiş olan ve hayatta olup bizi burada onurlandıran kahraman gazilerimizin huzurunda saygıyla eğilerek şükranlarımı sunuyorum” sözlerine yer verdi.

Türkiye Muharip Gaziler Derneği Karasu Şubesi Başkanı Enver Yıldız ise; “1. Dünya Savaşı sonrasında vatanımızı bölerek parçalamak isteyen, yedi düvele mensup düşman vatanımızı dört bir yandan işgal etti. Amaçları Anadolu'da Türk toplumunu tamamen ortadan kaldırmaktı. Tarih boyunca hür ve bağımsız yaşamış, esarete alışık olmayan Türk Milletinin bu işgale dur diyeceği şüphesizdi. Ordumuz, düşmanın ordusunun Anadolu'daki ilerleyişini Başkomutan Mustafa Kemal Atatürk'ün komutasındaki askerlerle durdurmuştur. Türk ordusu 13 Eylül 1921'de 22 gün 22 gece süren dünyanın en uzun ve en kanlı muharebelerinden biri olan Sakarya Meydan Muharebesinde düşmanı tarihinin en büyük bozguna uğratmıştır. Sakarya Meydan Muharebesi'nin zaferle nihayete ermesinin ardından 19 Eylül 1921 tarihinde Türkiye Büyük Millet Meclisi tarafından Mustafa Kemal Atatürk'e Gazilik unvanı ve Mareşal rütbesi verilişiyle birlikte bu tarih Gaziler Günü olarak kutlanmaya başlanmıştır. Bu vesileyle, Başta Gazi Mustafa Kemal Atatürk ve onun silah arkadaşları olmak üzere tüm şehit ve gazilerimizi saygıyla anıyor ve gazilerimizin Gaziler Gününü kutluyorum” dedi.

“Bu cennet vatan bizlere şehitlerimizin ve gazilerimizin emanetidir” diyen Karasu Belediye Başkanı İshak Sarı, tüm gazilerimizin gaziler günü…