# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                           |
| ----- | ------- | ------------ | ---------- | --------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Kaza saat 17.45 sıralarında, Gölcük Değirmendere Dörtyol mevkiinde meydana geldi. |
| c0001 | Lead    | Lead         | 800-1080   | evam ediyor.                                                                      |