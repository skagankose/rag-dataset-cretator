---
id: 03858merhabahabercom_d68414d5
url: file://03858_merhabahaber_com.md
title: 03858 merhabahaber com
lang: en
created_at: '2025-12-20T00:34:43.552691'
checksum: 9e12669fe64cfe4243b9683ccb7a97cb8a77f63009ee721393ec9649521fa044
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 136
  char_count: 1080
  num_chunks: 2
  num_sections: 1
---
Kaza saat 17.45 sıralarında, Gölcük Değirmendere Dörtyol mevkiinde meydana geldi. Buzlanma nedeniyle araçların kayması sonucu ard arda kazalar meydana geldi. Yalova istikametinde yaşanan kazalar nedeniyle 40 araç birbirine çarparken yol ulaşıma kapandı.

Yol savaş alanına dönerken polis ekipleri kazaya müdahalede ederek ambulans istedi. Bölgeye çok sayıda ambulans sevk edilerek yaralılara müdahalede bulundu. İtfaiye ekipleri ise yaralıları araçlardan çıkardı. Yaralanan 16 kişi kaldırıldıkları Gölcük Devlet Hastanesi’nde tedavi altına alındı.

Yalova istikameti ulaşıma kapanırken, trafik ekipleri, ambulans ve kurtarma ekiplerinin çalışması için İzmit istikameti de ulaşıma kapatıldı. Yolun ulaşıma açılabilmesi için kaza yapan araçların yol kenarına çekilmesi ve kaldırılması için çalışmalar devam ediyor.

Gölcük Kaymakamı Adem Yazıcı, kazada 40 aracın birbirine çarptığını belirterek, “Yoldaki buzlanma nedeniyle 40 araç birbirine girdi. Bu araçlar içerisinde TIR, otobüs, otomobil ve kamyonetler bulunuyor. Yaralanan 16 kişi Gölcük Devlet Hastanesi’ne sevk edildi” dedi.