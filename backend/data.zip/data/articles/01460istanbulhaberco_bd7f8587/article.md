---
id: 01460istanbulhaberco_bd7f8587
url: file://01460_istanbulhaber_com_tr.md
title: 01460 istanbulhaber com tr
lang: en
created_at: '2025-12-19T23:43:56.542199'
checksum: cb27ae579f3ecf4f5faa8e98148c7123bb336a841fe8e6cf5fe0d007a3410c0d
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 171
  char_count: 1288
  num_chunks: 2
  num_sections: 1
---
= Cizre'de PKK roketatarla saldırdı: 1 ölü, 3'ü asker 7 yaralı =

Cizre'de PKK roketatarla saldırdı: 1 ölü, 3'ü asker 7 yaralı.

PKK'lılar tarafından Cizre Garnizon Komutanlığı'na yapılan eş zamanlı roketatarlı ve silahlı saldırıda 1 vatandaş öldü, 3'ü uzman asker toplam 7 kişi yaralandı.

Şırnak'ın Cizre ilçesi Nur Mahallesi'nde bulunan Garnizon Komutanlığı'na PKK'lılar tarafından mahalle aralarından roketatarlı ve silahlı saldırı düzenlendi. 4 roketatarın isabet ettiği Garnizon Komutanlığı'nda bulunan askerlerin saldırıya anında karşılık vermesi ile çatışma çıktı.

PKK'lılarla askerler arasında yaklaşık 2 saat süren çatışmada, olayların arasında kalan 39 yaşındaki DEDAŞ elemanı Mesut Sanrı hayatını kaybederken, 3'ü uzman asker toplam 7 kişi yaralandı. Çatışmada yaralanan Maruf Gözüngü (28), Umut Uçun (3), Halil Takin (19) ve ismi öğrenilemeyen bir kişi Cizre Devlet Hastanesi'ne kaldırıldı.

PKK'lılar polis zırhlı aracına da roketle saldırdı. Çatışmanın çıkması ile birlikte Emniyet Müdürlüğü'nden ilçe merkezine gelen 1 polis zırhlı aracına da PKK'lılar tarafından roketatarlı saldırı düzenlendi. Ancak roket mermisi zırhlı aracın yanından geçerek boş bir alana isabet etti.

Çatışma sonrası saldırıyı düzenleyen PKK'lıları yakalamak için geniş çaplı operasyon başlatıldı.