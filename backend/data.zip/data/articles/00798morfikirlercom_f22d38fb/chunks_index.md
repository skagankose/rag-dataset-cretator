# Chunks Index

| ID    | Section              | Heading Path                              | Char Range | Preview                                                                                                |
| ----- | -------------------- | ----------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Franchising Nedir?   | Franchising Nedir?                        | 0-487      | = Franchising Nedir?                                                                                   |
| c0001 | Tarihçe ve Sektörler | Franchising Nedir? > Tarihçe ve Sektörler | 487-1013   | == Tarihçe ve Sektörler == Franchising, sistemin yaratılma ve ilk uygulama yeri olan ABD'de...         |
| c0002 | Terimler             | Franchising Nedir? > Terimler             | 1013-1199  | == Terimler == Lügat manası “imtiyaz” olan **franchise**, İngilizce bir kelimedir.                     |
| c0003 | Franchisor           | Franchising Nedir? > Franchisor           | 1199-1561  | == Franchisor == Franchisor, ürüne, hizmete veya bilgi birikimine ve bunlara ait denenmiş, kalitesi... |
| c0004 | Franchisee           | Franchising Nedir? > Franchisee           | 1561-1980  | == Franchisee == Franchisee, doğrudan veya dolaylı bir malı bedel karşılığında Franchisor’un ticari... |
| c0005 | Ücretlendirme        | Franchising Nedir? > Ücretlendirme        | 1980-2441  | == Ücretlendirme == Franchisee’nin Franchisor’a ödediği bedel; isim, marka veya sistemi kullanma...    |
| c0006 | İşletme Franchisingi | Franchising Nedir? > İşletme Franchisingi | 2441-2910  | == İşletme Franchisingi == Franchising’in bir başka türü işletme franchisingidir.                      |