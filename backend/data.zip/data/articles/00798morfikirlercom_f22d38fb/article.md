---
id: 00798morfikirlercom_f22d38fb
url: file://00798_morfikirler_com.md
title: 00798 morfikirler com
lang: en
created_at: '2025-12-19T23:22:04.526851'
checksum: cf440429455dd34200adcd75db17c1251f0568a6aef5e2eac2e2dfddf727f7bb
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 372
  char_count: 2910
  num_chunks: 7
  num_sections: 7
---
= Franchising Nedir? =

*Ayşegül Ayhan – Morfikirler*  

Franchising bir ürün veya hizmetin imtiyaz hakkına sahip tarafın, belirli bir süre şart ve sınırlamalar dahilinde işin yönetim ve organizasyonuna ilişkin bilgi ve destek sağlamak sureti ile, imtiyaz hakkını ticari işler yürütmek üzere ikinci tarafa verdiği imtiyazdan doğan, uzun dönemli ve sürekli bir iş ilişkilerinin bütünüdür. Franchising, birbirinden bağımsız iki taraf arasında meydana getirilen sözleşmesel bir ilişkidir.

== Tarihçe ve Sektörler ==

Franchising, sistemin yaratılma ve ilk uygulama yeri olan ABD'de başlamıştır. Bu sistemle çalışan yaklaşık 60 iş kolu mevcuttur. Bunlar arasında; otomobil kiralama, otomobil servis ürünleri, iş yardım servisleri, iş araçları, giyim ve ayakkabı, yapı dekorasyon, bilgisayar, kozmetik, perakende satış mağazaları, eğitim, yiyecek, sağlık ürünleri, ev aletleri, kuru temizleme, fast‑food, otelcilik ve lokanta vb. sektörler bulunmaktadır. Özellikle hizmet sektöründe çeşitlendirme hızla artmaktadır.

== Terimler ==

Lügat manası “imtiyaz” olan **franchise**, İngilizce bir kelimedir. Fransızca *Affanchir* olan franchise sözcüğünden “Franchising İmtiyaz Verme” kelimesi türetilmiştir.

== Franchisor ==

Franchisor, ürüne, hizmete veya bilgi birikimine ve bunlara ait denenmiş, kalitesi kanıtlanmış ve başarılı bir markaya, isme sahip ve bunların satış dağıtım veya işletme hakkını belirli bir bedel karşılığı veren taraftır. Franchisor, kendisi ve bireysel franchisee’lerinden oluşan franchising sisteminin kurucusu ve uzun vadeli koruyucusudur.

== Franchisee ==

Franchisee, doğrudan veya dolaylı bir malı bedel karşılığında Franchisor’un ticari adını ve/veya hizmet markasını, know‑how’unu, iş görme ve teknik yöntemlerini, sistemini ve diğer sınai ve/veya fikri mülkiyet haklarını kullanma hak ve zorunluluğunu, taraflar arasında bu amaçla yapılan yazılı Franchise Anlaşması süresi ve kapsamı içinde devamlı olarak alacağı ticari ve teknik destek ile üstlenir.

== Ücretlendirme ==

Franchisee’nin Franchisor’a ödediği bedel; isim, marka veya sistemi kullanma hakkı karşılığında ödenen bir başlangıç ücreti (**Franchisee Fee**) ve yıllık ciro ve kardan, anlaşmada belirlenen oranlarda yüzde olarak ödenen ücretlerden (**Royalty**) oluşur. Royalty, lisans veya ticari marka sahibinin sahip olduğu hakları bir başkasına devretmesi karşılığında aldığı bedelin tam karşılığıdır; Türkçe’de “lisans bedeli” olarak adlandırılır.

== İşletme Franchisingi ==

Franchising’in bir başka türü işletme franchisingidir. Burada franchisee ve franchisor arasında sadece ürün, servis ve marka alanında değil, bir bütün olarak işletme sistemi içerisinde pazarlama ve üretimle ilgili tüm faaliyetler yer alır. Çok basit bir anlatımla, bu tür franchising “akıl satmak” şeklinde tanımlanabilir. Oteller, restoranlar, perakende satış mağazaları, kiralama ve danışmanlık hizmetleri bu sınıflandırma içinde yer alır.