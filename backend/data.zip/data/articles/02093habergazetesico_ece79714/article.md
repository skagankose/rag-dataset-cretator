---
id: 02093habergazetesico_ece79714
url: file://02093_habergazetesi_com_tr.md
title: 02093 habergazetesi com tr
lang: en
created_at: '2025-12-20T00:05:02.522491'
checksum: d34bcbd8e96c73010cfe0da2a4e6bd4f24737e2e8444ab858283d7d57c9c2711
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 240
  char_count: 1999
  num_chunks: 3
  num_sections: 1
---
= Niksar Küçük Sanayi Sitesinde asfalt çalışması başladı =

Tokat'ın Niksar ilçesinde Küçük Sanayi Sitesinde belediye tarafından asfalt kaplama çalışması başlatıldı. Niksar Belediyesi Fen İşleri Müdürlüğü ekiplerince Küçük Sanayi Sitesinde sıcak asfalt kaplama çalışmalarına başlanıldı.

Çalışmaları yerinde inceleyen Niksar Belediye Başkanı Özdilek Özcan, “Söz verdiğimiz gibi Küçük Sanayi Sitemizde sıcak asfalt kaplama çalışmalarımıza başladık. Küçük Sanayi Sitemiz ilçemizin can damarı olan bir merkezimiz. Tabi öncelikle sanayimizin alt yapı problemleri vardı. Kanalizasyon problemlerini eski Belediye Başkanımız İdris Şahin döneminde çözmüştük. Bu dönemde ise yağmur suyu drenaj hatlarımızın projelerini uygulayarak ızgaralarımızı ve tahliye hatlarımızı koyduk. Sanayi esnaflarımıza geçen yıl sözünü vermiştik. Onlarda bizleri sabırla beklediler. Kendilerinden Allah razı olsun. Bugün burada sıcak asfalt çalışmalarımıza bismillah dedik. Ara yollarımızı da parkeyle kaplayarak vatandaşlarımızın ayağını çamura değdirmeyeceğiz. Geçtiğimiz gün Sanayi Kooperatifimizin değerli başkanı ve yönetim kurulu ile sanayimizin sorunlarını dinledik,” dedi.

Sıcak asfaltın bitiminin ardından, blok aralarını da parke ile kaplayacaklarını söyleyen Özcan, “Bu yılın sonunda hiçbir vatandaşım araçlarıyla sanayi sitemize geldiğinde, herhangi bir çamur veya bozuklukla karşılaşmayacak. Sanayide esnaf olan kardeşlerimden isteğimiz blok aralarında yapılan işgallerin kaldırılmasıdır. Çünkü 2018 yılında blok aralarında bordür çalışmalarımız ile yeşil alan çalışmalarımızı gerçekleştireceğiz. Ayrıca her esnafımızdan isteğimiz kendi iş yerlerinin önünde bulunan atıl maddeleri ve çöpleri düzgün bir şekilde muhafaza etmeleridir. Herkes kendi işyerinin önünü temiz tutarsa daha güzel bir sanayi sitemiz olur. Bizler 2018 yılında yollarıyla, yeşil alanlarıyla, bordür ve kaldırımlarıyla daha güzel bir sanayi ortaya koyacağız. Bizlerden dualarını esirgemeyen tüm hemşehrilerimize teşekkür ediyorum,” diye konuştu.