# Chunks Index

| ID    | Section                              | Heading Path                         | Char Range | Preview                                                                                         |
| ----- | ------------------------------------ | ------------------------------------ | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | Sarıkamış'ta Muhtarlar Günü Kutlandı | Sarıkamış'ta Muhtarlar Günü Kutlandı | 0-1000     | = Sarıkamış'ta Muhtarlar Günü Kutlandı = Kars'ın Sarıkamış ilçesinde, 19 Ekim Muhtarlar Günü... |
| c0001 | Sarıkamış'ta Muhtarlar Günü Kutlandı | Sarıkamış'ta Muhtarlar Günü Kutlandı | 800-1376   | rladı.                                                                                          |