---
id: 00417haberlercom_1a7b25d6
url: file://00417_haberler_com.md
title: 00417 haberler com
lang: en
created_at: '2025-12-19T23:09:21.533887'
checksum: dae7498736a669c289e6c4e96e41e657547acbf532826f6c194bc67d3285463a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 168
  char_count: 1376
  num_chunks: 2
  num_sections: 1
---
= Sarıkamış'ta Muhtarlar Günü Kutlandı =

Kars'ın Sarıkamış ilçesinde, 19 Ekim Muhtarlar Günü dolayısıyla tören düzenlendi. Düzenlenen tören, Sarıkamış Hükümet Konağı önündeki Atatürk Anıtı'na çelenk sunumu, saygı duruşu ve İstiklal Marşı'nın okunmasıyla başladı.

Sarıkamış Muhtarlar Derneği Başkanı Yunus Gökcan, muhtarların vatandaşlara en iyi şekilde hizmet vermek için çalıştığını belirten Gökcan, "Kültürümüzün ve toplumsal hayatımızın önemli yapı taşlarından olup yerel demokrasinin en eski örneğini temsil eden, devletimizin her noktadaki kurumsal temsilciliğidir. Muhtarlarımız, bulunduğu mahallede devletimizin tüm kurumlarını temsil etmekte ve halkımızla devlet kurumları arasında köprü vazifesi görmektedir." dedi.

Sarıkamış Kaymakamı Recep Koşal, törenin ardından muhtarları makamda ağırladı. Muhtarların gününü kutlayan Koşal, muhtarların sorunlarını dinledi. Koşal, gönüllerin ve kapılarının her zaman muhtarlara açık olduğunu söyleyerek, "Muhtarlık; halkımızın talep, problem ve ihtiyaçların en kısa yoldan yetkili makamlara arz ederek çözüm hususunda halkımızın en yakın yardımcısıdır. Hizmet noktasında muhtarların her türlü işlerinde yanındayız. 19 Ekim Muhtar Gününü kutluyorum, sağlıklı ve huzurlu günler diliyorum" dedi.

Törene, Sarıkamış Kaymakamı Recep Koşal, Belediye Başkan Vekili Serdar Kılıç, kurum amirleri ile mahalle ve köy muhtarları katıldı.