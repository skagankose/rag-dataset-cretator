# Dataset: 00834 multiplayer com tr

Generated on: 2025-12-19T23:23:24.883005
Total questions: 1

| # | Question                                                             | Answer          | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------------------- | --------------- | -------- | ----------------- |
| 1 | Videoda yer alan dört kişilik co‑op oyun modu hangi isimle anılıyor? | Resistance modu | FACTUAL  | c0000             |