---
id: 00834multiplayercomt_41b83a9e
url: file://00834_multiplayer_com_tr.md
title: 00834 multiplayer com tr
lang: en
created_at: '2025-12-19T23:23:16.538307'
checksum: c3b43b2d84e41ed93e9a615ae11f9795971d720c27ea2e29ea48aeae961517a7
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 86
  char_count: 643
  num_chunks: 1
  num_sections: 1
---
= Homefront: The Revolution'dan Kapalı Beta Tanıtım Videosu =

08 Şubat 2016 tarihinde Sercan 'SirJohnNacreS' Özdemir tarafından yazılmıştır.

Deep Silver'ın geliştirdiği ve oyuncular tarafından merakla beklenen Homefront: The Revolution için yeni bir video paylaşıldı.

Oyuncuların beklentilerini karşılamak isteyen Deep Silver, ilk yapımda beklentilerin altında kalmıştı.

Oyunun kapalı beta oynanış görüntüleri paylaşılan videoda yer alıyor.

Çoklu oyun modunu ele alan videoda gördüğümüz üzere dört kişilik bir Co‑Op modu da yer alıyor.

Resistance modu adına sahip bu dört kişilik co‑op oyun modu oyunculara güzel bir deneyim vaad ediyor.