# Chunks Index

| ID    | Section                                                   | Heading Path                                              | Char Range | Preview                                                                                         |
| ----- | --------------------------------------------------------- | --------------------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | Homefront: The Revolution'dan Kapalı Beta Tanıtım Videosu | Homefront: The Revolution'dan Kapalı Beta Tanıtım Videosu | 0-643      | = Homefront: The Revolution'dan Kapalı Beta Tanıtım Videosu = 08 Şubat 2016 tarihinde Sercan... |