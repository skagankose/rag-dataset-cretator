# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                                                                              |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Ev, iş yeri ve araçlarda bu çanta bulundurulmalı | Ev, iş yeri ve araçlarda bu çanta bulundurulmalı | 0-534      | = Ev, iş yeri ve araçlarda bu çanta bulundurulmalı = Erzurum'da AFAD ekipleri, deprem başta olmak... |