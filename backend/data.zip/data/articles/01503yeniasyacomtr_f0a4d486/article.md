---
id: 01503yeniasyacomtr_f0a4d486
url: file://01503_yeniasya_com_tr.md
title: 01503 yeniasya com tr
lang: en
created_at: '2025-12-19T23:45:23.541693'
checksum: 08b982c9b4f820f3df1a128eef29757dfbe5a444e5e0da2968c033ebe3be0f7c
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 66
  char_count: 534
  num_chunks: 1
  num_sections: 1
---
= Ev, iş yeri ve araçlarda bu çanta bulundurulmalı =

Erzurum'da AFAD ekipleri, deprem başta olmak üzere afetlerden hemen sonra ihtiyaç duyulabilecek malzemelerin yer aldığı **Afet ve Acil Durum Çantası** konusunda vatandaşları bilgilendiriyor. Eğitmenler, hayat kurtarmaya vesile olma özelliği taşıyan çantanın, evdeki çıkış kapısının yakınlarında muhafaza edilmesini tavsiye ediyor. Erzurum AFAD Müdürü Selahattin Karslı, yaptığı açıklamada, İstanbul'da meydana gelen depremden dolayı vatandaşlara “geçmiş olsun” dileklerini iletti.