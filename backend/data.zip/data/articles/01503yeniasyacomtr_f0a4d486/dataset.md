# Dataset: 01503 yeniasya com tr

Generated on: 2025-12-19T23:45:32.269534
Total questions: 1

| # | Question                    | Answer            | Category | Related_Chunk_IDs |
| - | --------------------------- | ----------------- | -------- | ----------------- |
| 1 | Erzurum AFAD Müdürü kimdir? | Selahattin Karslı | FACTUAL  | c0000             |