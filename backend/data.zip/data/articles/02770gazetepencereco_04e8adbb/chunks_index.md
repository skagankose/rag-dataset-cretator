# Chunks Index

| ID    | Section                     | Heading Path                | Char Range | Preview                                                                                                |
| ----- | --------------------------- | --------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | ZAFER’DE HEDEF YİNE TUTMADI | ZAFER’DE HEDEF YİNE TUTMADI | 0-1000     | == ZAFER’DE HEDEF YİNE TUTMADI == Türkiye’de tartışması sürekli devam eden, yolcu garantisi verilen... |
| c0001 | ZAFER’DE HEDEF YİNE TUTMADI | ZAFER’DE HEDEF YİNE TUTMADI | 800-1069   | lik” Zafer Havalimanı’na ise ilk dokuz ayında 556 uçak geldi.                                          |