---
id: 02770gazetepencereco_04e8adbb
url: file://02770_gazetepencere_com.md
title: 02770 gazetepencere com
lang: en
created_at: '2025-12-20T00:16:35.595742'
checksum: 3b45c5af0003ccb94ec7e05e9a7c520053bcd2c7b8ec314d2d927fa5445bc81f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 145
  char_count: 1069
  num_chunks: 2
  num_sections: 1
---
== ZAFER’DE HEDEF YİNE TUTMADI ==

Türkiye’de tartışması sürekli devam eden, yolcu garantisi verilen havalimanları ile ilgili her gün yeni bir bilgi ortaya çıkıyor. Sözcü’den Deniz Ayhan’ın haberine göre, milyonlarca lira harcanan, yap‑işlet‑devret modeliyle yapılan dört havalimanına yılın ilk dokuz ayında bir uçak bile inmediği ortaya çıktı. Havalimanlarında her gün onlarca personel görev yapmaya devam ederken, yolcuların gitmediği, tarifeli uçakların inip‑kalmadığı havalimanlarının giderleri de devletin kasasından, yani milletin cebinden karşılanıyor.

Türkiye’de 60 havalimanı var. Balıkesir Merkez, Çanakkale Gökçeada, Aydın Çıldır ve Uşak havalimanları bu yıl tamamen boş kaldı. Kocaeli Cengiz Topel Havalimanı’nı 9, Siirt Havalimanı’nı 324, Tokat Havalimanı’nı 376 uçak kullandı. “Kara delik” Zafer Havalimanı’na ise ilk dokuz ayında 556 uçak geldi. Havalimanını dokuz ayda 47 bin 803 yolcu kullandı. 2022 yılı için Zafer Havaalanı için garanti edilen yolcu sayısı ise 1 milyon 317 bin 733 olmuştu. Zafer’de yine hedef tutmadı, tutması da mümkün görünmüyor.