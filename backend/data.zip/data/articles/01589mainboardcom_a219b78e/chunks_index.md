# Chunks Index

| ID    | Section                                 | Heading Path                            | Char Range | Preview                                                                                              |
| ----- | --------------------------------------- | --------------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Haftada bir baş başa bir şeyler yapın   | Haftada bir baş başa bir şeyler yapın   | 50-369     | == Haftada bir baş başa bir şeyler yapın == Özellikle yoğun çalışan çiftler haftada bir günü baş...  |
| c0001 | Birlikte eğlenin                        | Birlikte eğlenin                        | 369-643    | == Birlikte eğlenin == Birlikte eğlenceli aktivitelere katılmak aranızdaki yakınlığı pekiştirir.     |
| c0002 | Uzun süreli aktivitelere birlikte gidin | Uzun süreli aktivitelere birlikte gidin | 643-862    | == Uzun süreli aktivitelere birlikte gidin == Sevgilinizle birlikte bir dil kursuna gidin ya da...   |
| c0003 | Sorunları hemen çözmeye bakın           | Sorunları hemen çözmeye bakın           | 862-1194   | == Sorunları hemen çözmeye bakın == Ateşli bir tartışmanın ortasında ondan özür dilemek her zaman... |
| c0004 | Romantizmden vazgeçmeyin                | Romantizmden vazgeçmeyin                | 1194-1572  | == Romantizmden vazgeçmeyin == Günlük hayatın karmaşası içinde romantizmin büyüsünü çoğu zaman...    |
| c0005 | Yorumlar                                | Romantizmden vazgeçmeyin > Yorumlar     | 1572-1803  | === Yorumlar === - **cyber_ozaf** (30.09.2007 02:42) - **helL_ChiLd** (29.09.2007 21:38) Iliskiyi... |