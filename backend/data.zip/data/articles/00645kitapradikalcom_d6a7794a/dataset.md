# Dataset: 00645 kitap radikal com tr

Generated on: 2025-12-19T23:17:07.807916
Total questions: 1

| # | Question                                      | Answer                    | Category | Related_Chunk_IDs |
| - | --------------------------------------------- | ------------------------- | -------- | ----------------- |
| 1 | Kitapta en başta hangi eylemden söz ediliyor? | Büyük Darülfünun boykotu. | FACTUAL  | c0000             |