---
id: 00645kitapradikalcom_d6a7794a
url: file://00645_kitap_radikal_com_tr.md
title: 00645 kitap radikal com tr
lang: en
created_at: '2025-12-19T23:16:58.537547'
checksum: 748fecad29541289c8c8c437b7b846009e5ed50db5a34ad72b5f6985b5f39c8b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 66
  char_count: 498
  num_chunks: 1
  num_sections: 1
---
= KURTULUŞ SAVAŞI GENÇLİĞİ =

Tüm Tarih Kitapları Radikal Kitap'ta! Zeki Sarıhanın titiz bir çalışmayla; o yılların gazete ve dergilerini, o döneme ait araştırma ve anı kitaplarını tarayarak, yazdığı bu kitapta, Birinci Dünya Savaşı'nda işgal edilen ülkesini savunmak için ayağa kalkan Jön Türklerin çocuklarının doğru ve haklı eylemlerini bulacaksınız. Kuşkusuz en başta, büyük Darülfünun boykotunu... Sarıhan, Kurtuluş Savaşı yıllarındaki gençlik örgütlenmesini de kapsamlı bir biçimde inceliyor.