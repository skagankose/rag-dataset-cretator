# Chunks Index

| ID    | Section                                    | Heading Path                               | Char Range | Preview                                                                                             |
| ----- | ------------------------------------------ | ------------------------------------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Binbaşı Demir yurt dışı görevini tamamladı | Binbaşı Demir yurt dışı görevini tamamladı | 0-1000     | = Binbaşı Demir yurt dışı görevini tamamladı = Binbaşı Demir yurt dışı görevini tamamladı 51 kez... |
| c0001 | Binbaşı Demir yurt dışı görevini tamamladı | Binbaşı Demir yurt dışı görevini tamamladı | 800-1115   | lecik'te göreve başladı.                                                                            |