---
id: 03027antalyahakkinda_65a33311
url: file://03027_antalyahakkinda_com.md
title: 03027 antalyahakkinda com
lang: en
created_at: '2025-12-20T00:20:52.541032'
checksum: 1d27d43d454257dcea5b150b8dc03b05db2b0a9cc61a83682106d32774af9d32
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 151
  char_count: 1115
  num_chunks: 2
  num_sections: 1
---
= Binbaşı Demir yurt dışı görevini tamamladı =

Binbaşı Demir yurt dışı görevini tamamladı 51 kez okunmuştur.  
Güncelleme Tarihi: 15 Haziran 2021 14:23  

KUMLUCA, KUMLUCA – İlçe Jandarma Bölük Komutanı Binbaşı Mehmet Demir, Afganistan görevini tamamlayıp döndü.  
Kumluca İlçe Jandarma Bölük Komutanı Binbaşı Mehmet Demir, yurt dışı görevi için NATO güçlerine bağlı olarak Afganistan'ın başkenti Kabil Emniyet Müdürlüğü'nde 6 aylık süreyle polis birliğine danışmanlık yaptı. Tatil merkezleri, Olympos ve Adrasan başta olmak üzere ilçe genelindeki asayişin sağlanması için başarılı çalışmalar yapan Jandarma Binbaşı Mehmet Demir, Afganistan'da 6 ay görev yaptı.  

2004 yılında Hava Harp Okulu'ndan mezun olduktan sonra 2 yıl komando, piyade ve jandarma hazırlık kursları alan Demir, 2006 yılında Bilecik'te göreve başladı. Ülkenin değişik bölgelerinde görev yapan Mehmet Demir, 2018 yılından beri Kumluca İlçe Jandarma Bölük Komutanlığı yapıyordu. 2019 yılı ağustos ayında binbaşılık rütbesine terfi eden Mehmet Demir, yurt dışı görevini tamamlayınca tekrar Kumluca İlçe Jandarma Bölük Komutanlığı görevine döndü.