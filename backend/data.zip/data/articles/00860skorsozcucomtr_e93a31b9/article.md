---
id: 00860skorsozcucomtr_e93a31b9
url: file://00860_skor_sozcu_com_tr.md
title: 00860 skor sozcu com tr
lang: en
created_at: '2025-12-19T23:24:08.537598'
checksum: 7562866de477c8fec58e9a036bf0590c993168bc60cb9c65e05d838ce068a090
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 212
  char_count: 1665
  num_chunks: 2
  num_sections: 1
---
= Zenke doğum gününde padişah oldu =

Karabükspor'un forveti olan ve yıllardır ülkemizde forma giyen Zenke için sürpriz bir doğum günü organizasyonu yapıldı.  
Güncellenme: 17:06, 04/12/2015  

PTT 1. Lig'de ilk yarının bitimine 4 hafta kala 23 puanla lider olan Kardemir Karabükspor, geçtiğimiz sezon Şanlıurfaspor'dan alınan Nijeryalı futbolcusu Zenke'ye 150 yıllık tarihi Safran Konak'da sürpriz doğum günü düzenledi.  

Hafta sonu Şanlıurfaspor maçı öncesi bu etkinlik futbolculara büyük moral kaynağı olurken, eğlence mekan sahipleri Simon Zenke'ye Osmanlı giysileri giydirerek “Hoş geldin padişahım” diyerek kapıda karşıladı.  

Geçtiğimiz sezon son anda Süper Lig'den düşen ve bu sene hedefini tekrar Süper Lig olarak belirleyen Kardemir Karabükspor, bu sezon Şanlıurfaspor'dan alınan Nijeryalı forvet futbolcusu Zenke'ye 150 yıllık tarihi konakta sürpriz doğum günü düzenledi.  

Doğum gününe futbolcular, teknik heyet, Kulüp Başkanı Ferudun Tankut, Futbol Şube Sorumlusu Tolga Gül, konak sahipleri ve Safranbolu Belediye Başkanı Necdet Aksoy katıldı. Futbolcular çalınan türküler eşliğinde gönüllerince eğlendiler.  

Zenke ise 150 yıllık bir konakta ilk defa doğum gününü kutladığını belirterek, “Bu organizasyonu gerçekleştirenlere teşekkür ederim. Pazar günü oynayacağımız Şanlıurfa maçına moral oldu, çok güzel eğlendik” dedi.  

Safran konak sahibi Recep Yücel ise Kardemir Karabükspor'u konaklarında ağırladıkları için mutlu olduklarını belirterek, “Karabük halkının takımımıza sahip çıkmasını bekliyoruz.” dedi.  

Kardemir Karabükspor Kulüp Başkanı Ferudun Tankut, Safran Konak sahibi Recep Yücel'e tüm futbolcuların imzaladığı formayı hediye etti.