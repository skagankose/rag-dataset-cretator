# Chunks Index

| ID    | Section                          | Heading Path                     | Char Range | Preview                                                                                                |
| ----- | -------------------------------- | -------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Zenke doğum gününde padişah oldu | Zenke doğum gününde padişah oldu | 0-1000     | = Zenke doğum gününde padişah oldu = Karabükspor'un forveti olan ve yıllardır ülkemizde forma giyen... |
| c0001 | Zenke doğum gününde padişah oldu | Zenke doğum gününde padişah oldu | 800-1665   | ı forvet futbolcusu Zenke'ye 150 yıllık tarihi konakta sürpriz doğum günü düzenledi.                   |