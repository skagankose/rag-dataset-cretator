---
id: 04501arkiteracom_2263dad9
url: file://04501_arkitera_com.md
title: 04501 arkitera com
lang: en
created_at: '2025-12-20T00:45:26.556547'
checksum: 1894120699c18e934f6fe0da80c3250188e5845ab2025e3ae667e68527425436
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 382
  char_count: 2927
  num_chunks: 4
  num_sections: 1
---
= Ulus Anafartalar Çarşısı Bize Sesleniyor: "Bana, belleğinize ve kente birlikte sahip çıkalım." =

Belki de asıl istenmeyen bu insanlar, sadece anılar veya mekanlar değil. Onları istenmeyen olmaya iten, istenmeyen dünya düzeni de olabilir, kim bilir…

"Geçmişin masalını, geleceğin hayalini" buradan yazarız. Çocukluğumuzun mutluluğunu hep sokakta ararız, tıpkı önümüzdeki baharın ilk ışıklarını da sokakta arayacağımız gibi.

İnsanın insana ve inkar ettiği kendi yitik doğasına karşı sürdürdüğü kıyım, ötekinin bastırılmasının inceltilmiş bir acı çektirme ayinine dönüştüğü gündelik hayatın sıradan kıyımı…

**Yer:** Ankara, **Bölge:** Ulus, **Cadde:** Hisarönü, **Yapı:** Anafartalar Çarşısı, 1967'de açılan bir yarışma üzerine, Ferzan Baydar, Affan Kırımlı, Tayfur Şahbaz'ın kazandığı proje ile elde edilen yapı bütünü, Ankara'nın ilk gelişim bölgesinde ve ilk alışveriş yapısı.

Kurulan yeni yönetim biçiminin, yeni yapı elde edişlerinde, yeni bir aşama; kübik tarzı, cephe niteliği, ilk yürüyen merdiveni, içinde alışveriş yapılan koridorlar ve o koridorlarda sanat eserleri barındıran bir tasarım olması itibariyle, birçok ilke sahip, bir modernizm denemesi. Ama ne zaman, 1970’lerde…

Kent deyince; işte bu 50 yılın biriktirmelerinin ve görmelerinin toplamının bizim aklımızla etkileşimi değil midir; olan, yaşanan, öğrenme/kültürel bellek yolculuğumuzun köşetaşı.

Fakat; büyüme, mutenalaşma ve yenilikteki doz aşımı hastalığımız, neo‑liberal diye adlandırılan günümüz birey/sermaye politik aklı, işte 2018’lerde, bize “yık‑yenile‑dönüştür‑unut ve hiç biriktirme”yi getiriyor.

Nüfus ve göç artınca, şehir de büyüyor, karmaşıklaşıyor ve çirkinleşiyor, yaşadığımız yer(ler)in tüm bellek olanakları da sisteme kurban ediliyor. Bu değişimde nefes alabildiğimiz alanlar da; kendi tarihimizde yaşadığımız yerler, içinden geçtiğimiz alanlar, kentin tarihi, belleği, o sokaklar, o yapılar, o parklar oluyor. Ve bu bizimle birlikte, kentin büyümesi ve yaş almasının tüm belleği oluyor. Kitaplara, filmlere, geleceğe değen hikayeleri üretiyor.

Hangimiz “Öteki”? Hangimiz “İstenmeyen”? Çok çok uzak bir ülkede, bir bilinmeyende mi yoksa yanı başımızda, içimizde mi? Kim belirliyor “Öteki”ni? Ben mi sen mi hepimiz mi?

Ankara'nın ilk (tarihi) merkezi Ulus'ta bulunan, kültürel bellek ve kentlilik bilincine dair yansımaları olan özgün bir yaşam alanı: Anafartalar Çarşısı. Çarşı içindeki kamusal seramik sanat eserleri ise birer kent estetiği unsuru. Toplumsal ve kolektif bir üretim olan kent belleğine ve kentin kültürel mirasına katkıda bulunmakta.

“yıkım estetiği / an aesthetics of demolition”ı anlamaya çalışıyorum. Yıkımdan değilse de yarattığı hüzünden estetik bir deneyim devşirdiğimizi seziyorum çünkü. Bir tür lanet gibi bizi esir eden tutkulu bir yıkım tasavvuru var; ölüme, kıyamete, yok oluşa yazgılı varlığımıza bir “karşıumut”.

Anafartalar Çarşısı içinde, 1963 tarihli seramik duvar panoları ve duvar resim...