---
id: 02986haber7com_bccf29be
url: file://02986_haber7_com.md
title: 02986 haber7 com
lang: en
created_at: '2025-12-20T00:20:11.553138'
checksum: 5aa0b980c89af29859a61ac9cda344d2cf24cc15fc951a98574a79043a86ba5f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 87
  char_count: 636
  num_chunks: 1
  num_sections: 1
---
= Aydın'da kamyonet kanala uçtu; 1 ağır 2 yaralı =

== GÜNCEL Haberleri GİRİŞ ==
**17.09.2020 03:13**  
**GÜNCELLEME 17.09.2020 03:13**

Edinilen bilgiye göre, bölgede devriye gezen jandarma ekiplerinden kaçtığı iddia edilen Hüseyin Varışlı (45) yönetimindeki 09 UC 619 plakalı kamyonet, sürücüsünün nedeni henüz bilinmeyen bir nedenle direksiyon hakimiyetini kaybetmesi sonucu Devlet Su İşleri'ne (DSİ) ait sulama kanalına uçtu. Çevredeki vatandaşlar durumu 112 Acil Servis, jandarma ve Aydın Büyükşehir Belediyesi İtfaiye ekiplerine bildirdi. İhbar üzerine bölgeye Aydın İl Afet ve Acil Durum Müdürlüğü (AFAD) ekipleri de sevk edildi.