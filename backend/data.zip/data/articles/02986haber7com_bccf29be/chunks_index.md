# Chunks Index

| ID    | Section                | Heading Path           | Char Range | Preview                                                                                               |
| ----- | ---------------------- | ---------------------- | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | GÜNCEL Haberleri GİRİŞ | GÜNCEL Haberleri GİRİŞ | 52-636     | == GÜNCEL Haberleri GİRİŞ == **17.09.2020 03:13** **GÜNCELLEME 17.09.2020 03:13** Edinilen bilgiye... |