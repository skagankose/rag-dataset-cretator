# Dataset: 02986 haber7 com

Generated on: 2025-12-20T00:20:19.264966
Total questions: 1

| # | Question                  | Answer    | Category | Related_Chunk_IDs |
| - | ------------------------- | --------- | -------- | ----------------- |
| 1 | Kamyonetin plakası neydi? | 09 UC 619 | FACTUAL  | c0000             |