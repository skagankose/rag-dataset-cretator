---
id: 00725gundemkibriscom_7c73e1f9
url: file://00725_gundemkibris_com.md
title: 00725 gundemkibris com
lang: en
created_at: '2025-12-19T23:19:37.538255'
checksum: c1ea495c503e6a81ee4736103673b657abae503373b9b1739170191297fd1c25
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 372
  char_count: 2942
  num_chunks: 4
  num_sections: 2
---
= İmece usülü eğitim =

08:32 29 Eylül 2014  
Haber Kaynağı: İmece usülü eğitim  

Dipkarpaz'daki Recep Tayyip Erdoğan Ortaokulu'nda 15 öğretmen eksiği nedeniyle eğitime başlanamamasına bu kez Dipkarpaz Belediyesi el attı. A+A- Hanife LEFKARALI. Geçtiğimiz hafta Okul Aile Birliği öncülüğünde düzenlenen eyleme Kıbrıs Türk Orta Eğitim Öğretmenler Sendikası (KTOEÖS) Başkanı Tahir Gökçebel de katılarak destek verdi; kriz çözülememiş, hatta Milli Eğitim Bakanı Mustafa Arabacıoğlu'nun da görevinden istifa etmesiyle kriz yeni bir aşamaya taşınmıştı.

Dipkarpaz Belediye Başkanı Suphi Coşkun yaptığı açıklamada, Dipkarpaz Recep Tayyip Erdoğan Ortaokulu'nda 2014‑2015 öğretim yılı öğretmen eksikliklerinden dolayı hâlâ eğitime başlayamadığını ve belediye olarak bu soruna müdahale edeceklerini kaydetti. Coşkun, okulun 2006 yılından bu yana hiçbir öğretim yılına sorunsuz başlayamadığını, bu yıl ise 91 öğrencinin öğretmen eksikliğinden dolayı ders başı yapamadığını belirtti. “Çocuklarımızın en doğal hakkı olan eğitim hakkı ellerinden alınmış bulunmaktadır. Bu sorunu tüm yetkililere aktarmamıza rağmen hâlen bir çözüm noktasına getirememişlerdir. Dipkarpaz Recep Tayyip Erdoğan Ortaokulu'nda müdür ve müdür muavini dahil olmak üzere 14 öğretmen açığı bulunmaktadır.” şeklinde konuştu.

**YOĞUN ŞEKİLDE ÇALIŞIYORUZ**  
Dipkarpaz Belediye Başkanı olarak bölgede yaşanan eğitim sorunu ve 91 çocuğun eğitim hakkından mahrum kalmasının kendilerini derinden etkilediğini belirten Coşkun, sorunlara çare üretmek için yoğun bir şekilde çalıştıklarını ifade etti. Bu sorunun aşılmasında belediyenin üzerine düşen sorumlulukları yerine getirebilmek için bölgede bulunan öğretmenlerle bir araya geldiklerini, Dipkarpaz Belediyesi sınırları içinde işsiz 15 öğretmen bulunduğunu kaydetti.

**İŞSİZ ÖĞRETMENLER SEFERBER OLU**  
Coşkun, “Öğretmenlerle birlikte yaptığımız toplantı sonrasında çocuklarımızın en doğal hakkı olan eğitim hakkından daha fazla mahrum bırakılmaması için gönüllü olarak öğretmen eksikliğini gidermeye hazır olduğumuzu tüm kamuoyuna bildirmek isteriz. Bizler ve 15 gönüllü öğretmen arkadaşlarım olarak yetkililere mesajımız, Dipkarpaz Recep Tayyip Erdoğan Ortaokulu'nda yıllardan beridir yaşanan kadro sıkıntısına köklü bir çözüm için özel kontenjan sistemini uygulayarak görev alan öğretmenlere en az 3 ya da 5 yıl zorunlu görev yapması şartı getirilmesidir. Bölge halkı olarak hükümetin bu güne kadar çözemediği bu sorunu ortadan kaldırmak adına öğretmenlerimizle birlikte hazır olduğumuzu ve üzerimize düşen sorumluluğu almaktan kaçmayacağımızı ifade etmek isteriz.” dedi.

=== Gönüllü Öğretmen Listesi ===

1. Mesut Dindar (Edebiyat)  
2. Kemal Erdoğan (Beden eğitimi öğret.)  
3. Leyla Sönmez (İngilizce‑tarih)  
4. Sinem Sönmez (İngilizce‑tarih)  
5. Diba Sünmez (İngilizce‑tarih)  
6. Özlem Tanışman (Okul öncesi öğret.)  
7. Fatma Tanışman (Psikolojik danış.)  
8. Seher Tanışman (Türkçe öğret.)  
9. Fırat Borak (Türkçe ...