# Chunks Index

| ID    | Section                  | Heading Path                                  | Char Range | Preview                                                                                               |
| ----- | ------------------------ | --------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | İmece usülü eğitim       | İmece usülü eğitim                            | 0-1000     | = İmece usülü eğitim = 08:32 29 Eylül 2014 Haber Kaynağı: İmece usülü eğitim Dipkarpaz'daki Recep...  |
| c0001 | İmece usülü eğitim       | İmece usülü eğitim                            | 800-1800   | Coşkun, okulun 2006 yılından bu yana hiçbir öğretim yılına sorunsuz başlayamadığını, bu yıl ise 91... |
| c0002 | İmece usülü eğitim       | İmece usülü eğitim                            | 1600-2585  | şen sorumlulukları yerine getirebilmek için bölgede bulunan öğretmenlerle bir araya geldiklerini,...  |
| c0003 | Gönüllü Öğretmen Listesi | İmece usülü eğitim > Gönüllü Öğretmen Listesi | 2587-2942  | === Gönüllü Öğretmen Listesi === 1.                                                                   |