# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                          |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------------ |
| c0000 | Lead    | Lead         | 0-1000     | Emlak Konut güvencesiyle İstanbul'un seçkin noktalarından olan Bahçekent'te yükselen Avrupark... |
| c0001 | Lead    | Lead         | 800-1800   | aret alanı yer alıyor.                                                                           |
| c0002 | Lead    | Lead         | 1600-2100  | sından da alıcılarına büyük kolaylık sağlayarak dikkatleri üzerine çeken Avrupark Hayat, TEM...  |