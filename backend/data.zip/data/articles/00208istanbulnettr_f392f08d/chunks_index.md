# Chunks Index

| ID    | Section                                 | Heading Path                            | Char Range | Preview                                                                                           |
| ----- | --------------------------------------- | --------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------- |
| c0000 | Akıllı Çocuklar Kulübü - Aile Eğlencesi | Akıllı Çocuklar Kulübü - Aile Eğlencesi | 0-1000     | = Akıllı Çocuklar Kulübü - Aile Eğlencesi = Kültür Sanat Etkinlikleri, Konser Tiyatro İstanbul... |
| c0001 | Akıllı Çocuklar Kulübü - Aile Eğlencesi | Akıllı Çocuklar Kulübü - Aile Eğlencesi | 800-1026   | aktır; sessiz kalmaları hususunda özen gösterilmesini önemle rica ederiz.                         |