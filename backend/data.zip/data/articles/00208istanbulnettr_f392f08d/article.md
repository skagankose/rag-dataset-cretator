---
id: 00208istanbulnettr_f392f08d
url: file://00208_istanbul_net_tr.md
title: 00208 istanbul net tr
lang: en
created_at: '2025-12-19T23:02:37.561266'
checksum: 108f499ffe3ed12e7861a13d1feefa0e92542025f2dcd785c9ab14db6ae3fe8a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 145
  char_count: 1026
  num_chunks: 2
  num_sections: 1
---
= Akıllı Çocuklar Kulübü - Aile Eğlencesi =

Kültür Sanat Etkinlikleri, Konser Tiyatro İstanbul Şehir Rehberi.

**Tarihler:** 20 Ekim 2018 Cumartesi ~ 20 Ekim 2018 Cumartesi  
**Saat:** 20 Ekim 14:00 - 20 Ekim 16:00

Merlin Ödüllü ünlü sihirbaz ve psikolog Kubilay QB Tunçer, 20 Ekim'de 14:00 ve 16:00 seansları ile 3-8 yaş arasındaki "akıllı çocuklarla" gösterilerini Küçük Sahne Uniq'de sürdürüyor. Yenilenen ve zenginleşen şovda sihir, eğlence ve yaratıcı düşünmeye davet bir arada sunuluyor. Akıllı Çocuklar Kulübü, binlerce çocuğa ulaşan benzersiz bir gösteri. Akıllı çocuklarımız daha da akıllı olsun ve çok eğlensinler diye 3. yılında, wapıjonSAHNE'de.

- Gösteri süresi 50-60 dakika kadar sürmektedir.  
- 3 yaş altı çocuklar, büyük kardeşleri var ise ebeveynleri ile beraber gösteriye alınacaktır; sessiz kalmaları hususunda özen gösterilmesini önemle rica ederiz.  
- 7 yaş ve üzeri çocuklar, girişteki arkadaşımıza veli telefonu verilerek veya kendi telefonu var ise tek başına bileklik takılarak girebileceklerdir.