# Dataset: 01769 aksiyonhaber com

Generated on: 2025-12-19T23:54:23.892349
Total questions: 1

| # | Question                                                                                   | Answer       | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------ | ------------ | -------- | ----------------- |
| 1 | Arsel kasabasında terk edilmiş Suriye plakalı araçta kaç kilogram patlayıcı ele geçirildi? | 100 kilogram | FACTUAL  | c0000             |