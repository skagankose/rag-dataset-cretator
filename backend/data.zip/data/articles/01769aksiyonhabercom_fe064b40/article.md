---
id: 01769aksiyonhabercom_fe064b40
url: file://01769_aksiyonhaber_com.md
title: 01769 aksiyonhaber com
lang: en
created_at: '2025-12-19T23:54:14.528033'
checksum: f7a878770b0f2b1634d1bc8ae2233a3710215472e785b48b4792650e419120d8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 77
  char_count: 604
  num_chunks: 1
  num_sections: 1
---
= Suriye'ye ait araçta 100 kilo patlayıcı bulundu! =

Lübnan'ın Suriye sınırındaki Arsel kasabasında terk edilmiş halde bulunan bir araçta 100 kilogram patlayıcı ele geçirildi. Lübnan güvenlik güçlerinden yapılan açıklamada, Arsel kasabasında yol kenarına terk edilmiş Suriye plakalı bir araçta 100 kilogram patlayıcının ele geçirildiği ifade edildi. Demir kutular içindeki bombaların patlamaya hazır hale getirildiği kayd edildi. Lübnan güvenlik güçleri, içindeki patlayıcıları etkisiz hale getirildikten sonra aracı bir çekiciyle bölgeden uzaklaştırdı. Konuyla ilgili geniş çaplı soruşturma başlatıldı.