# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                            |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | -------------------------------------------------- |
| c0000 | Suriye'ye ait araçta 100 kilo patlayıcı bulundu! | Suriye'ye ait araçta 100 kilo patlayıcı bulundu! | 0-604      | = Suriye'ye ait araçta 100 kilo patlayıcı bulundu! |