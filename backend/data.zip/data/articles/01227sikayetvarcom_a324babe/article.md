---
id: 01227sikayetvarcom_a324babe
url: file://01227_sikayetvar_com.md
title: 01227 sikayetvar com
lang: en
created_at: '2025-12-19T23:36:10.540764'
checksum: ed16155d167ae3ad3082c7ad07265d211c8e406ceeffefc26abd850c655ba318
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 110
  char_count: 809
  num_chunks: 1
  num_sections: 1
---
= Numnum Personelinin Davranışı Ve Yanlış Verilen Siparişten Şikayetçiyim! =

Bağdat Caddesi'nde yer alan NumNum'a ilk kez gittim, barbekü soslu tavuklu ve bulgurlu salata siparişi verdim. Siparişimi başka bir garson getirdi ve garsona yanlış sipariş getirdiğini söylediğimde siparişimi alan garsona danıştı ve sistemden siparişime baktılar. Siparişimi alan garson yanlış salatayı değiştirmeden geldi ve ona “Barbekü soslu tavuk istemiştim” dediğimde “Barbekü sos getiririz.” dedi, “Ama beyefendi bulgur da yok bu salatada” dediğimde “Bulgur da getiririz.” dedi ve siparişimi düzeltmedi, üstüne de dalga geçer gibi saygısız davrandı.

Esi 549 Okunma Markalar Köfteci Ramiz, Big Chefs, Happy Moon's, HD İskender Restaurant, Kasap Döner, Köfteci Yusuf, Pidem Restaurant, Bereket Döner, Bursa Kebap Evi, Midpoint