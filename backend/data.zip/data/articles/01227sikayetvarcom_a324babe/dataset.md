# Dataset: 01227 sikayetvar com

Generated on: 2025-12-19T23:36:19.653468
Total questions: 1

| # | Question                         | Answer              | Category | Related_Chunk_IDs |
| - | -------------------------------- | ------------------- | -------- | ----------------- |
| 1 | NumNum hangi caddede yer alıyor? | Bağdat Caddesi'nde. | FACTUAL  | c0000             |