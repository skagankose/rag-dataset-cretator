# Chunks Index

| ID    | Section                                                                  | Heading Path                                                             | Char Range | Preview                                                                    |
| ----- | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ---------- | -------------------------------------------------------------------------- |
| c0000 | Numnum Personelinin Davranışı Ve Yanlış Verilen Siparişten Şikayetçiyim! | Numnum Personelinin Davranışı Ve Yanlış Verilen Siparişten Şikayetçiyim! | 0-809      | = Numnum Personelinin Davranışı Ve Yanlış Verilen Siparişten Şikayetçiyim! |