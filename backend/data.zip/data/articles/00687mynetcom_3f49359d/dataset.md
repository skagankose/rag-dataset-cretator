# Dataset: 00687 mynet com

Generated on: 2025-12-19T23:18:31.141102
Total questions: 1

| # | Question                                                                         | Answer                                         | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------------------------------- | ---------------------------------------------- | -------- | ----------------- |
| 1 | Bakan Akar, Pençe-Kilit operasyonunda öldürülen terörist sayısını nasıl duyurdu? | 100'den fazla terörist etkisiz hâle getirildi. | FACTUAL  | c0000             |