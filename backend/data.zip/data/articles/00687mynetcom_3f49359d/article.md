---
id: 00687mynetcom_3f49359d
url: file://00687_mynet_com.md
title: 00687 mynet com
lang: en
created_at: '2025-12-19T23:18:21.533997'
checksum: 6814fc9597ef3908f5d86c9a4b82cdc4357bff1214ccd4b8e387477bfa56556b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 106
  char_count: 822
  num_chunks: 1
  num_sections: 1
---
= SON DAKİKA | Pençe-Kilit operasyonunda son durum! Bakan Akar duyurdu: 100'den fazla terörist etkisiz hâle getirildi =

25.05.2022 08:49 | Son Güncelleme: 25.05.2022 11:42

Son dakika haberi: Milli Savunma Bakanı Hulusi Akar, devam eden Pençe-Kilit operasyonuyla ilgili son durumu açıkladı. 5 askerin şehit olduğu hain saldırı sonrası mağarada kıstırılan teröristler etkisiz hâle getirilirken; Bakan Akar, yaptığı açıklamada operasyonlarda öldürülen terörist sayısının 100'den fazla olduğunu duyurdu.

Pençe-Kilit Operasyonundan dün gelen şehit haberleri Türkiye'yi kahretmişti. Milli Savunma Bakanlığı, Meluni Dağı kırsalında teröristlerle çıkan çatışmada Teğmen Abdulkadir Güler, Uzman Çavuş Onur Doğan, Uzman Çavuş Hüseyin Cankaya, Uzman Çavuş Bican Kapılay ve Sözleşmeli Er Celal Tekedereli şehit olduğunu duyurmuştu.