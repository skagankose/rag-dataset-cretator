---
id: 00103onediocom_9823ac25
url: file://00103_onedio_com.md
title: 00103 onedio com
lang: en
created_at: '2025-12-19T22:59:16.508196'
checksum: bb29e7077e1d9db6bfcdf252f3e998f038968b9238e06e2d0e26fe3807fb0a87
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 162
  char_count: 1205
  num_chunks: 2
  num_sections: 1
---
= Bakan Işık: '5 Milyona Sattım İlk Otomobili' =

Bakan Işık: '5 Milyona Sattım İlk Otomobili' – onedio.com  
24PAYLAŞIM 27/10/2015, 17:24  

Bilim, Sanayi ve Teknoloji Bakanı Fikri Işık, ilk yerli otomobilin 5 milyon liraya bir iş adamına satıldığını açıkladı. TRT Haber'de katıldığı programda soruları yanıtlayan Bakan Işık, üretilecek ilk yerli otomobile ilişkin, “Gebze'de hayırsever bir iş adamımız otomobili almak istediğini söyledi. 5 milyona sattım ilk otomobili” dedi.

Yerli otomobil projesi ile ilgili değerlendirmelerde bulunan Işık, otomobilin prototipine çok ciddi ilgi olduğunu söyledi. Işık, “Her gittiğimiz yerde, ‘İlk arabayı ben almak istiyorum, kesinlikle alacağım, biz arkadaş grubu olarak alacağız, şirketteki tüm arabaları yenilerim’ gibi tepkilerle karşılaşıyoruz. Bir anekdot paylaşayım, ilk otomobili sattım. Gebze'de hayırsever bir iş adamımız ilk otomobili almak istediğini söyledi. ‘Olur ama pahalı olur’ dedim, 5 milyona sattım ilk otomobili. Şartımız şu: Cumhurbaşkanımızdan farklı bir talimat gelmezse Gebzeli hayırsever iş adamına ilk üretilen aracı vereceğiz. Ama bunun karşılığında da hayırsever iş adamımız Gebze'ye 5 milyon değerinde bir okul yapıp bağışlayacak” dedi.