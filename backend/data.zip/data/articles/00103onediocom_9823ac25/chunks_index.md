# Chunks Index

| ID    | Section                                      | Heading Path                                 | Char Range | Preview                                                                                            |
| ----- | -------------------------------------------- | -------------------------------------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Bakan Işık: '5 Milyona Sattım İlk Otomobili' | Bakan Işık: '5 Milyona Sattım İlk Otomobili' | 0-1000     | = Bakan Işık: '5 Milyona Sattım İlk Otomobili' = Bakan Işık: '5 Milyona Sattım İlk Otomobili' –... |
| c0001 | Bakan Işık: '5 Milyona Sattım İlk Otomobili' | Bakan Işık: '5 Milyona Sattım İlk Otomobili' | 800-1205   | paylaşayım, ilk otomobili sattım.                                                                  |