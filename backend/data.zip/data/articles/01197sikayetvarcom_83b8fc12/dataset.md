# Dataset: 01197 sikayetvar com

Generated on: 2025-12-19T23:35:36.997962
Total questions: 2

| # | Question                                                                                                                       | Answer                                                                                                                                                                                        | Category       | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- | ----------------- |
| 1 | Cam değişimi için ne kadar ücret istendi?                                                                                      | 500-600 TL                                                                                                                                                                                    | FACTUAL        | c0000             |
| 2 | Şikayetçi ekranla ilgili hangi önlemi öneriyor ve ikinci parçada birinci parçada yer almayan hangi ek markalar listelenmiştir? | Önlem: Ekran camınızı güçlendirin. Birinci parçada olmayan, ikinci parçada eklenen markalar: Sony Mobile, Vestel Venüs, Reeder, LG Mobile, Lenovo‑Motorola Akıllı Telefonlar, General Mobile. | INTERPRETATION | c0000, c0001      |