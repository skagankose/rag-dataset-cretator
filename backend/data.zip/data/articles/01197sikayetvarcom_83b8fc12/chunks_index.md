# Chunks Index

| ID    | Section                       | Heading Path                  | Char Range | Preview                                                                                    |
| ----- | ----------------------------- | ----------------------------- | ---------- | ------------------------------------------------------------------------------------------ |
| c0000 | Samsung Ekran Cami Kalitesiz! | Samsung Ekran Cami Kalitesiz! | 0-1000     | = Samsung Ekran Cami Kalitesiz!                                                            |
| c0001 | Samsung Ekran Cami Kalitesiz! | Samsung Ekran Cami Kalitesiz! | 800-1098   | 1 numaralı hattımıza ya da www.samsung.com.tr internet sitemizde “Bize Ulaşın” bölümüne... |