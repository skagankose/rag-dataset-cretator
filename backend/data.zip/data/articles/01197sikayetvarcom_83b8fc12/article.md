---
id: 01197sikayetvarcom_83b8fc12
url: file://01197_sikayetvar_com.md
title: 01197 sikayetvar com
lang: en
created_at: '2025-12-19T23:35:10.541003'
checksum: 6108c9d77f02e0a3a217f1b073814984664fe6fd29f918bb77c62ed11413e7cf
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 151
  char_count: 1098
  num_chunks: 2
  num_sections: 1
---
= Samsung Ekran Cami Kalitesiz! =

Daha önce Samsung i serisinden telefonum düşmüş ve ekranı tuzla buz olmuştu, cam değişimi çok pahalı olduğundan dolaba kaldırıp S3 aldım. Kızıma da Note‑2. Kendimin ki henüz düşmediği için rahatım, zira en alçak yerden bile düşse camının çatlayacağından eminim. Ancak kızımın Note‑2’si düştü ve yine tuzla buz oldu camı. Değişimi için 500‑600 TL istiyorlar. Diğer telefonlarım da düştü ama hiç biri daha önceki i serimdeki ve Note‑2 gibi böyle tuz‑buz olmadı. S3’üm de düşer de tuz‑buz olursa bu son Samsung alışımız olacak. Ekran camınızı güçlendirin derim.

Tülay 47 Okunma 1712486 numaralı şikayet hakkında kullanıcıyla konu hakkında görüşülerek, gerekli bilgilendirmeler yapılmıştır. Değerli müşterimiz, Samsung ürünleri hakkında sormak istediklerinizi 444 77 11 numaralı hattımıza ya da www.samsung.com.tr internet sitemizde “Bize Ulaşın” bölümüne iletebilirsiniz. Saygılarımızla, Samsung Çağrı Merkezi.

Markalar: iPhone, Asus Cep Telefonu, Huawei, Casper Via, Sony Mobile, Vestel Venüs, Reeder, LG Mobile, Lenovo‑Motorola Akıllı Telefonlar, General Mobile.