---
id: 00538maxicepcom_aa62ee07
url: file://00538_maxicep_com.md
title: 00538 maxicep com
lang: en
created_at: '2025-12-19T23:13:24.535948'
checksum: 25ca2eeda7fcf63a21b1c2dce7d8effed03dc62f7645ff577a28fd0c9de9c3bc
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 236
  char_count: 1635
  num_chunks: 2
  num_sections: 1
---
= LG V10'UN FİYATI VE ÇIKIŞ TARİHİ BELLİ OLDU =

== Yeni akıllı telefon 8 Ekim tarihinde ilk olarak Güney Kore'de satışa sunulacak... ==

LG, 1 Ekim yani dün düzenlediği etkinlikle bazı yeni cihazlarını gün yüzüne çıkardı. Bunlar arasında yeni üst seviye akıllı telefonu **LG V10** yer alırken, ayrıca firmanın yeni akıllı saati **LG Watch Urbane 2nd Edition** da gün yüzüne çıktı.

Güney Kore devinin yeni akıllısı LG V10 birçok dikkat çekici özellikle geliyor. Bunlara baktığımızda yeni akıllı telefonun çift ekran ile geldiğini söyleyebiliriz. Ayrıca ön yüzünde çift kamera içeren, paslanmaz çelik çerçevesiyle de dikkat çekiyor.

Bu yeni cihazın satışa sunulacağı ilk ülke, firmanın anavatanı Güney Kore. Firma, 8 Ekim tarihinde LG V10'u yaklaşık **680 $** fiyat etiketiyle satışa sunacak. Diğer pazarlara ise kısa süre içinde sunulması bekleniyor.

LG V10, **5.7 inç** büyüklüğünde ve **2560 × 1440 piksel Quad HD** ekran içerirken, üst kısmında **2.1 inç** (**160 × 1040 piksel**) çözünürlüğünde ikinci bir ekran daha yer alıyor. Bu ekran bazı bildirimleri gösterirken, uygulama kısayollarını da barındırabiliyor. Qualcomm'un altı çekirdekli **Snapdragon 808** yongası gücünü alıyor; grafik işlemcisi ise **Adreno 418**. Yeni cihaz **4 GB** sistem belleği ve **64 GB** dahili depolama kapasitesiyle geliyor.

Akıllı telefonun arka yüzünde **16 MP** kamera bulunurken, ön kamera da **5 MP** çift kamera olarak belirlenmiş. Google Android **5.1.1 Lollipop** işletim sistemi üzerinde çalışan LG V10, **3 000 mAh** batarya ile sunulacak. **MIL‑STD‑810G** seviyesinde darbelere dayanıklı olan cihaz, parmak izi tarayıcısı da içeriyor.