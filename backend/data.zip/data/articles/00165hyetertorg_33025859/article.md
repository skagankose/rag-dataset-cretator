---
id: 00165hyetertorg_33025859
url: file://00165_hyetert_org.md
title: 00165 hyetert org
lang: en
created_at: '2025-12-19T23:01:10.560075'
checksum: 13d783f2af4dda22729f47e00735b409658dea9c221ae1b14eaf254fd524ae46
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 326
  char_count: 2760
  num_chunks: 4
  num_sections: 3
---
= İşgalciler yine iş başında =

İşgalciler yine iş başında – HyeTert İşgalciler yine iş başında İşgalci İsrail ve Ermeni Lobisi, Türkiye'nin üçe bölünmüş haritalarını yayınlayıp, soykırım yalanını beraber yönetiyorlar… Filistin'de işgal ettiği yerlere Yahudileri dolduran terörist İsrail, bölgede Ermenilere de özel statüler kazandırdı. Kadim Kudüs'te Ermenilerin mahallesini özel olarak koruyan Siyonist İsrail, Ermeni kilisesi tarafından hazırlanıp sergilenen Türkiye'nin sözde soykırım haritasını panolarına taşıdı. Sergilenen haritalar, yine İsrail'in terörist güçleri tarafından koruma altına alındı. Türkiye'nin üçe bölünmüş halde gösterildiği haritalara zarar veren kişilere ise, tutuklama cezası veriliyor. Başta Kudüs olmak üzere Filistin'de gasp ettiği bölgeleri işgalcilerle dolduran Siyonist İsrail, bölgedeki Ermenileri memnun etmek için elinden geleni yapıyor. Kadim Kudüs'teki Ermeni mahallesini özel yardımlarla kalkındıran işgalci İsrail, Ermeni nüfusunu arttırdı. Kadim Kudüs'teki küçük mahallede İsrail tarafından korunan Ermeniler, Türkiye'nin üçe bölündüğü sözde soykırım haritası sergiledi. Ermeni kilisesi tarafından hazırlanan sözde soykırım haritasında Türkiye'nin Güneydoğu Bölgesi'nde Kürdistan, Orta Anadolu Bölgesi'nde Ermenistan, Batı bölgesinde ise Osmanlı yazıyor. Turistlerin yoğun olarak gezdiği bölgeyi Türkiye'yi karalamaya yönelik bir propaganda alanına çeviren Ermeni lobisi ve Siyonist İsrail, haritanın varlığını 'ifade özgürlüğü' olarak nitelendiriyor ve haritaya zarar verenleri tutukluyorlar.

== TURİSTLERE KARA PROPANGANDA ==

Ermeni kilisesi tarafından hazırlanan "Ermeni Soykırımı Haritası" yol boyunca panolara yerleştiriliyor. Sözde soykırım paçavrasında Türkiye üçe bölünmüş durumda. Orta Anadolu Bölgesi Ermenistan'a, Güneydoğu Bölgesi Kürdistan'a servis edilen haritanın Batı bölgesinde ise Osmanlı yazıyor. "Tanıma, kınama, önleme" başlıklı bir yazı bulunan haritada gelen turistlere sözde Ermeni soykırımının propagandası yapılıyor. Yalan dolu kâğıt parçasıyla Türkiye'ye sinsi operasyonlar güden işgalci İsrail ve Ermeni lobisi, soykırım yalanını beraber yönetiyor.

== MAHALLEDE TÜRKLERE SALDIRIYORLAR ==

Filistin'de çocuk, yaşlı, kadın, erkek demeden insanlara zulmeden, milyonlarca kişiyi katleden işgalci İsrail, soykırım yalanını içeren haritalarla alakalı özgürlükten bahsediyor. Ermenilere yerleşim yeri yapan, kiliseler açtıran Siyonist İsrail, Ermeni kilisesi tarafından hazırlanan haritalara sesini çıkarmıyor. Hatta kâğıt paçavralarını koruyan İsrail'in terörist güçleri, haritaları yırtan Türk ve Müslüman vatandaşlara tutuklamaya kadar giden cezalar kesiyor. Siyonistlerle birlikte hareket eden Ermeniler, bölgeye giden Türk vatandaşlarını tahrik etmek için Türkçe küfürler edip, saldırıyor.