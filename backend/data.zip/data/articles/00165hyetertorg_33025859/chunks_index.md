# Chunks Index

| ID    | Section                          | Heading Path                                                  | Char Range | Preview                                                                                                |
| ----- | -------------------------------- | ------------------------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | İşgalciler yine iş başında       | İşgalciler yine iş başında                                    | 0-1000     | = İşgalciler yine iş başında = İşgalciler yine iş başında – HyeTert İşgalciler yine iş başında...      |
| c0001 | İşgalciler yine iş başında       | İşgalciler yine iş başında                                    | 800-1535   | ist İsrail, bölgedeki Ermenileri memnun etmek için elinden geleni yapıyor.                             |
| c0002 | TURİSTLERE KARA PROPANGANDA      | İşgalciler yine iş başında > TURİSTLERE KARA PROPANGANDA      | 1537-2122  | == TURİSTLERE KARA PROPANGANDA == Ermeni kilisesi tarafından hazırlanan "Ermeni Soykırımı Haritası"... |
| c0003 | MAHALLEDE TÜRKLERE SALDIRIYORLAR | İşgalciler yine iş başında > MAHALLEDE TÜRKLERE SALDIRIYORLAR | 2122-2760  | == MAHALLEDE TÜRKLERE SALDIRIYORLAR == Filistin'de çocuk, yaşlı, kadın, erkek demeden insanlara...     |