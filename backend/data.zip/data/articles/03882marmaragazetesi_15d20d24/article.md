---
id: 03882marmaragazetesi_15d20d24
url: file://03882_marmaragazetesi_com.md
title: 03882 marmaragazetesi com
lang: en
created_at: '2025-12-20T00:35:07.554629'
checksum: ef3f6db1ab10bb947c714c59eae0db67ecd32bc7c63607b30dc4e7fc6a4a166f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 370
  char_count: 3028
  num_chunks: 4
  num_sections: 1
---
= AK Parti'li Atabek'ten 'Kadın milletvekilleri sahada daha avantajlı' değerlendirmesi =

13:54 05 Aralık 2020  

Atabek, AA muhabirine yaptığı açıklamada, 1934 yılında Türk kadınına siyaset yolunun açıldığını, kadınların siyasi arenada milletvekili, belediye başkanı, muhtar olarak seçilmeye başladığını belirtti. Türk toplumunda kadının rolüne işaret eden Atabek, Kurtuluş Savaşı'nda kadınlara verilen görevlerin, en az 1934'teki seçilme kanunu kadar önemli olduğunu ifade etti.  

Türkiye'nin ilk başörtülü kadın bakan yardımcısı olarak daha önce görev yapan Atabek, "1934 yılındaki bu kanun, dünyada bir ilktir. Kadınlarımız daha görünür hale gelerek etkin mücadelelerini sürdürmüşlerdir. Fakat 1934 yılında çıkarılan kanun en etkin şekilde iktidarımız zamanında uygulanmıştır. Daha öncesinde ülkemizde Tansu Çiller gibi kadın başbakanımız da olmuştur. Fakat sayı olarak kadınların siyasi arenada en etkin olduğu dönem, Sayın Cumhurbaşkanımız Recep Tayyip Erdoğan önderliğindeki AK Parti iktidarı dönemidir." değerlendirmesinde bulundu.  

Kökeninden, inancından, konumundan dolayı ezilen, horlanan, dövülen, sürülen hatta öldürülen milyonlarca insanın yürekleri yakan trajedisi karşısında üzüntülü olduklarını anlatan Atabek, "Elbette bu kötü manzaradan kadınlar nasibini alıyor. Tabii afetlerden savaşlara, kıtlıklardan toplumsal kargaşalara kadar her krizin en ağır faturasını çocuklarıyla birlikte kadınlar ödüyor." diye konuştu.  

AK Parti iktidarları döneminde Türkiye'de kadınlara yönelik pozitif anlamda bir zihniyet devriminin yaşandığına dikkati çeken Atabek, bu zihniyet devrimine başta muhalefet partileri olmak üzere tüm dünyanın şahit olduğunu ve takdir ettiğini söyledi.  

AK Parti iktidarları döneminde artık inancından, dünyaya bakış açısından dolayı hiç kimsenin ötekileştirilmediğini vurgulayan Atabek, "Bugün kadınlarımız, ülke gündemini belirleyen ve etki eden kararlarda etkin rol oynamaktadır. AK Parti'nin kadın milletvekili kontenjan sayısı Türkiye'de bir ilktir. Kısacası AK Parti, kadına verilen önemi sadece lafta bırakmamış, uygulamada da etkin şekilde göstermiştir." dedi.  

"Kadın milletvekillerinin sahada ayrı bir avantajı var" Türkiye'nin her karış toprağında, kendi seçim bölgelerinde kadın milletvekillerinin sahada olmasının çok başka bir his olduğunu dile getiren Atabek, şöyle konuştu: "Kadın milletvekillerinin sahada ayrı bir avantajının olduğunu da belirtmek isterim. Örneğin, erkek milletvekillerimiz vatandaş ile genellikle köy ve kasaba kahvelerinde ya da benzer yerlerde bir araya geliyor. Fakat biz kadın milletvekilleri, genellikle seçmen vatandaşlarımız ile evlerde buluşma gerçekleştiriyoruz. Dolayısıyla halkımızın bizzat içinde yaşadığı durumu gözlemleme durumunu yakalıyoruz; ocakta ne pişiyor, evin durumuna bizzat şahit oluyoruz. Böylece vatandaşımızın gerçek ihtiyaçlarını, ocakta kaynayan çorbasına şahit oluyoruz. Bunun yanı sıra kadınlar elbette kadın milletvekilleriyle daha derin ve sıcak sohbetler gerçekleştiriyor ve bir sorun varsa bunun derinine inebiliyo"