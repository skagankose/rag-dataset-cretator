---
id: 03595saglikaktuelcom_30e848fa
url: file://03595_saglikaktuel_com.md
title: 03595 saglikaktuel com
lang: en
created_at: '2025-12-20T00:30:20.553381'
checksum: ee6d4ea5d64060f73b54c7464c5230336c39d19d7d244ff333beb22d3d593bb1
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 266
  char_count: 1986
  num_chunks: 3
  num_sections: 1
---
Yaz geldi. Kalın giysiler altına saklayamadığımız fazlalıklarımız dert olmaya başladı. Sağlıklı beslenme ve sporla diyet yaparak yavaş yavaş kilo vermek yerine; mucize olarak nitelendirilen ancak içeriğiyle ilgili bilgileri hiçbir zaman net açıklanmayan zayıflama hapları yine gündeme geldi. Ve ne yazık ki yine ölümlerle, yine çok ciddi hasarlarla…

Geçtiğimiz günlerde Meksika Biberi Hapı kullanarak kilo vermeye çalışan Asena Karabacak az kalsın canından oluyordu. Üzerinde hiçbir onay olmayan ve tek kelime de Türkçe bilgi içermeyen Meksika Biber Hapı'nı içen Karabacak, bir haftada 6 kilo verdi. Ancak kendisini “Toksik Hepatit” teşhisiyle yoğun bakımda buldu.

Hisar Intercontinental Hospital, İç Hastalıkları ve Endokrinoloji Bölümü, Obezite ve Diyabet Polikliniği Uzmanı Dr. Halil Kutlu EROL, zayıflama haplarının kesinlikle Sağlık veya Tarım Bakanlığı onaylı olmasını ve doktor kontrolünde kullanılması gerektiğinin altını çiziyor.

Aynı zamanda bu ilaçların obeziteyi de tetikleyebildiğini dile getiren Dr. Halil Kutlu EROL, “Kişi, ‘zayıflama hapları nasıl olsa hızlı bir şekilde kilo verdiriyor, ben canımın istediğini yerim, zayıflama hapını da alırım ve yemeğe devam ederim’ diye düşünüyor. Bu son derece yanlış. Sağlık açısından çok ciddi riskler söz konusu. Çünkü bu tür zayıflama hapları, özellikle amfetamin, metamfetamin veya fenfluramin gibi bağımlılık yapan ve sempatik sinir sistemini aşırı çalıştıran yasaklanmış maddeler içerebiliyor. Kalp hastalarında ritm bozuklukları yapıyor, kalp krizi riskini ortaya çıkarıyor, kalp kapak hastalıkları ve inme riskini artırabiliyor ve genellikle kilo vermeyi sadece geçici olarak sağlıyor.” 

Bu ilaçlarla kişi önce hızlı kilo veriyor. Sonra kilo verme hızı yavaşlıyor. Daima kural şudur: Hızlı verilen kilo, hızlı alınır. Biz, yavaş ve kontrollü kilo verilmesini tavsiye ediyoruz. Çok kilolu bir insan bile olsa, biz hastalarımıza, yavaş, sürdürülebilir ve kontrollü bir kilo verme rejimi öneriyoruz. açıklamasında bulundu.