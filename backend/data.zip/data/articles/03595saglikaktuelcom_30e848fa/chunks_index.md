# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                              |
| ----- | ------- | ------------ | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-1000     | Yaz geldi.                                                                                           |
| c0001 | Lead    | Lead         | 800-1800   | zayıflama haplarının kesinlikle Sağlık veya Tarım Bakanlığı onaylı olmasını ve doktor kontrolünde... |
| c0002 | Lead    | Lead         | 1600-1986  | ellikle kilo vermeyi sadece geçici olarak sağlıyor.” Bu ilaçlarla kişi önce hızlı kilo veriyor.      |