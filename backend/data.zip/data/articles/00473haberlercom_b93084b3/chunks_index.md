# Chunks Index

| ID    | Section                               | Heading Path                          | Char Range | Preview                                                                                           |
| ----- | ------------------------------------- | ------------------------------------- | ---------- | ------------------------------------------------------------------------------------------------- |
| c0000 | Sir Elton John Ankara'ya Ayak Basıyor | Sir Elton John Ankara'ya Ayak Basıyor | 0-1000     | = Sir Elton John Ankara'ya Ayak Basıyor = *Magazin – 21 Haziran 2011, Salı 11:30* Dünyaca ünlü... |
| c0001 | Sir Elton John Ankara'ya Ayak Basıyor | Sir Elton John Ankara'ya Ayak Basıyor | 800-1022   | ak.                                                                                               |