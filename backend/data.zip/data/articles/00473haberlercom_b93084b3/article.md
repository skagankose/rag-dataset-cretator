---
id: 00473haberlercom_b93084b3
url: file://00473_haberler_com.md
title: 00473 haberler com
lang: en
created_at: '2025-12-19T23:11:13.534517'
checksum: 0ab4d9011b43d38bbb551e4036ec91d3b8db30a5626f1d350c849bc2942c5fd4
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 136
  char_count: 1022
  num_chunks: 2
  num_sections: 1
---
= Sir Elton John Ankara'ya Ayak Basıyor =

*Magazin – 21 Haziran 2011, Salı 11:30*

Dünyaca ünlü İngiliz şarkıcı ve besteci Elton John, dünya turnesi kapsamında Türkiye'de 2 konser verecek. Elton John, İstanbul'un ardından, ilk kez Ankara'ya gelerek, 6 Temmuz'da Başkentlilerle buluşacak.

Müziğe katkıları ve AIDS başta olmak üzere birçok yardım projelerinde gösterdiği çabalar nedeniyle 1998 yılında Kraliçe Elizabeth'ten “Sir” unvanı alan John, İstanbul ve Ankara'da vereceği konserlerle hayranlarıyla bir araya gelecek. John Ankara'da ilk kez sahneye çıkmış olacak.

Dünya turnesi kapsamında Türkiye'ye gelecek sanatçı, 5 Temmuz'da İstanbul'da, 6 Temmuz'da ise Başkent Ankara'da konser verecek. Elton John, 6 Temmuz Çarşamba günü Ankara'da vereceği konserle hayranlarına muhteşem bir gece yaşatacak.

Ankara Arena'da düzenlenecek konser, Başkent'in bugüne kadar gerçekleşen en önemli etkinliklerinden biri olarak tarihte yerini alacak. Ankara Arena'daki konser, mekan kapasitesi nedeniyle 8 bin 500 kişi izleyebilecek.