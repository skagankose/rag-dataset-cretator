---
id: 00644haberaktuelcom_e7e1a87d
url: file://00644_haberaktuel_com.md
title: 00644 haberaktuel com
lang: en
created_at: '2025-12-19T23:16:56.563340'
checksum: ed7a38136bbe9e82b4459b10415e4dcf6d46acddd2123cbc1205fcb2808d1563
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 386
  char_count: 3055
  num_chunks: 6
  num_sections: 6
---
= Giriş =

30.01.2009 / 14:23:00 Güncelleme : 30.01.2009 / 14:27:49 Formlarda ailenin üye olduğu dernekler ve sivil toplum örgütleri soruluyor. Okullar tarafından öğrenci velilerine gönderilen "e-okul için öğrenci bilgileri" başlıklı yazıda, "2007-2008 Eğitim ve Öğretim yılı sonunda tüm Türkiye'de öğrenci bilgileri, Milli Eğitim Bakanlığı tarafından kurulan ve geliştirilen e-okul sistemine aktarılmaktadır" denilerek şunlar talep ediliyor: Öğrencinin ve anne-babasının kimlik bilgilerinin yanı sıra, öğrencinin ve anne-babasının sağlık bilgileri, öğrencinin dininin ne olduğuna ilişkin bilgiler, anne-babanın medeni durumuna, anne ve babanın üye olduğu sosyal ve kültürel dernekler, sivil toplum örgütlerine ilişkin bilgiler.

== HASSAS VERİLER ==

Söz konusu formda, öğrencinin geçirdiği ameliyat çeşitleri (apandist, fıtık, göz, kalp, diğer), kullandığı cihazlar (görsel, işitsel, ortopedik, diğer), geçirdiği hastalıklar (çocuk felci, sara, menenjit, havale, diğer), sürekli hastalıkları (alzheimer, astım, böbrek yetmezliği, felç, hepatit, kalp, kanser, parkinson, sara, siroz, şeker, tansiyon, verem, diğer), sürekli kullandığı ilaç (astım, kalp, sara, şeker, diğer) ve dinine ilişkin bilgiler (Budist, Hıristiyan, İslam, Musevi, diğer) isteniyor. Milli Eğitim Bakanlığı'nın e-Okul sistemi için istediği bilgileri Eğitim-Sen Genel Başkanı Zübeyde Kılıç ve Bilgi Üniversitesi Öğretim Üyesi Yrd. Doç. Dr. Leyla Keser Berber NTVMSNBC'ye değerlendirdi.

=== Zübeyde Kılıç (Eğitim-Sen Genel Başkanı) ===

**RESMEN BİR FİŞLEME ÖRNEĞİ**  
Uygulamanın, sadece veliye öğrenciyle ilgili gerekli olan bilgileri ulaştırması veya okul tarafından veliyle ilgili eğitim-öğretim açısından gerekli bilgilere anında ulaşılabilmesini amaçlaması gerekiyor. Fakat bu örnek resmen bir fişleme örneği. Birçok kurumda rastlanan, açıkça fişleme örneği.

=== BELİRLİ BİR NİYETE HİZMET EDEN UYGULAMALAR ===

Veliler çok açık ve rahat davranarak bu bilgileri verdiğinde, velilerin ve öğrencilerin fişlenmesine neden olacak. Ayrıca bu bilgileri alan ve değerlendiren öğretmenlerin, velilerin üye oldukları bu kurumları baz alarak öğrenciye karşı tavır ve davranışlarını farklılaştırması gibi sonuçlara yol açabilecektir. Bu açıdan problemlidir. Bu tür soruların kesinlikle bu tür formlarda olmaması gerekir. Bunlar amaçlı ve belirli bir niyete hizmet eden uygulamalardır.

=== AMAÇ DIŞINA SAPMIŞ ===

Genel anlamda bir e-okul uygulaması var fakat hazırlanan özel soruların formatlarını, içindeki bilgileri, içeriklerini okullar kendilerine göre de değiştirebiliyorlar. Onlar bunu zenginleştirme, farklılaştırma anlamında düşünüyorlar ama bu noktada tek standart üzerinden gidebileceğimiz bir uygulama yok. Ancak görülüyor ki, bu uygulama amaç dışına sapmış. Uygulama problemli ve e-okul uygulamasının amaç ve hedeflerini aşan bir durum.

=== BİZE DE ŞİKAYETLER GELDİ ===

Direkt e-okul uygulaması kapsamında olmasa bile o bağlamda gösterilerek özellikle ekonomik durumları iyi olmayan öğrencilerin bizzat evdeki tek tek ihtiyaçlarına kadar öğreniliyor. Öğrencinin ekonomik dur