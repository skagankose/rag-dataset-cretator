---
id: 02122olaycomtr_38d2ffd2
url: file://02122_olay_com_tr.md
title: 02122 olay com tr
lang: en
created_at: '2025-12-20T00:05:47.518615'
checksum: d33ac7971ab5eb26a74e2b5cb28ffa9b92c2a1a4b47c30308f24d510ac2c878c
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 172
  char_count: 1280
  num_chunks: 2
  num_sections: 1
---
= Haber duyuldu! 3 saat içinde herkes kaçtı =

Haber duyuldu! 3 saat içinde herkes kaçtı - Olay Gazetesi Bursa Ana Sayfa › Gündem › Haber duyuldu! 3 saat içinde herkes kaçtı  

Trabzon'un Akçaabat ilçesi Adacık Mahallesi, artan koronavirüs vakaları nedeniyle dün saat 21.00'den itibaren karantinaya alındı. Ancak 3 saat önce duyurulan kararı öğrenenler, apar topar mahalleden kaçtı. Jandarma ekipleri mahallenin tüm giriş ve çıkış noktalarını kapatarak önlem aldı.  

**Giriş:** 05-12-2020 13:30  

Sağlık Bakanı Fahrettin Koca'nın koronavirüs vaka sayısında ciddi artış olan iller arasında açıkladığı Trabzon'da tedbirler artırıldı. Kentte vaka sayılarında yüzde 50 artış yaşanırken, bazı yerleşim alanları karantinaya alınmaya başlandı.  

Akçaabat ilçesinde vaka ve temaslı sayısı artışı yaşanan 620 haneli, 1275 nüfuslu Adacık Mahallesi de İl Hıfzıssıhha Kurulu'nca ikinci bir emre kadar dün akşam saat 21.00'den itibaren geçerli olmak üzere karantinaya alındı.  

Adacık Mahallesi Muhtarı Selahattin Gedikli, karantina kararından birkaç saat önce haberdar olduklarını belirterek, “Karantina kararından çok önceden kimsenin haberi yoktu. Karar duyulunca işi gücü olanlar mahalleyi terk etti. Böyle bir karmaşa yaşandı. Jandarma ekiplerimiz hemen giriş çıkışları kapattı” dedi.