# Chunks Index

| ID    | Section                                   | Heading Path                              | Char Range | Preview                                                                                            |
| ----- | ----------------------------------------- | ----------------------------------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Haber duyuldu! 3 saat içinde herkes kaçtı | Haber duyuldu! 3 saat içinde herkes kaçtı | 0-1000     | = Haber duyuldu!                                                                                   |
| c0001 | Haber duyuldu! 3 saat içinde herkes kaçtı | Haber duyuldu! 3 saat içinde herkes kaçtı | 800-1280   | 20 haneli, 1275 nüfuslu Adacık Mahallesi de İl Hıfzıssıhha Kurulu'nca ikinci bir emre kadar dün... |