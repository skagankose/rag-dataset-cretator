# Dataset: 01805 tr tradingview com

Generated on: 2025-12-19T23:55:35.659672
Total questions: 1

| # | Question                                                                                                           | Answer | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------------------------------ | ------ | -------- | ----------------- |
| 1 | Yazar, BİST 100'ün hangi seviyenin üstünde kalıcı olamaması durumunda 70 binli seviyelere çekileceğini belirtiyor? | 98bin  | FACTUAL  | c0000             |