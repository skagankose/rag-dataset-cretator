---
id: 01805trtradingviewco_cb5dc7cb
url: file://01805_tr_tradingview_com.md
title: 01805 tr tradingview com
lang: en
created_at: '2025-12-19T23:55:27.543704'
checksum: f5388d56888360ba0a8f8d2d62ead5445649ce40696bf75bb343f0637a56f997
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 89
  char_count: 671
  num_chunks: 1
  num_sections: 1
---
= GLOBAL ÇÖKÜŞ – SONLANAN DİAGONAL =

kaganaybar1 tarafından BIST:XU100 sembolü için GLOBAL ÇÖKÜŞ ? SONLANAN DİAGONAL! — TradingView GLOBAL ÇÖKÜŞ ? SONLANAN DİAGONAL! Trend Analysis Wave Analysis Beyond Technical Analysis BIST bist100 XU100 trendanalysis waveanalysis beyondta bist bist100 xu100

BİST 100 endeksinin 120 binlerde sonlanan diagonal yaptığını düşünüyorum, eğer yanlış saymıyorsam. Ayrıca Omuz Baş Omuz formasyonu mevcudiyette görünüyor. Yorumum o ki BİST 100 "98bin" Seviyesinin üstünde kalıcı olamazsa 70 binli seviyelere hızlıca çekilecek ve ayı piyasasının başlamış olduğunu bize gösterecektir. BU SADECE BİR GÖRÜŞTÜR LÜTFEN KENDİNİZ DE DEĞERLENDİRİNİZ.