# Chunks Index

| ID    | Section                          | Heading Path                     | Char Range | Preview                                                                                            |
| ----- | -------------------------------- | -------------------------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | GLOBAL ÇÖKÜŞ – SONLANAN DİAGONAL | GLOBAL ÇÖKÜŞ – SONLANAN DİAGONAL | 0-671      | = GLOBAL ÇÖKÜŞ – SONLANAN DİAGONAL = kaganaybar1 tarafından BIST:XU100 sembolü için GLOBAL ÇÖKÜŞ ? |