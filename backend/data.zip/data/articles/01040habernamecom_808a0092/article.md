---
id: 01040habernamecom_808a0092
url: file://01040_habername_com.md
title: 01040 habername com
lang: en
created_at: '2025-12-19T23:30:08.540518'
checksum: 3694e8cff793fa8cc5cbabd34174410b894f2fbaecdb9c1c8647d64c10e42408
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 172
  char_count: 1364
  num_chunks: 2
  num_sections: 1
---
= Mehmetçiğin vurduğu öldürücü darbe =

*01.11.2011 08:45 - Haber Name*

Mehmetçiğin PKK terör örgütüne yönelik yaptığı operasyonlarda ölen terörist sayısını örgüt kendisine yakın internet sitesinden duyurdu. Milletvekili Demir Çelik, 4 cenazenin kimliğinin belirlendiğini söyledi. Kimlikleri tespit edilemeyen teröristler için ailelerden DNA örnekleri alındığını anlatan Çelik, iki haftalık süreçte diğer cenazelerin de isimlerinin belirleneceğini belirtti.

Cenazeleri daha önce aileleri tarafından alınan Ebru Muhinkancı İstanbul'da, Çetin Modanlar Urfa'da, Sezar Arslan ise Muş Korkut'ta defnedilmişti. Öte yandan, cenazeleri almaya Cizre, Suruç, Mezopotamya belediyelerine ait ambulans ve cenaze nakil araçlarının gelmesi dikkat çekti.

Terör örgütü PKK'ya yakınlığı ile bilinen bir internet sitesi, Türk Silahlı Kuvvetleri tarafından Hakkari'nin Çukurca ilçesi kırsalında gerçekleştirdiği operasyon sonrası 35 teröristin kaybolduğunu açıkladı. En az 24 teröristin öldüğü belirtilen açıklamada, 11 PKK'lının da kayıp olduğu belirtildi.

CİHAN Etiket(ler): haber, Emine Ayna, Demir Çelik, Türk Silahlı Kuvvetleri, Emine Ayna, PKK PKK NIN DESTEKÇİLERİ PKK terör örgütünün siyasi desteği ve mali kaynakları kurutulmadan sorunun nihai çözümü mümkün değildir. TBMM çatısı altında teröre destek veren milletvekilleri varken PKK ile mücadelenin hiç bir anlamı olmaz.