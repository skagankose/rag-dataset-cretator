# Chunks Index

| ID    | Section                            | Heading Path                       | Char Range | Preview                                                                                           |
| ----- | ---------------------------------- | ---------------------------------- | ---------- | ------------------------------------------------------------------------------------------------- |
| c0000 | Mehmetçiğin vurduğu öldürücü darbe | Mehmetçiğin vurduğu öldürücü darbe | 0-1000     | = Mehmetçiğin vurduğu öldürücü darbe = *01.11.2011 08:45 - Haber Name* Mehmetçiğin PKK terör...   |
| c0001 | Mehmetçiğin vurduğu öldürücü darbe | Mehmetçiğin vurduğu öldürücü darbe | 800-1364   | esi, Türk Silahlı Kuvvetleri tarafından Hakkari'nin Çukurca ilçesi kırsalında gerçekleştirdiği... |