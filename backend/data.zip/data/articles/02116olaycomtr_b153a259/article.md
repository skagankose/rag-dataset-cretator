---
id: 02116olaycomtr_b153a259
url: file://02116_olay_com_tr.md
title: 02116 olay com tr
lang: en
created_at: '2025-12-20T00:05:41.510553'
checksum: 7fdb780ae40d4edd0d5591dad766a7311ce1953ecc3992c3b36d1e25e01b561e
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 45
  char_count: 339
  num_chunks: 1
  num_sections: 1
---
= Otomobil devrildi: 1 ölü, 2 yaralı =

**Giriş:** 22-09-2021 14:55  
Şeyma C'nin kullandığı otomobil, Kantar mevkisinde yoldan çıkarak devrildi. Kazada, sürücü Şeyma C. olay yerinde yaşamını yitirdi. Sürücünün 6 yaşındaki kızı E.E.C. ile annesi N.G. yaralandı. Sağlık ekipleri tarafından hastaneye kaldırılan yaralıların tedavisi sürüyor.