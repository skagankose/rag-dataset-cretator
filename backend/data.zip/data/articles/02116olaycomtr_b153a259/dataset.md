# Dataset: 02116 olay com tr

Generated on: 2025-12-20T00:05:50.349904
Total questions: 1

| # | Question                                            | Answer   | Category | Related_Chunk_IDs |
| - | --------------------------------------------------- | -------- | -------- | ----------------- |
| 1 | Kazada olay yerinde yaşamını yitiren sürücü kimdir? | Şeyma C. | FACTUAL  | c0000             |