# Chunks Index

| ID    | Section                            | Heading Path                       | Char Range | Preview                                                                                                |
| ----- | ---------------------------------- | ---------------------------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Otomobil devrildi: 1 ölü, 2 yaralı | Otomobil devrildi: 1 ölü, 2 yaralı | 0-339      | = Otomobil devrildi: 1 ölü, 2 yaralı = **Giriş:** 22-09-2021 14:55 Şeyma C'nin kullandığı otomobil,... |