# Chunks Index

| ID    | Section               | Heading Path          | Char Range | Preview                                                               |
| ----- | --------------------- | --------------------- | ---------- | --------------------------------------------------------------------- |
| c0000 | Takı Takmak Günah mı? | Takı Takmak Günah mı? | 0-1000     | = Takı Takmak Günah mı?                                               |
| c0001 | Takı Takmak Günah mı? | Takı Takmak Günah mı? | 800-1800   | z var ve kolu bacağı yok; oyun hamurundan hazırlanıyor, gövdesi var.  |
| c0002 | Takı Takmak Günah mı? | Takı Takmak Günah mı? | 1600-2146  | r takıların takılması caiz değildir, kaçınılması en doğru karar olur. |