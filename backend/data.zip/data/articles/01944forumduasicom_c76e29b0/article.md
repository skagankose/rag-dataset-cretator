---
id: 01944forumduasicom_c76e29b0
url: file://01944_forumduasi_com.md
title: 01944 forumduasi com
lang: en
created_at: '2025-12-20T00:00:05.543383'
checksum: ec98628a17698ea347a9ffb887957aa209ba0d61f55cae853724a11cf55643d8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 299
  char_count: 2146
  num_chunks: 3
  num_sections: 1
---
= Takı Takmak Günah mı? =

Selamun Aleykum. Bileklik, kolye gibi takıların takılması günah mıdır? Ama İslam dairesi içindeki bileziklerden bahsediyorum. Bildiğim kadarıyla diğerleri günah oluyordu. Farz‑ı Misal bilekliğin üzerinde “Diyanet Vakfı” yazıyorsa bizim o bilekliği takmamızda bir sakınca var mıdır? Umarım anlatabilmişimdir. Allah’a emanet olun 🙂

Yorum: Takı Takmak Günah mı?  
Arifselim: Takılarda erkeklerin kadınlara mahsus olan zinetleri kullanmaları caiz değildir. Ayrıca kibre vesile olmamalı ve bu takılarda uygunsuz simgeler ve yazılar olmamalıdır. Okudunuz mu?

Her Gün Kısa Duş Almak, Her Hafta Oda Temizliği Yapmak Aşırılık Olup Günah Olur Mu?  
Yorum: Takı Takmak Günah mı?  
Kayıtsız. Üye Mrb: Bende kuzenlerimle birlikte kolye yaptıracaktık. Bu kolye de gülen yüz, şal bir kız var ve kolu bacağı yok; oyun hamurundan hazırlanıyor, gövdesi var. Sadece biz bu kolyeleri takarsak günah olur mu? İnşallah anlatabilmişimdir. Ya bu kolyeler olmaz, çiçekli kolyeler de günah olur mu? Okudunuz mu?

Namazda Okunan Rabbena Duaları  
Yorum: Takı Takmak Günah mı?  
Arifselim: Merhaba. Kolye takmak kızlar için caizdir. Tam bir canlı resmi yoksa gülen yüz gibi, kullanılması haram olmasa da canlıya ait bir şey olması doğru değildir. Çiçekli süslerle kolyeler takmak caizdir. Kadınların süslerini yabancı erkeklere göstermeleri ise haramdır.

Seyyah_26: Selamun aleykum. Üzerinde tuğra resmi bulunan takıları takmak caiz midir? Belirgin şekilde besmele okunmuyor. Sadece tuğra şekli ama yine de tereddüt ettim. Okudunuz mu?

Fotoğraf makinesiyle fotoğraf çekmek günah mı?  
Ensar: Bu tür takıların takılması caiz değildir, kaçınılması en doğru karar olur. Müslüman erkek için takılması gereken tek şey gümüş bir yüzüktür. Altının takılması erkeğe haram, bakır, demir vs. gibilerinin takılması mekruhtur.

Seyyah_26: Merhaba. Ben bir bayanın üzerinde tuğra resmi bulunan altın kolye takması caiz midir diye sormak istemiştim. Okudunuz mu?

Evlilikte nasip aranır mı?  
Ensar: Bayanın altın takması caizdir, fakat resimli olarak takılması caiz değildir. Altında bulunan o resmin çekilmesi en isabetli hareket olur.

Kalın, sağlıcakla.