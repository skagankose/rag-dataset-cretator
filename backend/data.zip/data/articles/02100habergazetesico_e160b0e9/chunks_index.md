# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                                                                              |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Çukurova Biyoçeşitlilik Müzesi Eylül'de açılacak | Çukurova Biyoçeşitlilik Müzesi Eylül'de açılacak | 0-632      | = Çukurova Biyoçeşitlilik Müzesi Eylül'de açılacak = Adana Valisi Mahmut Demirtaş, yaklaşık 2 bin... |