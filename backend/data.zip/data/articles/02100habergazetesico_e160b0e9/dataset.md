# Dataset: 02100 habergazetesi com tr

Generated on: 2025-12-20T00:05:25.785470
Total questions: 1

| # | Question                                                                   | Answer                        | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------------------------- | ----------------------------- | -------- | ----------------- |
| 1 | Çukurova Biyoçeşitlilik Müzesi'nin kapalı alanı yaklaşık kaç metrekaredir? | Yaklaşık 2 bin 600 metrekare. | FACTUAL  | c0000             |