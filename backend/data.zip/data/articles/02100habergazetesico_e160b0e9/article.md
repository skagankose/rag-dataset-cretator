---
id: 02100habergazetesico_e160b0e9
url: file://02100_habergazetesi_com_tr.md
title: 02100 habergazetesi com tr
lang: en
created_at: '2025-12-20T00:05:16.520360'
checksum: a0f9f1bda39b6274ebcc4ff7bde2940f7452440fe4b70a65b8bdc2ec8036e992
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 78
  char_count: 632
  num_chunks: 1
  num_sections: 1
---
= Çukurova Biyoçeşitlilik Müzesi Eylül'de açılacak =

Adana Valisi Mahmut Demirtaş, yaklaşık 2 bin 600 metrekare kapalı alana sahip Çukurova Biyoçeşitlilik Müzesi'nde incelemelerde bulundu. Yetkililerden bilgi alan Vali Demirtaş, kentin zenginliklerini tanıtmak, gelecek nesillere aktarmak ve farkındalık oluşturmak amacıyla kentte kurulacak olan Çukurova Biyoçeşitlilik Müzesi'nin yapılacağı alanda incelemelerde bulunduklarını söyledi. Vali Demirtaş, Adana ve bölgesinde yaşayan endemik türler dahil bitki, kuş, memeli, sürüngen, balık, amfibi ve yok olan türlerin de tanıtılacağı müzenin kente ve bölgeye hayırlı olmasını diledi.