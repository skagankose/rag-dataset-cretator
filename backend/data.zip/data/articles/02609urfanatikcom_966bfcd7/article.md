---
id: 02609urfanatikcom_966bfcd7
url: file://02609_urfanatik_com.md
title: 02609 urfanatik com
lang: en
created_at: '2025-12-20T00:13:54.518598'
checksum: 89580eb5a1f06a411c7e766182c389631b2d1a48de2ad38ecd852b794289579d
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 145
  char_count: 1099
  num_chunks: 1
  num_sections: 1
---
= Şanlıurfa'da otomobil ile tır kafa kafaya çarpıştı: 1 Ölü, 1 yaralı =

Şanlıurfa-Mardin karayolunun 73'üncü kilometresi direksiyon hakimiyetini kaybeden otomobil sürücüsü karşı şeride uçarak tıra çarptı. Kazada otomobil sürücüsü hayatını kaybetti.

Kaza Şanlıurfa-Mardin karayolunun 73'üncü kilometresi Viranşehir ilçesi yakınlarında yaşandı. Edinilen bilgilere göre Mustafa Elgün'ün (33) kullandığı 35 KFF 82 plakalı otomobil, sürücünün direksiyon hakimiyetini kaybetmesi sonucu karşı şeride geçerek Şerif S.'nin kullandığı 33 ACE 113 plakalı tırla çarpıştı.

Kazayı gören diğer sürücüler durumu hemen sağlık ekiplerine haber verdi. Otomobilin içerisinden çıkarılan Mustafa Elgün'ün olay yerinde hayatını kaybettiği tespit edildi, tır sürücüsü Şerif S. ise yaralandı. Mustafa Elgün'ün cenazesi olay yerinde yapılan incelemelerin ardından Adli Tıp Morguna kaldırıldı.

= otomobil, Son dakika haber |, Son dakika haberleri |, # Son dakika haberleri |, olay, Sağlık, Şanlıurfa, kaza, Asayiş, viranşehir son dakika kaza haberleri, Viranşehir yolu kaza, yaralı, Otomobil İle Tır Kafa Kafaya Çarpıştı =