# Dataset: 02609 urfanatik com

Generated on: 2025-12-20T00:14:04.227396
Total questions: 1

| # | Question                                                         | Answer             | Category | Related_Chunk_IDs |
| - | ---------------------------------------------------------------- | ------------------ | -------- | ----------------- |
| 1 | Kazada hayatını kaybeden otomobil sürücüsünün adı ve yaşı nedir? | Mustafa Elgün (33) | FACTUAL  | c0000             |