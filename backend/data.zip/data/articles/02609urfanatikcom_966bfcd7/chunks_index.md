# Chunks Index

| ID    | Section                                                             | Heading Path                                                        | Char Range | Preview                                                                                     |
| ----- | ------------------------------------------------------------------- | ------------------------------------------------------------------- | ---------- | ------------------------------------------------------------------------------------------- |
| c0000 | Şanlıurfa'da otomobil ile tır kafa kafaya çarpıştı: 1 Ölü, 1 yaralı | Şanlıurfa'da otomobil ile tır kafa kafaya çarpıştı: 1 Ölü, 1 yaralı | 0-871      | = Şanlıurfa'da otomobil ile tır kafa kafaya çarpıştı: 1 Ölü, 1 yaralı = Şanlıurfa-Mardin... |