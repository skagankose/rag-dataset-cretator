---
id: 03058seylereksisozlu_adcbe294
url: file://03058_seyler_eksisozluk_com.md
title: 03058 seyler eksisozluk com
lang: en
created_at: '2025-12-20T00:21:23.550554'
checksum: 22fc92183a697a1dc00d1039c6afd9f66fd7aaad8ba04e3b742c401a8f5413de
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 372
  char_count: 2948
  num_chunks: 4
  num_sections: 1
---
= Muhabbet Kavramının Nelere Kadir Olduğunu Kelimenin Arapça Kökeni Üzerinden Açıklayan Bir Yazı =

**Ekşi Şeyler – Edebiyat**  
1 Ağustos 2017 • 33,5b • 396 okunma • Paylaşım

Sözlük yazarı **highfly**, *muhabbet* kelimesini Arapça kökenlerine ayırarak kelimenin sevgi ile olan ilişkisini açıklıyor ve günlük hayatta kullandığımız kelimelerin daha derin anlamlar içerdiğini gösteriyor.

*Muhabbet*, Arapça “sevgi” anlamına gelen **hubb** sözünden gelmektedir. Bu **hubb** sözünden “dost, sevgili” anlamlarından **habib** kelimesi türemiştir. Aynı zamanda “sevilen” anlamında **mahbûb** sözü de öyle. “Sevgi göstermek” anlamında bugün kullanmadığımız **ihabb** kelimesinden “dost, sevgili, sevgi gösteren...” anlamlarında **muhibb** sözü türemiştir.

Kanuni Sultan Süleyman’ın şair olarak mahlası **muhibbi** buradan gelir. Kanuni iyi bir şair değildir ama klasik şiirin en büyüklerinden olan Baki’ye el uzatarak onu, deyim yerindeyse, keşfetmiştir. Kanuni “saltanatımın en keyifli işi Baki’yi tanımaktı.” demiştir (kaynak: Fuad Köprülü, *Türk Edebiyatı Tarihi*).

Aslen **mahabbet** olan kelime Osmanlıca dil bilgisinde *mimli masdar* türünde bir kelimedir ve bu **hubb** kelimesinden gelir. “Sevgi” anlamındadır. Osmanlıca içerisinde “mu” ile başlayan pek çok kelimeden etkilenerek (bkz: analogi) *muhabbet* şekline dönüşmüştür.

Bugün *muhabbet* kelimesi “sevilen kişi ile edilen sohbet, konuşma, görüşme” fiilini karşılamaktadır. Esas olarak bu fiili karşılayan kelime ise Arapça içerisinde **sohbet**’tir. Arapça orijinali *suhbet* olan kelimenin faili *sâhib*’dir. Biri sizi seviyor, sizi sohbetine layık görüyorsa sizin sahibinizdir, siz de onun.

Osmanlı devrinde padişahlar sohbetini hoş buldukları şairleri himayeleri altına alırlardı (bkz: patronaj). Bu şairler şura meclislerinde, nam‑ı diğer işret meclislerinde hâmileri olan padişahlara veya büyük devlet adamlarına şiirler okur, kasideler sunarlardı. Bu şairlere padişahların sohbetine layık görüldükleri ve onlara dostluk ettikleri için **musâhib** denirdi ki bu kelime de *sohbet* kelimesinden gelir.

Örnek vermek gerekirse Kanuni‑Baki dostluğu herkesin malumudur. Karşılıklı yapılan yani işteş sohbet’e **musahabet** denir ki **musahib** bu kelimenin öznesidir. Son olarak Hz. Muhammed’i görebilmiş ve onun sohbetine nail olabilmiş kişilere *sâhib* kelimesinin çoğulu olan **sahabe** denmiştir. Bu kelimenin diğer bir çoğulu ise **ashâb**’dır.

Türkçedeki “sevgi” sözü **sevmek** fiilinden gelir. Eski Türkçe hâli **seb‑tir**. **b > v** değişimi ile bugünkü hâlini almıştır. **Sevgi** kelimesine getirilen sıfat eki ile **sevgilisözü** türetilmiştir. Türkçe “aşk” anlamına gelen gelen söz **sevi**’dir. Aşk kelimesi ve kendisinden türeyen kelimeler hakkında pek çok kişi şu duyguyu yaşamıştır; birini severken beslenilen hisleri abartıyor gibi olmamak için “sevmiyorum da hoşlanıyorum” diye insan kendini kandırır. **Hoş** sözü Farsça olup Türkçe isimden fiil yapım eki almıştır.