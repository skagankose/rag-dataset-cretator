# Chunks Index

| ID    | Section         | Heading Path    | Char Range | Preview                                                                                            |
| ----- | --------------- | --------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | JR.Art Direktör | JR.Art Direktör | 71-1071    | == JR.Art Direktör == Kuyumculuk sektöründe faaliyet gösteren firmamızın aşağıdaki niteliklere...  |
| c0001 | JR.Art Direktör | JR.Art Direktör | 871-1737   | ktır sektörün ve 40 yıldır mücevher üretiminin içinde olan yeni adıyla Piano Jewellery; zamanın... |