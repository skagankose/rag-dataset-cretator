---
id: 01236yenibiriscom_b734ad6d
url: file://01236_yenibiris_com.md
title: 01236 yenibiris com
lang: en
created_at: '2025-12-19T23:36:29.530390'
checksum: 76a0e6fd375694a191fbea9d6563886c46f061aead61ccdc3658c6e92526cb0b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 221
  char_count: 1737
  num_chunks: 2
  num_sections: 1
---
= PİANO KUYUMCULUK SAN. VE TİC. LTD. ŞTİ - JR.Art Direktör İş İlanı =

== JR.Art Direktör ==

Kuyumculuk sektöründe faaliyet gösteren firmamızın aşağıdaki niteliklere sahip "JR.Art Direktör" arayışı bulunmaktadır. Photoshop, İllustratör, Premier vb. programları çok iyi derecede kullanabilen, Sosyal medya yönetimi konusunda en az 2 yıl tecrübeli, Sosyal medya ve farklı digital mecralarda kullanılmak üzere tasarımlar oluşturabilen, Sosyal medyayı ve mecra dinamiklerini bilen; işin tüm süreçlerini takip edebilecek, kreatif konsept fikri geliştirmede ve bunu bitmiş tasarım olarak uygulamada kuvvetli, grafik tasarım alanında en az 3 yıl tecrübeli, digital ve basılı iş dinamiklerinde yetkin, özgün tasarım, planlama ve koordinasyon yeteneği güçlü, çözüm odaklı düşünebilen, iletişim becerileri kuvvetli, detaylara önem veren, grafik tasarım uzmanı / grafiker.

Üç kuşaktır sektörün ve 40 yıldır mücevher üretiminin içinde olan yeni adıyla Piano Jewellery; zamanın ruhunu yakalayarak birçok konuda ilklere imza atan çalışmaları ile çağın getirdiği hızla hareket etmeye odaklanmış bir firmadır.

Laboratuvar sistemiyle çalışan firmamız, farklı teknik ve detayları birleştirerek, mücevher tasarım ve üretiminde faaliyet gösteren birçok firmadan ayrışmaktadır; rodaj, sıcak ve soğuk mine uygulamaları, deneysel tasarım geliştirme yöntemleriyle mücevher üretiminde farklı bir noktada yer almaktadır.

Değerli taşların tedariki, uygulanması ve tasarımlarla harmanlanması konusunda da başarılı olan firmamız, tecrübeli ve titiz ekibiyle kusursuz ürünler çıkarmaktadır. Bugün birçok markaya üretim yapan Piano Jewellery, geleneksel tasarımlardan, üretilmesi yüksek teknik yeterlilik ve işçilik isteyen birçok ürünü ustalıkla üretebilmektedir.