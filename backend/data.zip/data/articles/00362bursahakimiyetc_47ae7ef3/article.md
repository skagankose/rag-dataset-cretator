---
id: 00362bursahakimiyetc_47ae7ef3
url: file://00362_bursahakimiyet_com_tr.md
title: 00362 bursahakimiyet com tr
lang: en
created_at: '2025-12-19T23:07:40.528849'
checksum: 9d05bd2490ca0657cf4c0a0169b6d5d9320ebc93760381c3cbe9eddb75db9256
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 404
  char_count: 3028
  num_chunks: 5
  num_sections: 4
---
= Trafik kazası sebebiyle tazminat davası - Av. Veysel TAYYAR - Bursa Hakimiyet =
**Giriş Tarihi:** 12.08.2021 08:08  

Bilindiği üzere geçtiğimiz günlerde meşhur bir seyahat firmasına ait yolcu otobüsü Balıkesir'in Edremit ilçesinde hakimiyetini kaybetmiş ve yoldan çıkarak taklalar atmıştı. Bu kaza sonrası 16 kişi ölmüş ve birçok kişi de yaralanmıştı. Kazadan sonra yaralananların ya da vefat eden yolcuların yakınlarının maddi manevi zararlarını kime ne şekilde yöneltebileceği sıkça gündeme geldi. Ben de bu elim kaza üzerine yaralamalı ve ölümlü kazalarda tazminat davalarını ve sigorta şirketlerinin bu davalardaki sorumluluğunu sizler için kaleme aldım.

== Maddi tazminat türleri ==
Trafik kazası sebebiyle maddi tazminat genelinde iki tür tazminat talep edilebilmektedir:  

1. **Güç ya da Efor Kaybı Tazminatı.**  
2. **Destekten Yoksun Kalma Tazminatı.**  

Tabii yaralanan kişi ya da vefat eden kişinin mirasçıları bu kaza sonrası yaşadıkları travma, korku, üzüntü ve elem sebebiyle ayrıca manevi tazminat da talep edebilmektedir.

== Trafik kazası sonrası güç kaybı tazminatı nedir? ==
Trafik kazası sebebiyle kişinin dâimi olarak sakatlanması yahut malul duruma gelmesi durumunda hak kazanacağı tazminata efor/güç kaybı tazminatı denmektedir. Şehir içi ya da şehirlerarası bir karayolunda şahsi aracınızda ya da yolcu taşıma aracında, sürücü ya da yolcu ya da hatta yaya konumundayken geçirdiğiniz bir trafik kazası sonrası malul duruma gelmişseniz kusurlu aracın trafik ve kasko sigorta şirketinden çok ciddi miktarlarda tazminat talep edebilirsiniz. Bunun için öncelikle ilgili yasa gereği sigorta şirketine yazılı olarak başvurmalısınız. Tabi başvururken sonuca etkili olacak tüm belgeleri de başvuru ekinde göndermek de gerekiyor. Başvuru üzerine ödeme yapılmaması halinde ise asliye ticaret mahkemelerinde tazminat davası açılması mümkün. Kazazedenin kazadaki kusur oranı, maluliyet oranı, yaşı, eğitim durumu ve geliri tazminatın hesaplanmasında önem arz ediyor.  

> **"BENİM KALICI BİR HASARIM YOK BEN TAZMİNAT ALAMAM."** DEMEYİN!  
> Kazayı birkaç kırıkla veya zedelenmeyle atlatmış ya da 8 yıllık zamanaşımı süresi içerisinde tamamıyla iyileşmiş olsanız dahi yetkili kurumlardan alınacak maluliyet raporları sizi çok şaşırtabilir, hatta hayatınızın değişmesine sebep olabilir. Kaza sonrası sadece doku zedelenmesi problemi yaşayan birinin dahi ortalama %5 malul duruma geleceğini unutmayın.

== Destekten yoksun kalma tazminatı ==
Trafik kazasında vefat etmiş olan kişinin desteğine muhtaç olan kişilerin (eşi, çocukları, ana-babası, kardeşleri vs.) kazazedenin vefatı sebebiyle yoksun kaldıkları destek gereği hak kazandıkları tazminata destekten yoksun kalma tazminatı denmektedir. Trafik kazasında eşini kaybeden birinin acısı muhakkak ki tarif edilemez. Ancak vefat eden kişinin geride kalan eşinin, çocuklarının, ana babasının yahut kardeşlerinin kusurlu tarafın sigorta şirketine başvurarak yoksun kaldıkları desteği talep etmeleri de en doğal haklarıdır.

== Bu tazminatta kıstas ne olacaktır? ==