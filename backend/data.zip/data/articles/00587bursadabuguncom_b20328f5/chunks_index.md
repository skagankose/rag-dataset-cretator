# Chunks Index

| ID    | Section              | Heading Path         | Char Range | Preview                                                                                      |
| ----- | -------------------- | -------------------- | ---------- | -------------------------------------------------------------------------------------------- |
| c0000 | Yüzüklerin kraliçesi | Yüzüklerin kraliçesi | 0-1000     | = Yüzüklerin kraliçesi = Yüzüklerin kraliçesi BALIKESİR'in Edremit İlçesi'nde, gümüş takı... |
| c0001 | Yüzüklerin kraliçesi | Yüzüklerin kraliçesi | 800-1528   | zlediğini anlattı.                                                                           |