---
id: 00587bursadabuguncom_b20328f5
url: file://00587_bursadabugun_com.md
title: 00587 bursadabugun com
lang: en
created_at: '2025-12-19T23:15:01.531210'
checksum: 1527a14af13b3fd910ff6a7f7e9cf535e8ce698219ff23486bea50a1fda6423f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 208
  char_count: 1528
  num_chunks: 2
  num_sections: 1
---
= Yüzüklerin kraliçesi =

Yüzüklerin kraliçesi BALIKESİR'in Edremit İlçesi'nde, gümüş takı koleksiyonu yapan Zehra Kızılgün, yüzükleri ve koluna taktığı zincirleriyle ilgi odağı oluyor.

10 Eylül 2013 Salı, 13:19

Bir reklam şirketinin sahibi olan 43 yaşındaki Zehra Kızılgün, ünlü sanatçı merhum Barış Manço'ya olan hayranlığının kendisini gümüş takılara yönelttiğini, 16 yaşındayken başladığı koleksiyonunda 26 yılda biriktirdiği gümüş 34 yüzük, 45 künye ve bileklik, 23 kolye, 3 halhal, 3 hızma, 5 ayak parmağı yüzüğüne sahip olduğunu söyledi.

Türkiye'de seyahat etme şansı bulduğu birçok kentten gümüş takı aldığını dile getiren Zehra Kızılgün, gümüş takının, özellikle yüzüğün kendisinde bir tutku olduğunu, 113 parçadan oluşan gümüş takı koleksiyonunu haftada bir karbonatlı su ve limonla temizlediğini anlattı.

Kızılgün, "İlk günlerde yalnızca yüzük alıyordum. Zaman içinde koleksiyonum geliştikçe, işin ruhunu öğrendim. Şimdi birçok takımın çizimini ben yapıyorum. Kapalıçarşı'da bu işi yapan ustaların sayısı bir elin parmaklarını geçmiyor. Bu yüzden Erzurum, Trabzon gibi Anadolu kentlerinde son kalan ustaların elde yaptıkları ve geleneksel motiflerin yer aldığı takıları tercih ediyorum" dedi.

113 parçadan oluşan, toplam bir kilo 50 gram takı koleksiyonunun maddi değerini bilmediğini, bir yüzük için bin lira, bin 1500 lira ödediğini belirten Kızılgün, "Koleksiyonumun içinde 80 yıllık bir yüzük var, 15 bin lira önerdiler, kıyıp da satamadım. Satarsam eğer, sanırım güzel bir otomobil alabilirim" diye konuştu.