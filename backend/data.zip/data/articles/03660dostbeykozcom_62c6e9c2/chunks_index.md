# Chunks Index

| ID    | Section                      | Heading Path                 | Char Range | Preview                                                                                               |
| ----- | ---------------------------- | ---------------------------- | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | Güncelleme: 24.03.2015 21:04 | Güncelleme: 24.03.2015 21:04 | 53-1053    | == Güncelleme: 24.03.2015 21:04 == Baharın müjdecisi, bolluğun ve bereketin simgesi Nevruz, Beykoz... |
| c0001 | Güncelleme: 24.03.2015 21:04 | Güncelleme: 24.03.2015 21:04 | 853-1853   | öyleyen Okul Müdürü Kazım Sıtkı, Celal Aras Anadolu Lisesi olarak nevruz coşkusunu yaşamak...         |
| c0002 | Güncelleme: 24.03.2015 21:04 | Güncelleme: 24.03.2015 21:04 | 1653-2285  | el Çelikbilek de atladı.                                                                              |