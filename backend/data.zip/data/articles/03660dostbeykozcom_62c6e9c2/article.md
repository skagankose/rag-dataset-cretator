---
id: 03660dostbeykozcom_62c6e9c2
url: file://03660_dostbeykoz_com.md
title: 03660 dostbeykoz com
lang: en
created_at: '2025-12-20T00:31:25.551668'
checksum: 776f599c840be0781b19507be5a482ea580092a144f68e766a168852ac1a6da0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 293
  char_count: 2285
  num_chunks: 3
  num_sections: 1
---
= Beykoz Belediye Başkanı Nevruz ateşinden atladı =

== Güncelleme: 24.03.2015 21:04 ==

Baharın müjdecisi, bolluğun ve bereketin simgesi Nevruz, Beykoz Celal Aras Anadolu Lisesi'nin tertip ettiği "Nevruz Bayramı" programıyla coşkuyla kutlandı. Okul bahçesinde nevruz ateşinin yakıldığı, öğrencilerin şarkılar söylediği etkinlikte Başkan Yücel Çelikbilek ve Kaymakam Erdoğan temsili olarak demir dövdü.

"Türk Dünyası ve Toplulukları Haftası" kapsamında tertip edilen "Nevruz Bayramı" kutlamasına Beykoz Belediye Başkanı Yücel Çelikbilek, Beykoz Kaymakamı Süleyman Erdoğan, Beykoz Milli Eğitim Müdürü Kazım Bozbay, Beykoz Belediye Başkan Yardımcısı Muharrem Kaşıtoğlu, okul müdürü Kazım Sıtkı ve öğrenciler katıldı.

Türk Dünyası'nın Ortak Coşkusu Nevruz Bayramı'nın Türk Dünyası, İran, Orta Asya Ülkeleri ve Türkiye'de büyük bir coşkuyla kutlandığını söyleyen Okul Müdürü Kazım Sıtkı, Celal Aras Anadolu Lisesi olarak nevruz coşkusunu yaşamak istediklerini ve bu nedenle bu kutlamayı yaptıklarını belirtti.

Okul müdürü ayrıca Nevruzun yeni bir başlangıç olduğunu, gece gündüzün eşitlendiğini, sıcaklıkların arttığını, nüfusu 200 milyonu aşan Türk Dünyası'nda sevgi, kardeşlik ikliminde ortak kültür ve coşkuyu yansıttığını aktardı.

Etkinliğin okulun konferans salonunda yapılan bölümünde öğrenciler hazırladıkları şiirler ve türküleri okudular. Ergenekon'un simgesi olan demir dövme işi de tiyatral olarak öğrenciler tarafından canlandırıldı. Demiri dövme işini Belediye Başkanı Yücel Çelikbilek ve Kaymakamımız Süleyman Erdoğan birlikte temsili olarak yaptı.

Okulun bahçesinde yakılan nevruz ateşinin üzerinden öğrenciler, okul müdürü ve Başkan Yücel Çelikbilek de atladı. Büyük bir coşku ve bayram havasında kutlanan programda çeşitli ikramlar ve halk oyunları gösterisi de yer aldı.

Başkan Yücel Çelikbilek: "Barışa Uyanış Olsun" Nevruzun kardeşlik ve barışa yeniden başlangıç için bir fırsat olmasını dileyen Başkan Yücel Çelikbilek ise mesajında: "Dünya coğrafyasında zulüm ve haksızlıkların kol gezdiği günümüzde umarım Nevruz, ülkemiz ve tüm Dünya'da barışa uyanış olur" temennisinde bulundu.

Anahtar Kelimeler: Beyoz Haberleri, Nevruz, Kutlama, Beykoz Celal Aras Anadolu Lisesi, Yücel Çelikbilek, Süleyman Erdoğan, Türk Dünyası, İran, Orta Asya, Kazım Sıtkı, Kazım Bozbay