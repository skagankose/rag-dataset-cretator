# Chunks Index

| ID    | Section                                  | Heading Path                             | Char Range | Preview                                                                                             |
| ----- | ---------------------------------------- | ---------------------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Avon Kozmetik Müşteri Temsilcisi Tehdidi | Avon Kozmetik Müşteri Temsilcisi Tehdidi | 0-1000     | = Avon Kozmetik Müşteri Temsilcisi Tehdidi = 21.12.2015'de online hızlı sipariş verdim, temsilci... |
| c0001 | Avon Kozmetik Müşteri Temsilcisi Tehdidi | Avon Kozmetik Müşteri Temsilcisi Tehdidi | 800-1266   | vim K.                                                                                              |