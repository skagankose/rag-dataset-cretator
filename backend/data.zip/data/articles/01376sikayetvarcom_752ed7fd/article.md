---
id: 01376sikayetvarcom_752ed7fd
url: file://01376_sikayetvar_com.md
title: 01376 sikayetvar com
lang: en
created_at: '2025-12-19T23:41:08.541363'
checksum: ddb7fbe2f4acb5554af3495be67265f45f2505deabdec2a7b9a45cba502fe5c4
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 150
  char_count: 1266
  num_chunks: 2
  num_sections: 1
---
= Avon Kozmetik Müşteri Temsilcisi Tehdidi =

21.12.2015'de online hızlı sipariş verdim, temsilci önerilerinden **F******'ı** seçtim. 22.12.2015'de sipariş onayı için bir erkek tarafından arandım; aynı kişi bugün 14.00‑15.00 arasında arayarak yarın siparişin ulaşacağını söyledi. Siparişimin stoklarda bulunmadığını ve değiştirdiklerini ilettiler. Siparişi istemediğimi, bir daha sipariş vermeyeceğimi söyledim. “Vermezsiniz o zaman” gibi bir söylemi oldu, sinirlenip telefonu kapattım. Sonrasında **05382402003** numaralı kısa mesaj geldi; “ben oraya geleceğim, yüzüme söyleyin bakalım hakaretinizi” şeklinde tehdit mesajı gönderdi. “Ben oraya gelince anlatırsınız derdinizi” diye bir SMS daha attı. Şikayetimin firmaya acilen iletilmesini rica ediyorum.

4486533 numaralı şikayet hakkında, Sayın Sevim K. ile 28.12.2015 tarihinde görüşülmüş ve şikayet hakkında detaylı bilgi alınmıştır. Temsilcimizin bildirimine istinaden gerekli incelemeler yapılarak tüm bilgiler kendisine iletilmiştir.

Bilginize sunar, iyi çalışmalar dileriz.  
Saygılarımızla,  
Avon Müşteri İletişim Merkezi  
Avon Kozmetik Temsilcisi  

25 Aralık 2015  
Markalar: Palette, Loreal Paris, Biosante Detoks, LR Health & Beauty Systems, Flormar, Nivea, Oriflame, Diadermine, Bioderma, Sensodyne