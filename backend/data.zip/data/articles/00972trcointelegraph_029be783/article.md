---
id: 00972trcointelegraph_029be783
url: file://00972_tr_cointelegraph_com.md
title: 00972 tr cointelegraph com
lang: en
created_at: '2025-12-19T23:27:52.528037'
checksum: b9f0447e0a47ad996173f857c0dbd9ae39ab69393db6282b22f003178591b1aa
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 233
  char_count: 1841
  num_chunks: 3
  num_sections: 1
---
= İngiltere Merkez Bankası Negatif Faiz ve Bitcoin =

Bitcoin analistleri, İngiltere Merkez Bankası'nın aldığı kararın BTC fiyatına olumlu yansıyacağını düşünüyor. Piyasa Haberleri Bitcoin (BTC) için dolaylı "reklam yapan" isimlerin arasına İngiltere Merkez Bankası da katıldı. Küresel ekonomik kriz nedeniyle ulusal para birimlerini korumak isteyen İngiliz yetkililer, bilmeden Bitcoin'in ekmeğine yağ sürüyorlar.

Bloomberg tarafından 17 Eylül tarihinde bildirilen habere göre, İngiltere Merkez Bankası (BoE) negatif faiz oranlarını kabul eden bankalar kervanına katıldı. Negatif faiz oranı "BTC'nin benimsenmesini sağlar". Toplantı sonunda BoE, negatif faiz kararı aldı. Yani, ülkedeki yatırımcılar paralarını bankalarda muhafaza etmek isterlerse, faiz alamadıkları gibi bir de üstüne ödeme yapmak zorunda kalacaklar.

Bitcoin Fiyat Endeksi: 1 Bitcoin Kaç TL? (BTC TL). İngiltere hem Corona virüs salgınından, hem de Brexit'in etkisinden muzdarip. Bu sebeple yetkililerin negatif faiz uygulamasına geçmek istedikleri belirtiliyor. Politika yapıcılar, faiz oranlarını şu an için yüzde 0,1'de tutmak için oy verirken, İngiliz sterlini birçok para birimine karşı değer kaybetti.

İngiltere Merkez Bankası bilanço tablosu (GBP). Kaynak: TradingEconomics/ Bank of England.

Bitcoin destekçileri, böylesi bir hamlenin hem itibari para biriminin, hem de kurumun kendi saygınlığını baltaladığını düşünüyor. Tyler Winklevoss, bu hamlenin Bitcoin'in yararına olacağını düşünüyor: "Bitcoin için daha iyi bir reklam yapılamazdı. Onların parasından vazgeçip Bitcoin üzerinde uzun pozisyon alabilirsiniz." Deneyimli trader Tone Vays de benzer düşünceleri savundu: "Paranızı bankada saklamanız / biriktirmeniz için sizden ücret alacaklar. Bir Bitcoin Hodler daha ne isteyebilir! Teşekkürler Bank of England, BTC'nin benimsenmesine yardımcı olacaksınız."