# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                                                                              |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | 0-1000     | = İngiltere Merkez Bankası Negatif Faiz ve Bitcoin = Bitcoin analistleri, İngiltere Merkez...        |
| c0001 | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | 800-1800   | zorunda kalacaklar.                                                                                  |
| c0002 | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | İngiltere Merkez Bankası Negatif Faiz ve Bitcoin | 1600-1841  | imli trader Tone Vays de benzer düşünceleri savundu: "Paranızı bankada saklamanız / biriktirmeniz... |