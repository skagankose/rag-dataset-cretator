# Chunks Index

| ID    | Section                 | Heading Path                                 | Char Range | Preview                                                                                             |
| ----- | ----------------------- | -------------------------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Ripley yalnız dön!      | Ripley yalnız dön!                           | 0-285      | = Ripley yalnız dön!                                                                                |
| c0001 | AVCI UZAYLILARI GETİRME | Ripley yalnız dön! > AVCI UZAYLILARI GETİRME | 285-1285   | == AVCI UZAYLILARI GETİRME == Sivil roket üreticisi SpaceX'in, NASA için geliştirdiği personel...   |
| c0002 | AVCI UZAYLILARI GETİRME | Ripley yalnız dön! > AVCI UZAYLILARI GETİRME | 1085-1357  | k üreyerek insanlığı tehdit eder hâle geliyordu.                                                    |
| c0003 | EFSANENİN 40'INCI YILI  | Ripley yalnız dön! > EFSANENİN 40'INCI YILI  | 1359-1878  | == EFSANENİN 40'INCI YILI == Ridley Scott'ın yönettiği Oscar'lı bilim kurgu filmi *Alien*'ın ilk... |
| c0004 | AV OLABİLİRİZ           | Ripley yalnız dön! > AV OLABİLİRİZ           | 1878-2363  | == AV OLABİLİRİZ == Alman bilim insanları Prof.                                                     |