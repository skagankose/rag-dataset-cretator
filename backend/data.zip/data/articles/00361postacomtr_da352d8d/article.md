---
id: 00361postacomtr_da352d8d
url: file://00361_posta_com_tr.md
title: 00361 posta com tr
lang: en
created_at: '2025-12-19T23:07:39.533734'
checksum: f2d1afc431bdc70dd237ebe144bc8703c214b65891574d9df10aa6285f879a50
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 302
  char_count: 2363
  num_chunks: 5
  num_sections: 4
---
= Ripley yalnız dön! =

SpaceX'in Crew Dragon kapsülü dün Uluslararası Uzay İstasyonu'na başarıyla kenetlendi. Bilimkurgu severlerin ise kapsülün içindeki Ripley adlı mankene bir çağrısı var: **Ripley yalnız dön!**  
04 Mart 2019, Pazartesi 08:31  
Son Güncelleme: 04.03.2019 11:13  

== AVCI UZAYLILARI GETİRME ==

Sivil roket üreticisi SpaceX'in, NASA için geliştirdiği personel taşıyıcı Crew Dragon dün uluslararası uzay istasyonu'na (uui) kenetlendi. Devletlerin tekelinde olan uzay yolculuğunun ticari faaliyete dönüşmesinin ilk adımı olan Crew Dragon, ilginç bir tartışmayı da ateşledi. Ünlü bilimadamı Stephen Hawking'in Dünya dışı canlılarla iletişimin insanlığın sonunu getireceği görüşünü destekleyenler, gezegenler arası turizmin 'avcı uzaylılar'a yerimizi göstereceği ya da 'ölümcül bakterileri' Dünya'ya getireceği gibi teoriler ortaya attı. SpaceX'in 'çılgın' kurucusu Elon Musk ise Crew Dragon kapsülü içindeki mankene efsane bilimkurgu filmi *Alien*'ın (yaratık) başkahramanı Ripley'nin ismini vererek bu korkulara göndermede bulundu. Filmde, uzay mekiğine sızan yaratık üreyerek insanlığı tehdit eder hâle geliyordu. Crew Dragon ile uzay istasyonunun dünkü tarihi birleşmesi bilim dünyasında büyük ses getirirken, bilimkurgu severler de uzay turisti manken Ripley'ye sosyal medya üzerinden **'lütfen bu kez yalnız dön'** mesajları yağdırdı.

== EFSANENİN 40'INCI YILI ==

Ridley Scott'ın yönettiği Oscar'lı bilim kurgu filmi *Alien*'ın ilk gösteriminin üzerinden tam 40 yıl geçti. 1979'da beyaz perdede yer aldıktan sonra pek çok devam filmi, dizi, video oyunu ve çizgi romanla yaşamaya devam eden Alien efsanesinde, Sigourney Weaver'ın canlandırdığı Ripley karakteri istilacı uzaylılarla mücadele ettikten sonra geri dönerken yanında onlardan birini getiriyordu. SpaceX üretimi Falcon 9 roketiyle fırlatılan Crew Dragon, temmuzda insanlı uçuşlara başlayacak.

== AV OLABİLİRİZ ==

Alman bilim insanları Prof. Dr. Michael Schetsche ve Dr. Andreas Anton'un geçtiğimiz haftalarda yayınlanan *The Alien Society* (Uzaylı Topluluğu) adlı kitapta, evrene bilinçsizce sinyal gönderilmemesi gerektiği dile getiriliyor. Uzaylılarla kurulacak iletişimden insanoğlunun **'av olarak'** zararlı çıkacağı görüşüne yer veriliyor. *Alien* filmindeki 'yaratık' En İyi Görsel Efekt Oscar'ını kazanırken 'istilacı uzaylı' imgesi olarak tüm dünyanın zihnine kazındı.