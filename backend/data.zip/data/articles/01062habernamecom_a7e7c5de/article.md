---
id: 01062habernamecom_a7e7c5de
url: file://01062_habername_com.md
title: 01062 habername com
lang: en
created_at: '2025-12-19T23:30:52.535535'
checksum: 85aa36889984e0d32cd96115e0992d1c8cd709bb2e446e0a3f08213eb7044f2a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 306
  char_count: 2400
  num_chunks: 3
  num_sections: 1
---
= ABD'li profösörden Ermenilere şok =

**15.10.2011 12:26 - Haber Name**

Aralarında İsveçli ve Ermeni dinleyicinin de bulunduğu yaklaşık 200 kişiye seslenen McCarthy, iki saat süren sunumunda, Ermeni iddialarının temel kurgusundaki mantık hatalarını teker teker ortaya koyarak, çarpıtılan tarihi gerçekleri ve tahrif edilmiş istatistikleri dinleyenlerle paylaştı.  

ABD'li Profesör Justin McCarthy: “İsveç'te kabul edilen sözde soykırım tasarısı en kötüsü.”  

İsveç'e “Osmanlı devleti son dönemi ve 1915 olayları” konulu bir konferans vermek için gelen tarih profesörü Justin McCarthy, İsveç Parlamentosu'nda kabul edilen sözde soykırım tasarısının diğer ülke parlamentolarında kabul edilen tasarılar içinde en kötüsü olduğunu söyledi.  

McCarthy: “Çünkü İsveç'te kabul edilen tasarıda sadece Ermenilerin soykırıma uğradığı yazmıyor. Tasarı Süryanilerin, Asurîlerin, Pontus Rumlarının, Keldanilerin de soykırıma maruz kaldığını öne sürüyor, adeta Türklerin (Müslümanlar) diğer herkesi öldürdüğünü iddia ediyor.”  

Slaytlar eşliğinde 1915 olaylarını etraflıca anlatan McCarthy, “Osmanlı devleti, Ruslarla savaştığı bir dönemde isyan çıkartan ve Rusların ajanları gibi hareket eden Ermeni çetelerinden kurtulmak için ona destek veren Ermeni halkını zorunlu göçe tabii tutmak zorunda kaldı ve acı verici olaylar yaşandı” dedi.  

McCarthy: “1915 olayları için o dönem kimse masumdu diyemem. Evet, o yıllarda Türkler (Müslümanlar) Ermenileri öldürmüştü, bu doğru ama Ermeniler de birçok Türk'ü (Müslüman) öldürmüştü. Bu bir etnik temizleme değildi, savaş şartlarında yaşanmış bir şeydi. Hükümetlerin yanı sıra halklar da savaşmıştı ve bu savaşta yüz binlerce insan ölmüştü.”  

Osmanlı devletinin soykırım yaptığına dair hiç bir somut delil olmadığının da altını çizen McCarthy; “Kaldı ki arşivlerde Ermeni mültecilere saldırmayın şeklinde birçok yazışma vardır. Ayrıca aralarında bir şehrin valisinin de olduğu olaylardan sorumlu birçok insan yargılanarak idam edilmiştir. Soykırım amacı güden bir devlet bu kişileri neden assın?” diye sordu.  

Profesör McCarthy, konferansın ikinci bölümünde ise katılımcıların sorularını cevaplandırdı. Bir soru üzerine McCarthy, “Aralarında Türkiye'den yazarlarının olduğu bir grup yazar kitaplarına ‘Türkler soykırım yaptı’ diye başlıyor ve uzun uzun Türklerin neden soykırım yaptığını anlatıyor. Bu insanlara deliliniz ...” (devamı orijinal metinde kesilmiş).