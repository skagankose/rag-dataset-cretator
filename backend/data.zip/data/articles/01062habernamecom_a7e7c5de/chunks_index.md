# Chunks Index

| ID    | Section                           | Heading Path                      | Char Range | Preview                                                                                          |
| ----- | --------------------------------- | --------------------------------- | ---------- | ------------------------------------------------------------------------------------------------ |
| c0000 | ABD'li profösörden Ermenilere şok | ABD'li profösörden Ermenilere şok | 0-1000     | = ABD'li profösörden Ermenilere şok = **15.10.2011 12:26 - Haber Name** Aralarında İsveçli ve... |
| c0001 | ABD'li profösörden Ermenilere şok | ABD'li profösörden Ermenilere şok | 800-1800   | enilerin soykırıma uğradığı yazmıyor.                                                            |
| c0002 | ABD'li profösörden Ermenilere şok | ABD'li profösörden Ermenilere şok | 1600-2400  | yanı sıra halklar da savaşmıştı ve bu savaşta yüz binlerce insan ölmüştü.” Osmanlı devletinin... |