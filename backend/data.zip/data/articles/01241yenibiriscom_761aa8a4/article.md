---
id: 01241yenibiriscom_761aa8a4
url: file://01241_yenibiris_com.md
title: 01241 yenibiris com
lang: en
created_at: '2025-12-19T23:36:39.539413'
checksum: 4af53fd0c02691c4d3239f20e8a1993dac452804eced02b7619737f2952d954a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 156
  char_count: 1206
  num_chunks: 2
  num_sections: 1
---
= AFYTOS HOTELS - Ön Büro Şefi İş İlanı =

Balıkesir Ön Büro Şefi İş İlanları

Afytos Hotels grubumuzun bünyesinde bulunan otellerimiz için ÖN BÜRO bölümünde değerlendirmek üzere takım arkadaşı arayışımız bulunmaktadır. Takım motivasyonunu sağlamak ve takımına liderlik etmek. Misafirlerin karşılanmasını, yönlendirilmesini ve bilgilendirilmesini gerçekleştirmek. Misafir talep, şikayet ve önerilerini doğru analiz edip hızlı çözüm üretmek ve bu konuda inisiyatif almak. Telefon trafiğini etkin ve hızlı yönetmek, doğru yönlendirmeler yaparak iletişimi sağlamak. Rezervasyona dair iş takibini eksiksiz yerine getirmek, periyodik doluluk kontrolleri yaparak günlük, haftalık ve aylık istatiksel raporlar hazırlamak ve bunları ilgili birimlere iletmek. Kontrat girme, fiyat belirleme vb. konularda gerekli işlemleri ve takibi yapmak. Turizm ve seyahat acentalarıyla devamlı iletişimde olmak, hedef pazarları ve oradan gelecek hedef misafir profillerini tanımak ve onları bu doğrultuda ağırlamak. Konukların c/in ve c/out yapana kadar geçen süreçte misafir memnuniyetini ön planda tutarak, onların talep, istek ve ihtiyaçlarının hızlı bir şekilde karşılandığından emin olabilecek bir Ön Büro Şefi aramaktayız.