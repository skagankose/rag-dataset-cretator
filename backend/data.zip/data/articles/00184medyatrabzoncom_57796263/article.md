---
id: 00184medyatrabzoncom_57796263
url: file://00184_medyatrabzon_com.md
title: 00184 medyatrabzon com
lang: en
created_at: '2025-12-19T23:01:49.563071'
checksum: a54d35c55e8cc825fa28d3fd7424c86f7ac8888470eaf7c6a233bb2225fe4cde
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 34
  char_count: 256
  num_chunks: 1
  num_sections: 1
---
Sağlık çalışanları, basın açıklaması yaptı Karabük Eğitim ve Araştırma Hastanesi önünde toplanan sağlık çalışanları adına konuşan Türk Sağlık - Sen Şube Başkan Yardımcısı Ali Ünal, Türkiye'de sağlıkçılara uygulanan şiddetin günden güne arttığını öne sürdü.