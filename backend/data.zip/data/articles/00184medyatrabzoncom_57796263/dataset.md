# Dataset: 00184 medyatrabzon com

Generated on: 2025-12-19T23:01:58.958678
Total questions: 1

| # | Question                                                                                            | Answer                                            | Category | Related_Chunk_IDs |
| - | --------------------------------------------------------------------------------------------------- | ------------------------------------------------- | -------- | ----------------- |
| 1 | Karabük Eğitim ve Araştırma Hastanesi önünde toplanan sağlık çalışanları adına konuşan kişi kimdir? | Türk Sağlık - Sen Şube Başkan Yardımcısı Ali Ünal | FACTUAL  | c0000             |