# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                             |
| ----- | ------- | ------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-256      | Sağlık çalışanları, basın açıklaması yaptı Karabük Eğitim ve Araştırma Hastanesi önünde toplanan... |