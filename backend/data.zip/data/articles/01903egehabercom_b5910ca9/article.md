---
id: 01903egehabercom_b5910ca9
url: file://01903_egehaber_com.md
title: 01903 egehaber com
lang: en
created_at: '2025-12-19T23:58:43.543749'
checksum: 12afaaef8df6a6af3fe81d0bc9cb25ca4438f4c08270fb40a4d46e368dd70dfd
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 283
  char_count: 2220
  num_chunks: 3
  num_sections: 1
---
= Bilim Kurulu üyesi Prof. Dr. Serhat Ünal o tarihe işaret ederek uyardı! =

Bilim Kurulu üyesi Prof. Dr. Serhat Ünal, koronavirüse ilişkin önemli açıklamalarda bulunurken vatandaşları uyardı. Prof. Ünal, koronavirüsü atlatmış kişilerin bir daha hasta olmayacağı şeklinde çalışmaların olduğunu, ancak geçirmemiş gibi tedbirli olmaları gerektiğini belirtti. Öte yandan, Ekim‑Kasım aylarında havaların soğumasıyla birlikte vaka sayılarında ciddi artış olabileceğinin altını çizdi.

Hacettepe Üniversitesi Enfeksiyon Hastalıkları ve Klinik Mikrobiyoloji Ana Bilim Dalı Başkanı ve Koronavirüs Bilim Kurulu üyesi Prof. Dr. Serhat Ünal, Dünya Sağlık Örgütü’nün (DSÖ) koronavirüs semptomlarını göstermeyen hastalardan virüs bulaşmasının çok nadir olduğu yönündeki açıklamasına karşı başka bir üniversitenin çalışma yaptığını, bunun doğru olmadığını gösterdiğini söyledi.

Prof. Dr. Ünal, şu sözlerle açıklama yaptı:  
> “Bizim yapmamız gereken, karşımızdan gelen her kişi için ‘Bu hastalığı bulunduruyor’ diye düşünmek, ona göre tedbirleri almak. Karşımızdaki herkes bu hastalıkla enfekte kabul edilecek. Hiçbir aralık bırakmadan tedbirler düzenli yapılacak.”

**GEÇİRENLERDE GEÇİRMEMİŞ GİBİ TEDBİRLİ DAVRANMAK ZORUNDA**  

Prof. Dr. Ünal, antikor testleriyle 150 bin kişinin taranacağını ve bunun, asemptomatik geçirmiş olanlarla beraber kaç kişinin bu hastalığı geçirdiğini göstereceğini söyledi. Ayrıca PCR testi ile hasta olanların tarandığını hatırlatarak şunları ekledi:  

> “Bu bize ‘Salgın ne tarafa gidiyor, nasıl kontrol edeceğiz, ne tedbirler alacağız’ gibi kıymetli bilgiler verecek. Hastalığı geçirmiş kişilerde antikor da oluşmuş ise koruyuculuğun, yani bir daha hasta olmama ihtimalinin çok yüksek olduğunu düşünüyoruz. Bunun aksini gösteren bazı çalışmalar var; ama çoğunluğu koruyuculuğun olduğu şeklinde. Yani ‘Geçiren kişiler bir daha hasta olmaz, karşısındakine de bulaştırmaz’ şeklinde. Ancak bu, ‘Tedbiri tamamen elden bırakın, herkesin ortasında maskesiz dolaşın’ anlamına gelmiyor. Geçirenler de geçirmemişler gibi tedbirli davranmak zorundalar. Bu koruyuculuk ne kadar devam ediyor; henüz çok emin değiliz. Çünkü ilk hastalar 4‑4,5 ay oldu ve onlarda koruyuculuğun devam ettiğine dair çalışmalar var.”