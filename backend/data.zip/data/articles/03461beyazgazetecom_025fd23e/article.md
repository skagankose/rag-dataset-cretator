---
id: 03461beyazgazetecom_025fd23e
url: file://03461_beyazgazete_com.md
title: 03461 beyazgazete com
lang: en
created_at: '2025-12-20T00:28:06.552751'
checksum: 96dacdd05547242159d8f065040193f0d057287ec6ab29961535f98f4312a7a8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 281
  char_count: 2122
  num_chunks: 3
  num_sections: 1
---
= İş Kazası Cinayet Anı Depresyon İlacı Polis Ekipleri Nayet Zanlısı - Katil zanlısının adliyeye getirilmesi - İkilinin birlikte fotoğrafı (ESKİŞEHİR) - Depresyon ilacı kullandığını belirten zanlı cinayet anını hatırlamadığı söyledi - Cinayet zanlısı Tacettin Y. =

Eskişehir'de, dini nikahlı eşi olduğu iddia edilen kadını bıçaklayarak öldüren ve aynı bıçakla kendisini de yaralayan zanlı adliyeye sevk edildi. Olay, dün Şirintepe Mahallesi Seymen Sokak üzerinde bir ikamette meydana geldi.

Ülviye İnci (52) ile dini nikahlı eşi olduğu iddia edilen Taceddin Y. (42) arasında sabah saatlerinde tartışma çıktı. Yaşanan tartışmanın kısa sürede büyüyüp kavgaya dönmesiyle Tacettin Y., mutfaktan aldığı bıçakla Ülviye İnci'yi defalarca bıçakladı.

Darp edilip ardından bıçaklanan çaresiz kadın çığlıklar atarak "Beni kurtarın, öldürecek" diye bağırdı. Sesi duyan komşuları ise durumu polis ekiplerine bildirdi. Bu sırada kapıyı zorlayan komşular, kilitli olduğu için açamadı. Daha sonra olay yerine gelen ekipler de kapıyı açamayınca çilingir çağrıldı. Çilingir ile kapı açılarak, 112 Acil Sağlık ekipleri içeri girdi.

Ekipler, Ülviye İnci'nin aldığı bıçak darbeleri sonucunda olay yerinde hayatını kaybettiği belirledi.

"Bıçağı aldığımı ve bıçakladığım kısımları hatırlamıyorum" cinayetin ardından kendine zarar veren Taceddin Y. ise 112 ekipleri ve polisin nezaretinde önce hastaneye, daha sonra emniyete götürüldü.

Burada alınan ifadesinde depresyon ilacı kullandığını dile getiren ve cinayet sonrasında da çok sayıda hap kullandığını iddia eden Tacettin Y., "Bana karşı sürekli aşağılayıcı konuşup bunaltıyordu. Olayın gecesi de parka gitmiştik, orada da tartıştık. Daha önce iş kazası geçirdiğim için çalışmıyormuş gibi hissettiğimi söyledi. Bana sürekli iyileşemeyeceğimi söyleyerek laf ediyordu. Olay sabahı marketten su alıp geldi, uyanmıştı. Kahvaltı için mi uyandığını sorduğumda beni tersledi. Sonra ben sigara içmek için balkona çıktım. Bıçağı aldığımı ve bıçakladığım kısımları hatırlamıyorum" ifadelerini kullandı.

Zanlı Tacettin Y. emniyetteki işlemleri sonrası bugün öğle saatlerinde adliyeye sevk edildi.