---
id: 0186910marifetorg_1080cc18
url: file://01869_10marifet_org.md
title: 01869 10marifet org
lang: en
created_at: '2025-12-19T23:57:34.580983'
checksum: b8f3ce54f90a693715ec6da0826722697ab8da52a7191aec51c075196fcadafd
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 66
  char_count: 446
  num_chunks: 1
  num_sections: 1
---
= Kelebekli keçe ajanda kılıfı =

== Keçeden mini dikiş seti ==
*ardish - 16 Şubat 2016*

Biz baharı erken getirelim dedik ve farklı bir ajanda kılıfı yaptık. Klasik ajandalardan sıkılanlar için kılıfımıza kelebek ve baharın habercisi olan uğur böceği ekledik. Her sene yeni ajandanızla tekrar tekrar kullanabileceğiniz 15×21 cm boyutunda olan ajanda kılıfımız, kitap kılıfı olarak da kullanılabilir. Kelebek kadar özgür ruhlu olanlar için ideal.