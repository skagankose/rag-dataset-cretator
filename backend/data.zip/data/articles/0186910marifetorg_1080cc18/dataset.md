# Dataset: 01869 10marifet org

Generated on: 2025-12-19T23:57:43.959750
Total questions: 1

| # | Question                       | Answer   | Category | Related_Chunk_IDs |
| - | ------------------------------ | -------- | -------- | ----------------- |
| 1 | Ajanda kılıfının boyutu nedir? | 15×21 cm | FACTUAL  | c0000             |