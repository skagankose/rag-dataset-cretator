# Chunks Index

| ID    | Section                                      | Heading Path                                 | Char Range | Preview                                                        |
| ----- | -------------------------------------------- | -------------------------------------------- | ---------- | -------------------------------------------------------------- |
| c0000 | Ferrari Motor Dayanıklılığı Konusunda Emin.. | Ferrari Motor Dayanıklılığı Konusunda Emin.. | 0-1000     | = Ferrari Motor Dayanıklılığı Konusunda Emin..                 |
| c0001 | Ferrari Motor Dayanıklılığı Konusunda Emin.. | Ferrari Motor Dayanıklılığı Konusunda Emin.. | 800-1114   | Valensiya'da tekrar etmeyeceği konusunda eminiz" diye konuştu. |