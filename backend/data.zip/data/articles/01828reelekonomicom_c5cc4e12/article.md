---
id: 01828reelekonomicom_c5cc4e12
url: file://01828_reelekonomi_com.md
title: 01828 reelekonomi com
lang: en
created_at: '2025-12-19T23:56:13.541806'
checksum: c7ec9f8c5c9db48da09d38534fa129be9dc21713e4905207a07594394a81bfd8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 347
  char_count: 2658
  num_chunks: 4
  num_sections: 1
---
= Çinli Sanatçılar: "Türkiye'de Kriz Ve Tehlike Yok, Bunu Ülkemizde Anlatacağız" =

İzmir Ticaret Odası'nın kenti Çin'de tanıtmak amacıyla yürüttüğü çalışmalar kapsamında İzmir'e gelen Çinli sanatçılar, "Bize 'Türkiye'de kriz var, tehlike var, sakın gitmeyin' diyorlardı. Ama böyle değilmiş, gördüğümüz gibi gerçekten herkes çok rahat ve keyifle yaşıyor. Aldığımız tüm bu sinyalleri Çin'de anlatacağız" dedi.

İzmir'i tanıtmak için yürütülen faaliyetler kapsamında Çinli sanatçılar İZTO Protokol Toplantı Salonunda oda heyetiyle bir araya geldi. İZTO Protokol Toplantı Salonunda gerçekleştirilen görüşmede, sanatçılara ilk olarak İzmir'in tanıtım filmi izlettirildi.

Çin ile Türkiye arasındaki ilişkileri canlı tutmanın çok önemli olduğuna işaret eden İzmir Ticaret Odası Yönetim Kurulu Üyesi Oğuz Özkardeş, "İlişkiler kültür ve sanat seviyesinde olduğu için daha da önem kazanıyor. İzmir 8 bin 500 yıllık tarihe sahip ve tarihçilerin 'Güzel İzmir' olarak tanımladığı bir kenttir. Turizmde gerekli her şeyimiz var, gastronomimiz var. Farklı kültürleri barındırıyoruz ve bu bakımdan çok renkli bir şehre sahibiz. Her gelene hitap edecek bir kentimiz var. Ülkeler arasında bir sanata, kültüre dayanmayan ekonomik bağların ne kadar hızlı kopabildiğini görüyoruz. Dolayısıyla sizlerin ziyareti bizler için son derece kıymetli" dedi.

Çin'de Türkiye Turizm Yılı olduğunu ifade eden Özkardeş, "İlişkilerin gelişimine katkıda bulunması adına sosyal medyanın önemi de yadsınamaz. Çin'de İZTO olarak çeşitli platformlarda dijital medya programı yürütüyoruz ve birçok takipçimiz olması bizi heyecanlandırıyor. Odamızda Türkiye'nin hiçbir odasında olmayacak kadar güçlü bir turizm grubu kurduk ve Çin ile olan ilişkilere büyük önem veriyoruz. Asya Pasifik Bölgesinde fuarlara katılıyoruz. Firmalara da katılması için ciddi teşvik de bulunuyoruz ve her türlü ilişkilerimizin gelişeceğine inanıyoruz" diye konuştu.

"Türkiye'de tehlike olduğunu söylüyorlar ama böyle değilmiş" Çin Heyet Başkanı Gu Zhenqıng ise Türkiye'de bir kriz ve tehlike algısı oluşturulmaya çalışıldığına işaret ederek, Türkiye'de görülen sanatları, kültürleri Çin'e götürüp orada tanıtacağız. Bize 'Türkiye'de kriz var, tehlike var, sakın gitmeyin' diyorlardı. Ama böyle değilmiş, gördüğümüz gibi gerçekten herkes çok rahat ve keyifle yaşıyor. Aldığımız tüm bu sinyalleri Çin'de anlatacağız" dedi.

Çinli sanatçılar ayrıca İzmir'de bir kültür festivali düzenlenmesi ve İzmir Enternasyonal Fuarı'nda da ülkelerini tanıtma talebini iletti. Çinli sanatçılar ilk olarak İzmir kent merkezini ve Tarihi Kemeraltı Çarşısı'nı gezdi, ardından da Selçuk, Seferihisar, Efes'te şehir turu yapacağı belirtildi.