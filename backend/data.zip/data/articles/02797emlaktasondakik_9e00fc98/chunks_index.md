# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                          |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------------ |
| c0000 | Lead    | Lead         | 0-1000     | 2017-2018 yılında yenilenen öğretim programlarında da Bilişim Teknolojileri derslerinin ana...   |
| c0001 | Lead    | Lead         | 800-1496   | plarına göre düzenlenen kodlama ve robotik dersleri, erken çocuklukta kodlama diliyle tanışan... |