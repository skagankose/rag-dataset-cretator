---
id: 02797emlaktasondakik_9e00fc98
url: file://02797_emlaktasondakika_com.md
title: 02797 emlaktasondakika com
lang: en
created_at: '2025-12-20T00:17:02.538944'
checksum: fd7975cb3e3ce7199514fc59456f07a069fb3de99d8207e0ecf9929c8b473f9b
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 179
  char_count: 1496
  num_chunks: 2
  num_sections: 1
---
2017-2018 yılında yenilenen öğretim programlarında da Bilişim Teknolojileri derslerinin ana ekseninde yer alan kodlama ve robotik müfredat uygulamaları ders içeriklerine entegre bir şekilde Bilişim ve Teknolojileri Dersleri ve DYK Kurslarında, bu eğitimi alan öğrencilerimiz teknoloji kullanarak fikirlerini hayata geçirme becerisi kazanmaya çalışıyor. Programlama eğitiminin öğrencilere yansıtıcılık, yaratıcılık, kural öğrenme, kurallara uyma, problem çözme ve analitik düşünme, uzamsal düşünme becerileri gibi beceriler kazandırması amaçlanıyor. Edremit İlçe Milli Eğitim Müdürü Yusuf Koç, yakın gelecekte her türlü üretimin temelini yazılım oluşturacağından söz ederek Robotik ve Kodlama eğitiminin öğrenciler için önemine değindi. Koç, “Edremit’li öğrencilerimiz kodlama diliyle tanıştı. Yaş gruplarına göre düzenlenen kodlama ve robotik dersleri, erken çocuklukta kodlama diliyle tanışan çocuklara gelecekte yazılım üretme konusunda yaşıtlarının önüne geçme olanağı sunuyor. Yakın gelecekte her türlü üretimin temelini yazılımın oluşturacağı öngörülürken yazılım dili olan kodlamanın öğretimi de eğitimin en önemli unsurlarından biri olarak öne çıkıyor. Artık eğitimde ezberci yaklaşımlar terk ediliyor. Biz de İlçemizde öğrencilerimizin kendi fikirlerini, kendi düşüncelerini hayata geçirmeleri, artık kağıt üzerinde soru çözmek yerine iş birlikleriyle yöntemini kullanmaları, fikir üretmeleri ve kendi hayallerini gerçekleştirmeleri için bir ortam yaratmak istedik.” ifadelerini kullandı.