---
id: 02430sinemalarcom_31ad43d9
url: file://02430_sinemalar_com.md
title: 02430 sinemalar com
lang: en
created_at: '2025-12-20T00:10:55.516648'
checksum: 2cdeba555fe1a5698e9a71f9690702bb094823fe7c9ea16ee063b05be26d2984
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 242
  char_count: 1729
  num_chunks: 2
  num_sections: 1
---
= 38. İstanbul Film Festivali Ulusal Yarışma Jürisi Belli Oldu =

İstanbul Kültür Sanat Vakfı tarafından 5‑16 Nisan tarihlerinde düzenlenecek 38. İstanbul Film Festivali'nin jüri üyeleri açıklandı. Ulusal Yarışma jüri başkanlığını, ulusal ve uluslararası önemli festivallerden ödüllerle dönen yönetmen, yazar ve senarist **Ümit Ünal** üstlenecek.

Jüri üyeleri:
- Masumiyet filmiyle tanınan oyuncu **Derya Alabora**
- Sofra Sırları'nda izleme fırsatı bulduğumuz oyuncu **Alican Yücesoy**
- Rüzgarın Hatıraları ve Yol Kenarı gibi pek çok yapımda çalışmış görüntü yönetmeni **Andreas Sinanos**
- Yazar/senarist **Gaye Boralıoğlu**

Ulusal Yarışma'da **Altın Lale En İyi Film**, **En İyi Yönetmen**, **Jüri Özel Ödülü**, **En İyi Kadın Oyuncu**, **En İyi Erkek Oyuncu**, **En İyi Senaryo**, **En İyi Görüntü Yönetmeni**, **En İyi Kurgu** ve **En İyi Müzik** olmak üzere toplam 9 dalda ödül veriliyor.

Ödül tutarları:
- Altın Lale En İyi Film: **150.000 TL**
- Onat Kutlar anısına Jüri Özel Ödülü: **50.000 TL**
- En İyi Kadın ve En İyi Erkek Oyuncu: **10.000 TL** each
- Anadolu Efes, En İyi Yönetmen ödülüne layık görülen isme **50.000 TL** takdim edecek.

İKSV, İstanbul Film Festivali tarafından sinemanın emektar isimlerine verilen Sinema Ödülleri'ni 2019 yılında alacak isimleri de Aralık ayında açıklamıştı. 
- **Yaşam Boyu Başarı Ödülü**: yönetmen **Şerif Gören**
- **Sinema Onur Ödülleri**: oyuncu ve yapımcı **Göksel Arsoy**, oyuncu **Selda Alkor**
- **Sinema Emek Ödülü**: akademisyen **Jak Şalom**

Ödül töreni 4 Nisan Perşembe gecesi, 38. İstanbul Film Festivali Açılış Töreni'nde gerçekleşecek.

Bu yıl festival kapsamında **Stanley Kubrick** film seçkisinin izleyicilerle buluşacağı ise geçtiğimiz günlerde duyuruldu.