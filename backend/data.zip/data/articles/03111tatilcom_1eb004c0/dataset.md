# Dataset: 03111 tatil com

Generated on: 2025-12-20T00:22:22.529391
Total questions: 1

| # | Question                                          | Answer | Category | Related_Chunk_IDs |
| - | ------------------------------------------------- | ------ | -------- | ----------------- |
| 1 | Borgo Ramezzana Otel hangi bölgede bulunmaktadır? | Trino  | FACTUAL  | c0000             |