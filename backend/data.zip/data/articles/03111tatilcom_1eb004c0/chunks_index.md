# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                        |
| ----- | ------- | ------------ | ---------- | ---------------------------------------------------------------------------------------------- |
| c0000 | Adres   | Adres        | 92-977     | === Adres === Trino Borgo Ramezzana Otel, sizleri en iyi şekilde misafir edebilmek için tüm... |