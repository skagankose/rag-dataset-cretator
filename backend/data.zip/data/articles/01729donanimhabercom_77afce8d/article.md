---
id: 01729donanimhabercom_77afce8d
url: file://01729_donanimhaber_com.md
title: 01729 donanimhaber com
lang: en
created_at: '2025-12-19T23:52:54.529305'
checksum: b6f8bd0e535b2acbdef886568ab487eefb54e67db89e3f4c2f87270333f9d0e0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 161
  char_count: 1352
  num_chunks: 2
  num_sections: 1
---
= Volkswagen, Türkiye'den yaklaşık 324 bin aracı gönüllü geri çağıracak =

**Otomobil | DonanımHaber**  
17 Ekim 2015, 15:52 (Güncellendi, 7 yıl)

Geçtiğimiz ay ortaya çıkan Volkswagen'in emisyon skandalında gelişmeler devam ediyor. Kısa bir süre önce bu haberde şirketin Ocak ayından itibaren araçları geri çağırmaya başlayacağını sizlere iletmiştik. Bu kez ise Bilim, Sanayi ve Teknoloji Bakanı Fikri Işık ülkemizde etkilenen araçlar ve geri çağrılmaları hakkında konuştu.

Türkiye'de Volkswagen'in EA 189 dizel motoruna sahip 323 bin 977 araç olduğunu söyleyen Işık, tüm araçların Almanya ile birlikte Ocak ayından itibaren gönüllü olarak geri çağrılacağını belirtti. Geri çağrılan araçların teknik güncellemeleri yapılacağı belirtilirken bu güncellemelerin içeriği konusunda henüz net bir bilgi bulunmuyor.

Türkiye'de araç vergi sisteminin emisyona bağlı olmadığını hatırlatan Işık, "Bizim için önemli olan Türkiye'de emisyon değerlerinin çevre kirliliğine olan etkisi" şeklinde konuştu. Firmanın da araçları gönüllü geri çağırmayı kabul etmesinin ardından cezai yaptırım uygulanmayacağı belirtildi.

Audi araç sahipleri: www.audi.co.uk/owners-area/emissions/check-your-car.html adresinden, VW araç sahipleri ise: www.volkswagen.co.uk/owners/dieselinfo adresinden sorgulama yaparak emisyon skandalından etkilenip etkilenmediklerini öğrenebilirler.