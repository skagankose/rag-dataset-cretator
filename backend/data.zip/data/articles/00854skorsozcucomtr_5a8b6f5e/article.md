---
id: 00854skorsozcucomtr_5a8b6f5e
url: file://00854_skor_sozcu_com_tr.md
title: 00854 skor sozcu com tr
lang: en
created_at: '2025-12-19T23:23:56.535403'
checksum: d94cb0a901eb7702df5892aa696d34bf8ea6cce63a1413e8e5070794dbca1740
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 378
  char_count: 2993
  num_chunks: 4
  num_sections: 2
---
= Orman'dan taraftara çağrı – Spor Haberleri =

Beşiktaş Başkanı Fikret Orman, sponsorluk anlaşmasında takımla ilgili açıklamalarda bulundu. Güncellenme: 14:28, 16/04/2014

Beşiktaş Kulübü Başkanı Fikret Orman, Spor Toto Süper Lig'in bitimine 5 hafta kala hayata geçirilen elektronik bilet uygulaması nedeniyle taraftarlarından Passolig kartlarını en kısa zamanda almalarını istedi. Ortaköy'deki Feriye Lokantası'nda Kalde firması ile yapılan sponsorluk sözleşmesinde gazetecilerin sorularını yanıtlayan Orman, "Başkan olarak Passolig kartımı aldım, taraftarlarımız bu uygulamaya en kısa zamanda dahil olmalı" dedi.

Fenerbahçe ile çok önemli bir maç oynayacaklarını belirten Orman, "Elektronik bilet, kanunlar çerçevesinde yapılan bir uygulama. Şahsi fikrimi sorarsanız, ligin bitmesine bu kadar az zaman kala uygulanmaya başlaması yanlış. Daha sonra başlasa daha sempatik olabilirdi. Yorum yapmak bu saatten sonra kimseye bir şey kazandırmaz. Taraftarlarımızdan passolig kartlarını en kısa zamanda almalarını rica ediyorum. Fenerbahçe ile Şampiyonlar Ligi'ne doğrudan katılma yolunda çok önemli bir maç oynayacağız ve taraftarımıza çok ihtiyacımız var. 80 bin kişilik Olimpiyat Stadı'nı doldurmalıyız, herkesi duyarlı olmaya davet ediyorum" diye konuştu.

Fenerbahçe'nin derbide, Galatasaray'ın UEFA Şampiyonlar Ligi'ne lig ikincisi olarak doğrudan katılamaması için gerçek performansından uzak mücadele edeceği şeklindeki dedikodular için "komik" yorumunu yapan Orman, "105 senelik rekabette ilk ve son maçımız değil. Bu söylentiler anlamsız, herkes kendi işine baksın" ifadesini kullandı.

== FUTBOL GÖNÜLLE YÖNETİLMEZ ==

Teknik direktör Slaven Bilic'in Beşiktaş ile güzel bir uyum yakaladığını vurgulayan başkan Fikret Orman, sözlerine şöyle devam etti: "Bilic gerçekten Beşiktaş'a uydu, elbisesi Beşiktaş bedeniyle uyuştu. Bizler gibi hocamız da mütevazı, çok iyi bir insan fakat futbol gönülle yönetilmez. Beşiktaş'ın hedefleri var. Nihai amacımız Avrupa'da bir kupa almaktır, bu doğrultuda yürüyoruz. Osmanlılar gibi yapılanma, gelişme ve büyüme dönemlerimiz var. Bilic'in yapılanmamızda yeri hazır. Temennimiz, kendisiyle uzun bir anlaşma yapmaktır. Hocamızla daha sonra oturup konuşuruz."

Yeni sezona yönelik transferler konusunda hummalı bir çalışma yürüttüklerini, buna rağmen henüz hiçbir futbolcuyla anlaşma sağlamadıklarını da açıklayan Fikret Orman, Beşiktaş transfer komitesinin detaylı izlemeler yaptığını ve transfer görüşmelerinin önümüzdeki haftadan itibaren hızlanacağını ifade etti.

İnşaatı devam eden Vodafone Arena ile ilgili bilgiler de veren Beşiktaş Kulübü Başkanı Orman, sözlerini şöyle tamamladı: "İnşaatımız sorunsuz ilerliyor. Bitirme tarihimiz 30 Ağustos'tur. UEFA kuralları gereği, önümüzdeki sezon maçlarımızı nerede oynayacağımız ile ilgili iki stat adı vermek zorundayız. Bu yüzden Atatürk Olimpiyat Stadı'nın ismini de verdik. Kimsenin aklına kötü bir şey gelmesin. Vodafone Arena bizim değil, Beşiktaş'ın stadı. Taraftarlarımız loca alarak bize çok b"