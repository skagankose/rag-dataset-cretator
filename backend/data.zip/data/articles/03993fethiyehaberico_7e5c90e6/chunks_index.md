# Chunks Index

| ID    | Section                        | Heading Path                   | Char Range | Preview                                                                                            |
| ----- | ------------------------------ | ------------------------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Meclis Üyeleri Yemekte Buluştu | Meclis Üyeleri Yemekte Buluştu | 0-1000     | = Meclis Üyeleri Yemekte Buluştu = Fethiye Belediye Başkanı Alim Karaca, CHP’li, Ak Parti’li ve... |
| c0001 | Meclis Üyeleri Yemekte Buluştu | Meclis Üyeleri Yemekte Buluştu | 800-1162   | tiyoruz.                                                                                           |