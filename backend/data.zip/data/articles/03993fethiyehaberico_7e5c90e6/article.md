---
id: 03993fethiyehaberico_7e5c90e6
url: file://03993_fethiyehaberi_com.md
title: 03993 fethiyehaberi com
lang: en
created_at: '2025-12-20T00:36:58.596808'
checksum: 09bc9f43cdac72b1be6983376026b9f54a0cda4997cd92d0b2866ca0c1e166ac
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 147
  char_count: 1162
  num_chunks: 2
  num_sections: 1
---
= Meclis Üyeleri Yemekte Buluştu =

Fethiye Belediye Başkanı Alim Karaca, CHP’li, Ak Parti’li ve Milliyetçi Hareket Partili (MHP) meclis üyeleriyle bir araya gelerek 6 aylık çalışmalarla ilgili bilgi verdi. Birlik ve beraberlik içinde, ayrım gözetmeksizin çalışmaları tüm meclis üyelerinin birlikte yürüttüğünü söyledi.

Kayaköy İzela Restaurant’ta gerçekleştirilen yemekte Karaca, meclis üyeleriyle tek tek ilgilendi. 6 aylık süreçte yapılan hizmetlerin aktarılmasının yanı sıra, Ak Partili ve MHP meclis üyelerinin seçim döneminde mahallelerde verdikleri sözlerin yerine getirilmesi anlamında Karaca net mesajlar verdi;

> “Seçim zamanında Ak Parti’li veya MHP’li belediye meclis üyelerimiz kendi mahalleleriyle ilgili hizmet sözü vermiş olabilir. Biz hiç kimseyi ayırmadan tüm hizmetleri yapmak istiyoruz. Amacımız siyasi parti gözetmeksizin Fethiye’nin 41 mahallesine hizmetleri gerçekleştirmek. Bunun için 7/24 çalışıyoruz. Ak Parti ve MHP’nin mahallelerde yapmak istediği hizmetleri notlarımıza alacağız. Bizim düşüncemiz tamamen bu yöndedir. Buraya gelerek birlik ve beraberlik örneği gösteren değerli belediye meclis üyelerimize teşekkür ediyorum.” dedi.