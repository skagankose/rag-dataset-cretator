# Dataset: 00408 haberler com

Generated on: 2025-12-19T23:09:13.012454
Total questions: 1

| # | Question                                                                    | Answer         | Category | Related_Chunk_IDs |
| - | --------------------------------------------------------------------------- | -------------- | -------- | ----------------- |
| 1 | 2018 yılında kaç kişinin HIV virüsü taşıdığı raporda kaç olarak kaydedildi? | 8 bin 362 kişi | FACTUAL  | c0000             |