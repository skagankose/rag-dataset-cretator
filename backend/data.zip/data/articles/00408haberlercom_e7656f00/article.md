---
id: 00408haberlercom_e7656f00
url: file://00408_haberler_com.md
title: 00408 haberler com
lang: en
created_at: '2025-12-19T23:09:03.525329'
checksum: 903e9055ac4d5c239da96932aee03278b502816cdcdf56d86209c8ca1123ca60
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 97
  char_count: 742
  num_chunks: 1
  num_sections: 1
---
= Kuzey Kore'de AIDS vakaları: Pyongyang'a göre yok, uzmanlara göre yaygın =

Kuzey Koreli yetkililer, ülkelerini HIV virüsünün bulaşmadığı, AIDS vakalarının olmadığı ülke olarak tanıtsa da uzmanlar aksini söylüyor.

Geçen yıl aralık ayında, Dünya AIDS Günü dolayısıyla düzenlenen bir etkinlikte, hükümet yetkililerinin yanı sıra Dünya Sağlık Örgütü'nün o dönemdeki Kuzey Kore temsilcisi Thushara Fernando, dış dünyadan kopuk yaşayan ülkede AIDS hastalığının görülmediğini öne sürerek kutlama yapmıştı.

Kuzey Kore ve ABD'li uzmanların hazırladığı bir rapordaysa 2018 yılında 8 bin 362 kişinin HIV virüsü taşıdığı, Kuzey Koreli sağlık yetkililerinin artan AIDS riskini, kamuoyuna duyurmadan takip ettiği kaydedildi.

Euronegs.com'da Görüntüle