---
id: 01286bodyforumtrcom_ef1275ff
url: file://01286_bodyforumtr_com.md
title: 01286 bodyforumtr com
lang: en
created_at: '2025-12-19T23:38:08.537596'
checksum: 32ddbf3af09fb9e6f9cd9c421445d5bf52aceffeb22804556e8e466d442553cd
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 191
  char_count: 1355
  num_chunks: 2
  num_sections: 1
---
= Haftada kaç gün antreman yapmalıyım? =

BodyForumTR Vücut Geliştirme Forumu Haftada kaç gün antreman yapmalıyım? Konusu “Yeni Başlayanlar Bölümü” forumundadır ve komandoengın47 tarafından 19 Aralık 2014 başlatılmıştır.

Arkadaşlar araştırmalarım sonucunda vücut geliştirmeye yeni başlayanlar haftada 3 gün antreman yapması ve arada iki gün kasların dinlenip gelişmesi gerekiyormuş. Bazı yerlerde haftada 4‑5 günde antreman yapılabilirmiş diye öğrendim. Yaşım 23, kilom 49, boy 171 cm; bu bünyeye göre haftada kaç gün çalışmalıyım?

Haftada 3 gün çalış, geri kalan günlerde ne bulursan ye, kilo al.

**Courageousss**, 19 Aralık 2014: 4 gün ideal. Kompleks karbonhidratlarla temiz kilo almaya bak, kalori hesabı yap. Günlük ihtiyacının 500 fazlasını alman yeterli; haftada 0.4‑0.6 kilo arası almaya bak. 0.4‑0.6 nedir? Anlayamadım o miktarı. 400 gr‑600 gr arası al, yani ayda 1.6‑2.4 kilo arası.

Günlük 2800 kaloriden başlayacağım. İki hafta sonra kilo almaya başlarsam bu değerden devam edeceğim.

Tebrik ederim yeni başlayanlara göre iyi anladın. Kimisi kalorisini bize hesaplatıyor, özel yemek programı istiyor.

Ben bu forum ve diğer forumları da buraya kayıt olmadan önce araştırmıştım. Burada bir arkadaş 2800 kaloriden başlamam için demişti. Ben de kaloriyi hesapladım. Kalori sonucuna göre 1 kilo almam için 2800 civarı kalori gerektiğini gördüm.