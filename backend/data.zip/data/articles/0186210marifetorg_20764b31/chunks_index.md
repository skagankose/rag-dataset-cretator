# Chunks Index

| ID    | Section                   | Heading Path              | Char Range | Preview                                                                                             |
| ----- | ------------------------- | ------------------------- | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Kanaviçe pembe iğnedenlik | Kanaviçe pembe iğnedenlik | 0-364      | = Kanaviçe pembe iğnedenlik = Merhabalar, kanaviçe işlemeli, kenarları pembe fırfırlı iğnedenlik... |