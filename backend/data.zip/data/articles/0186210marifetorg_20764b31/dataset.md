# Dataset: 01862 10marifet org

Generated on: 2025-12-19T23:57:31.011194
Total questions: 1

| # | Question                                                 | Answer          | Category | Related_Chunk_IDs |
| - | -------------------------------------------------------- | --------------- | -------- | ----------------- |
| 1 | İğnedenlik modelinin kenarları hangi renkte fırfırlıdır? | Pembe fırfırlı. | FACTUAL  | c0000             |