---
id: 02060habergazetesico_a50b383f
url: file://02060_habergazetesi_com_tr.md
title: 02060 habergazetesi com tr
lang: en
created_at: '2025-12-20T00:03:56.518303'
checksum: 935315e6654c43f41810996af47b56f78631eae76f741c3789267c8545696a0a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 165
  char_count: 1283
  num_chunks: 2
  num_sections: 1
---
= SASKİ'nin 2017 yılı bütçesi belli oldu =

Samsun Büyükşehir Belediyesi SASKİ Genel Kurulu 2016 yılı 6. birleşiminin birinci oturumu Büyükşehir Belediyesi hizmet binasında yapıldı.

Büyükşehir Belediye Meclisi 1. Başkanvekili Turan Çakır başkanlığında yapılan SASKİ Genel Kurulu'nda gündem maddelerinden biri olan 2017 mali yılı gelir‑gider bütçesi görüşüldü.

Görüşülen bütçede SASKİ Genel Müdürlüğü'nün 2017 mali yılı gelir‑gider bütçesi 380 milyon TL olarak oy birliği ile onaylandı.

Oylama sonrası konuşan Büyükşehir Belediye Meclisi 1. Başkanvekili Turan Çakır, “Başta başkanımız Yusuf Ziya Yılmaz olmak üzere bütün SASKİ çalışanlarımıza teşekkür ediyoruz. SASKİ'nin yaptığı hizmetler görülmüyor ama hizmetler yoksa da toprağın üzerindeki almış olduğumuz hizmetlerden daha çok hissediliyor. Dolayısıyla biz bu olumsuzluğu hissetmiyorsak SASKİ çalışanlarının ve Samsun halkının başarısıdır. Çünkü Samsun halkından toplanan su paraları ile bu hizmetler hayata geçiriliyor. İş sadece para ile de olmuyor. Aldığınız bu parayı hizmete dönüştürmeniz gerekiyor. Ülkemiz gelişmiş ülkeler seviyesine doğru gidiyor. En doğal hakkımız hava ve sudur. Eksikliklerimiz olabilir. Bu eksikliklerde en kısa zamanda giderileceğini ümit ederek SASKİ çalışanlarına tekrar teşekkür ediyorum” dedi.