# Chunks Index

| ID    | Section                                | Heading Path                           | Char Range | Preview                                                                                            |
| ----- | -------------------------------------- | -------------------------------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | SASKİ'nin 2017 yılı bütçesi belli oldu | SASKİ'nin 2017 yılı bütçesi belli oldu | 0-1000     | = SASKİ'nin 2017 yılı bütçesi belli oldu = Samsun Büyükşehir Belediyesi SASKİ Genel Kurulu 2016... |
| c0001 | SASKİ'nin 2017 yılı bütçesi belli oldu | SASKİ'nin 2017 yılı bütçesi belli oldu | 800-1283   | layısıyla biz bu olumsuzluğu hissetmiyorsak SASKİ çalışanlarının ve Samsun halkının başarısıdır.   |