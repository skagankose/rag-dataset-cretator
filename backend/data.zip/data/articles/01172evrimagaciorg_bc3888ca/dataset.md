# Dataset: 01172 evrimagaci org

Generated on: 2025-12-19T23:34:32.009425
Total questions: 1

| # | Question                                              | Answer                                                | Category | Related_Chunk_IDs |
| - | ----------------------------------------------------- | ----------------------------------------------------- | -------- | ----------------- |
| 1 | Metinde mRNA aşılarıyla ilgili hangi soru yer alıyor? | mRNA aşıları DNA'yı değiştirebilir mi? Cevabı Öğrenin | FACTUAL  | c0000             |