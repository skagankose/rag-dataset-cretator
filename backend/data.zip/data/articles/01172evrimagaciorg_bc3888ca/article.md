---
id: 01172evrimagaciorg_bc3888ca
url: file://01172_evrimagaci_org.md
title: 01172 evrimagaci org
lang: en
created_at: '2025-12-19T23:34:20.540122'
checksum: a766a5d7491818084daf4923d39fed3117b0f916705ec95e89ce83b43045d645
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 40
  char_count: 276
  num_chunks: 1
  num_sections: 1
---
= Edanur Çukadar (niloticus67556) | Takipçiler - Evrim Ağacı =

Hatırlatıcı doz nedir? Tek dozdan fazla aşıya ne gerek var? Cevabı Öğrenin

COVID-19 aşıları kısırlığa neden olur mu? Doğurganlığı etkiler mi? Cevabı Öğrenin

mRNA aşıları DNA'yı değiştirebilir mi? Cevabı Öğrenin