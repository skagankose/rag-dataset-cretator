---
id: 03405technopatnet_3eee345b
url: file://03405_technopat_net.md
title: 03405 technopat net
lang: en
created_at: '2025-12-20T00:27:10.595818'
checksum: e1733a7618de1d078ed05f844f1c6c30c11f1c1fc10ab8ae04beaeaf15325894
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 314
  char_count: 2170
  num_chunks: 3
  num_sections: 1
---
= Casper Excalibur G900 düşük CPU ve GPU kullanımı =

Evet arkadaşlar, sorun bu. Ekteki görselde de görebileceğiniz üzere sistem kendini tam olarak kullanmıyor. Casper Excalibur G900 kullanıyorum. Güç planlarından **Gaming mode** açık ve cihaz sürekli şarja takılı. Menüde kendini daha çok kullanıyor, 400‑450 FPS veriyor fakat oyuna girince kullanım niye düşüyor?

**Model:** Casper Excalibur G900  
**Ekran kartı:** RTX 2060  
**İşlemci:** i7 10750H 2.60 GHz – 5.0 GHz  
**Ekran:** 144 Hz  
**RAM:** Samsung 16 GB 3200 MHz  

20201102_165833.jpg (365,7 KB) – Görüntüleme: 66  

Model= Casper Excalibur G900. Grafikler en yüksekde mi? FPS sabitlemesi var mı? Ayarlar ve çözünürlük ne?

İlk 2 resimde ayarlarım en düşükte, çözünürlük 1920×1080 144 Hz. En düşük ayarlarda **lobide** %53 GPU %24 CPU kullanımı ile 314 FPS alırken, oyunda %30 GPU %20 CPU kullanımı ile 130‑190 FPS arası değişken bir durum var.

Diğer 2 resimde ayarlarım en yüksek çözünürlük 1920×1080 144 Hz. **Lobide** GPU %67 CPU %18 olmak üzere 270 FPS; oyun içinde ise %36 GPU %30 CPU ile 100‑140 FPS alıyorum. Herhangi bir FPS sabitlemesi kullanmıyorum.

248,8 KB – Görüntüleme: 49  
268,1 KB – Görüntüleme: 34  
vyl.jpg (236,8 KB) – Görüntüleme: 34  
vyo.jpg (297,8 KB) – Görüntüleme: 49  

MSI Afterburner’da işlemci hızını da gösterin. Bir şekilde güç kısma varsa bunu görebilirsiniz. Ayrıca oyun modu işlemciye belli bir güç sınırı koyuyor; yüksek performansta da test edin. Menüde aldığınız FPS değeri oyun esnasında aldığınız değerden çok daha yüksek olabilir ve bu normal bir durumdur. Bu şekil değil, diğer dizüstü bilgisayarların bu oyunlarda aldığı performansla karşılaştırma yapmanız gerekiyor.

İşlemci ile ilgili sıcaklık seçenekleri var; hızına dair bir şey bulamadım. Yüksek performans ve sonradan CMD üzerinden eklediğim **Nihai Performans** modlarını denedim, değişen bir şey yok. Yalnızca gözüme çarpan GPU **Lim1** fotoğraflarda gördüğünüz üzere lobide (yüksek ayarlarda) **POWER** moduna giriyor. Ancak oyun içinde **No Load** yazıyor.

İnternet üzerinde benimle aynı özelliklere sahip bir Excalibur benchmark göremedim fakat benzer diğer laptoplarda 200 civarı FPS’ler görünüyor.