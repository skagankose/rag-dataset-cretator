# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                                                                             |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Casper Excalibur G900 düşük CPU ve GPU kullanımı | Casper Excalibur G900 düşük CPU ve GPU kullanımı | 0-1000     | = Casper Excalibur G900 düşük CPU ve GPU kullanımı = Evet arkadaşlar, sorun bu.                     |
| c0001 | Casper Excalibur G900 düşük CPU ve GPU kullanımı | Casper Excalibur G900 düşük CPU ve GPU kullanımı | 800-1800   | llanımı ile 314 FPS alırken, oyunda %30 GPU %20 CPU kullanımı ile 130‑190 FPS arası değişken bir... |
| c0002 | Casper Excalibur G900 düşük CPU ve GPU kullanımı | Casper Excalibur G900 düşük CPU ve GPU kullanımı | 1600-2170  | yarların bu oyunlarda aldığı performansla karşılaştırma yapmanız gerekiyor.                         |