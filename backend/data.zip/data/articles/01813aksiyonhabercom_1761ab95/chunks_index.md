# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                      |
| ----- | ------- | ------------ | ---------- | -------------------------------------------- |
| c0000 | Lead    | Lead         | 0-355      | Uluabat Gölü'ndeki kuşları tek tek saydılar. |