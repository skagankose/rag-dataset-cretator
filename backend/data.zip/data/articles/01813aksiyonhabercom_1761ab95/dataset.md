# Dataset: 01813 aksiyonhaber com

Generated on: 2025-12-19T23:55:52.591742
Total questions: 1

| # | Question                                                                                                          | Answer                           | Category | Related_Chunk_IDs |
| - | ----------------------------------------------------------------------------------------------------------------- | -------------------------------- | -------- | ----------------- |
| 1 | Bursa'da vatandaşlar tarafından yaralı olarak bulunan şahinler tedavilerinin tamamlanmasının ardından ne yapıldı? | Tabii yaşama alanlarına salındı. | FACTUAL  | c0000             |