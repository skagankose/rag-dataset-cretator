---
id: 01813aksiyonhabercom_1761ab95
url: file://01813_aksiyonhaber_com.md
title: 01813 aksiyonhaber com
lang: en
created_at: '2025-12-19T23:55:42.536772'
checksum: 6667aedbacbbdc3931d19cb7cc6aa9750994be3a07bffdea2cb7fb3141a30766
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 43
  char_count: 355
  num_chunks: 1
  num_sections: 1
---
Uluabat Gölü'ndeki kuşları tek tek saydılar.  

Doğa Koruma ve Milli Parklar 2. Bölge Bölge Müdürlüğü, Bursa'daki sulak alanlarda kış ortası su kuşu sayımına başladı.  

Tedavileri tamamlanan şahinler hürriyete uçtu.  

Bursa'da vatandaşlar tarafından yaralı olarak bulunan şahinler, tedavilerinin tamamlanmasının ardından tabii yaşama alanlarına salındı.