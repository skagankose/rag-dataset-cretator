---
id: 01316sikayetvarcom_208be71b
url: file://01316_sikayetvar_com.md
title: 01316 sikayetvar com
lang: en
created_at: '2025-12-19T23:39:08.543496'
checksum: 2bcb83135c61b1f04cb6b1d49d9e2706fd65337d241054ac1e43e990bf46a6a1
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 137
  char_count: 930
  num_chunks: 1
  num_sections: 1
---
= Casper Nirvana Ürün Şikayetleri =

Casper laptop aldık ekim 2020 de Eylül 2021'de laptop açılmıyor diye servise gönderdik servis bize 784 TL ücret talep etti bu ücreti neden istedi onu da bilmiyorum sadece IBAN gönderdiler parayı 2 gün içinde yatırın dediler garantili ürün...

09 ağustos 2021 tarihinde Casper resmi internet sitesinden (www.casper.com.tr) satın aldığım laptopu beğenmediğim için, satın aldığım tarihten 2 gün sonra, 11 Ağustos 2021 tarihinde, iade talebimi firmaya ilettim. Ürünü 14 Ağustos 2021 tarihinde firmanın yönlendirmesi ile orijinal ambalajında kargoy...

Casper Nirvana F800 7500 Silver Çok Yavaş Casper Nirvana f800.! Ürünü taksit yapan başka bir mağazadan aldım. Çok yüksek fiyat ödedim alırken. Ama fiyat performans olarak çok kötü. Bilgisayarın açılması en az 4 dakika sürüyor. Açıldıktan sonra kendine gelmesi de en az o kadar. Herhangi bir geri dönüş alamıyorum bu konuda. Verilen paralar az...