# Dataset: 01316 sikayetvar com

Generated on: 2025-12-19T23:39:17.555183
Total questions: 1

| # | Question                                           | Answer | Category | Related_Chunk_IDs |
| - | -------------------------------------------------- | ------ | -------- | ----------------- |
| 1 | Servis Casper laptop için kaç TL ücret talep etti? | 784 TL | FACTUAL  | c0000             |