---
id: 03031antalyahakkinda_41c06905
url: file://03031_antalyahakkinda_com.md
title: 03031 antalyahakkinda com
lang: en
created_at: '2025-12-20T00:20:56.550668'
checksum: 7e7b0daa309463794b736352ae2ffd19dfdc7b9520ae809fdcdb7380b929a616
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 267
  char_count: 1996
  num_chunks: 3
  num_sections: 1
---
= Şadi Böcek son yolculuğuna uğurlandı =

Şadi Böcek son yolculuğuna uğurlandı | Antalya Hakkında Dolar 8,8686 %0 Euro 10,3889 %0 Altın (Gr) 501,41 %0,49 Bitcoin 389444 %4.09215 Ethereum 27559 %9.81039

Anasayfa / Antalya Haberleri / Şadi Böcek son yolculuğuna uğurlandı Şadi Böcek son yolculuğuna uğurlandı 1130 kez okunmuştur. Güncelleme Tarihi: 30 Ağustos 2021 18:09 /ANTALYA, ANTALYA

Büyükşehir Belediye Başkanı Muhittin Böcek, koronavirüs tedavisi gördüğü sırada akciğerine enboli atması sonucu ölen ağabeyi Şadi Böcek'i (62) son yolculuğuna uğurladı. Büyükşehir Belediye Başkanı Muhittin Böcek'in ağabeyi Şadi Böcek, geçen haftalarda koronavirüse yakalandı. 2 haftadır Akdeniz Üniversitesi Hastanesi'nde koronavirüs tedavisi gören Şadi Böcek, durumu ağırlaşınca Covid Yoğun Bakım Ünitesi'ne alındı. Ağabey Böcek, akciğerlerine enboli atması sonucu dün hayatını kaybetti.

Evli ve 3 çocuk babası Şadi Böcek'in cenazesi bugün öğleden sonra Uncalı Mezarlığı'na getirildi. Böcek ailesi cenazeye gelen vatandaşların taziyelerini kabul etti. Başkan Muhittin Böcek'in oğlu Gökhan Böcek ise babasının yanından bir an olsun ayrılmadı. Cenazedeki yoğunluk nedeniyle sık sık sosyal mesafe uyarısı yapıldı.

Cenaze törenine AK Parti Milletvekilleri Mustafa Köse ve Kemal Çelik, CHP Milletvekilleri Cavit Arı, Çetin Osman Budak, Aydın Özer ve Rafet Zeybek, CHP İl Başkanı Nuri Cengiz, İYİ Parti İl Başkanı Mehmet Başaran, Konyaaltı Belediye Başkanı Semih Esen, Muratpaşa Belediye Başkanı Ümit Uysal, Manavgat Belediye Başkanı Şükrü Sözen, Finike Belediye Başkanı Mustafa Geyikçi, Kumluca Belediye Başkanı Mustafa Köleoğlu, Burdur Belediye Başkanı Ali Orkun Ercengiz, Yeşilova Belediye Başkanı Mümtaz Şenel, AESOB Başkanı Adlıhan Dere, esnaf odalarının başkanları, STK temsilcileri ve çok sayıda kişi katıldı. Covid 19 nedeniyle vefat eden Şadi Böcek'in tabutu musalla taşına konulmadan ikindi namazını müteakip cenaze namazı kılındı. Böcek'in cenazesi, aile mezarlığına gözyaşları eşliğinde defnedildi.