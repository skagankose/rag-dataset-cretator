# Chunks Index

| ID    | Section                              | Heading Path                         | Char Range | Preview                                                                                             |
| ----- | ------------------------------------ | ------------------------------------ | ---------- | --------------------------------------------------------------------------------------------------- |
| c0000 | Şadi Böcek son yolculuğuna uğurlandı | Şadi Böcek son yolculuğuna uğurlandı | 0-1000     | = Şadi Böcek son yolculuğuna uğurlandı = Şadi Böcek son yolculuğuna uğurlandı | Antalya Hakkında... |
| c0001 | Şadi Böcek son yolculuğuna uğurlandı | Şadi Böcek son yolculuğuna uğurlandı | 800-1800   | ındı.                                                                                               |
| c0002 | Şadi Böcek son yolculuğuna uğurlandı | Şadi Böcek son yolculuğuna uğurlandı | 1600-1996  | ustafa Köleoğlu, Burdur Belediye Başkanı Ali Orkun Ercengiz, Yeşilova Belediye Başkanı Mümtaz...    |