# Chunks Index

| ID    | Section                                            | Heading Path                                       | Char Range | Preview                                                                                       |
| ----- | -------------------------------------------------- | -------------------------------------------------- | ---------- | --------------------------------------------------------------------------------------------- |
| c0000 | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | 0-1000     | = Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti = Trabzonspor, Turkcell Süper Lig'in 15. |
| c0001 | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | 800-1800   | yönetimle önümüze bakmamız gerekiyor.                                                         |
| c0002 | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti | 1600-1805  | günlerde böyle ucuz goller yemeyiz” dedi.                                                     |