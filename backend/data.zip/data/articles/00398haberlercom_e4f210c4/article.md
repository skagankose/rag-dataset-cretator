---
id: 00398haberlercom_e4f210c4
url: file://00398_haberler_com.md
title: 00398 haberler com
lang: en
created_at: '2025-12-19T23:08:43.525452'
checksum: aa6d05099cbcb581c4cc3c6e8b82fd8189fc73061726096805ce678f7b10dab8
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 232
  char_count: 1805
  num_chunks: 3
  num_sections: 1
---
= Trabzonspor, Gaziantepspor'u Son Dakikalarda Geçti =

Trabzonspor, Turkcell Süper Lig'in 15. Haftasında kendi sahasında Gaziantepspor'u 3-2 mağlup etti. Trabzonspor Teknik Direktörü Ersun Yanal, karşılaşma sonrası yaptığı açıklamada galibiyeti hak ettiklerini söyledi.

Ligin belki de en erken golüyle maça başladıklarını ifade eden Ersun Yanal, “Kazanmak için çok arzuluyduk. Trabzonspor'un formatına uygun bir skoru de elde ettiğimizde ve farklı skora gideceğimiz dakikada eksik kaldık. Oyun bizim elimizdeydi. Ahmet'in atılmasından sonra yine pozisyonumuz vardı. Son dakikada attığımız gol, maçın bizim hakkımız olduğunun da kanıtıydı” dedi.

Trabzonspor'un zor bir süreç yaşadığının altını çizen Yanal, “Kongreden önce bunu her zaman yaşamış Trabzonspor. Bir haftamız kaldı. Sonra belirlenecek yönetimle önümüze bakmamız gerekiyor. Futbol adına sıcak bir gece yaşattıkları için her iki takımı da kutlamak gerekiyor. İstediğim her şey olmadı tabi ama hedefe gidebileceğimizin sinyallerini aldık” diye konuştu.

Yanal, Yattara'nın kendisini değiştirmemesinin ödülünü son dakikada verdiğini de söyledi.

Bir dönem Ersun Yanal'ın yardımcılığını yapan Gaziantepspor Teknik Direktörü Mesut Bakkal ise, “Enteresan ve izleyenlerin zevk aldığı bir maç oldu. Ben bitmesini hiç istemedim. Pozisyonlar, penaltılar, kartlar. Oyunun 15. saniyesinde yediğimiz gol moralimizi bozdu. Eğer bir takım 2-0'dan sonra bu mücadeleyi yapıyorsa kutlamak gerek. Beraberliği de sağladık, ama garanti oynamamız puan kaybetmemize neden oldu. Özellikle ikinci yarıdaki oyunumuzu devam ettirmemiz gerekiyor. İnşallah ileriki günlerde böyle ucuz goller yemeyiz” dedi.

Öte yandan, karşılaşmanın 75. dakikasında De Nigris'in darbesiyle sağ kaşında açılma olan ve hastaneye kaldırılan Tolga Seyhan'ın durumunun iyi olduğu belirtildi.