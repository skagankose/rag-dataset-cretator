# Chunks Index

| ID    | Section                                      | Heading Path                                 | Char Range | Preview                                                                   |
| ----- | -------------------------------------------- | -------------------------------------------- | ---------- | ------------------------------------------------------------------------- |
| c0000 | Savcının dava dosyalarının bilgileri çalındı | Savcının dava dosyalarının bilgileri çalındı | 0-775      | = Savcının dava dosyalarının bilgileri çalındı = İkitelli'de Bakırköy 12. |