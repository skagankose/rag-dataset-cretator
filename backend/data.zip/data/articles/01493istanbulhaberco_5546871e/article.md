---
id: 01493istanbulhaberco_5546871e
url: file://01493_istanbulhaber_com_tr.md
title: 01493 istanbulhaber com tr
lang: en
created_at: '2025-12-19T23:45:02.536751'
checksum: 0ee70976929f25cf59a67db6083206b552b24e26b2754c130489cbaecdbd73d0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 101
  char_count: 775
  num_chunks: 1
  num_sections: 1
---
= Savcının dava dosyalarının bilgileri çalındı =

İkitelli'de Bakırköy 12. Ağır Ceza Mahkemesinin duruşma savcısı Uğur Yaşar Güngör'ün, içinde dava dosyalarıyla ilgili bilgilerin bulunduğu çantası çalındı.

İkit Organize Sanayi Bölgesi'nde, Bakırköy 12. Ağır Ceza Mahkemesinin duruşma savcısı Uğur Yaşar Güngör'ün, 7 Şubat Cuma günü öğle saatlerinde arabasının camları kırılarak, araç içinde bulunan el çantası çalındı.

Savcı Güngör'ün çalınan çantasında ruhsatlı silahı, nü cüzdanı, mesleki kimliği, e-imza kartı ve 3 adet harici bellek olduğu, içinde müzik parçaları bulunan harici belleklerinden bir tanesinin geçtiğimiz günlerde bulunduğu öğrenildi.

Savcının baktığı dava dosyalarıyla ilgili bilgilerin olduğu diğer iki harici belleğin ise halen kayıp olduğu öğrenildi.