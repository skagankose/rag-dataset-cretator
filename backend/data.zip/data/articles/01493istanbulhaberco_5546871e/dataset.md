# Dataset: 01493 istanbulhaber com tr

Generated on: 2025-12-19T23:45:12.182617
Total questions: 1

| # | Question                                                    | Answer | Category | Related_Chunk_IDs |
| - | ----------------------------------------------------------- | ------ | -------- | ----------------- |
| 1 | Savcı Güngör'ün çantasından kaç adet harici bellek çalındı? | 3 adet | FACTUAL  | c0000             |