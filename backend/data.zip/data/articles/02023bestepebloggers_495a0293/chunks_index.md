# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                            |
| ----- | ------- | ------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-200      | İnsanlık olarak yıllar geçtikçe daha da tembelleşiyor, bir nevi hareketsiz olan yaşam tarzımızı... |