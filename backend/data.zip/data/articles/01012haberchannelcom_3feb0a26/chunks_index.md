# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                            |
| ----- | ------- | ------------ | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Lead    | Lead         | 0-623      | Beşiktaş, Süper Lig'in 20'nci haftasında Çaykur Rizespor ile yarın deplasmanda oynayacağı maçın... |