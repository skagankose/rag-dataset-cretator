---
id: 01012haberchannelcom_3feb0a26
url: file://01012_haberchannel_com.md
title: 01012 haberchannel com
lang: en
created_at: '2025-12-19T23:29:11.540356'
checksum: 96dc434c3d8fdf1785a9093736926cc4d76675422acdf8ebaa738851e24432ea
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 64
  char_count: 623
  num_chunks: 1
  num_sections: 1
---
Beşiktaş, Süper Lig'in 20'nci haftasında Çaykur Rizespor ile yarın deplasmanda oynayacağı maçın hazırlıklarını bu sabah yaptığı antrenmanla tamamladı.  
SPOR 31.01.2020, 13:44  

Siyah‑beyazlılarda, sözleşmesindeki madde nedeniyle yönetimin isteği doğrultusunda son 2 maçtır kadroya alınmayan Portekizli sol bek Rebocho, Rizespor maçı kadrosuna dahil edildi.  

#Futbol #istanbul #spor #siyah #ümraniye #haberler #takım #rizespor #haberchannel #Vida #fotoğrafları #sporhaberleri #beşiktaşhaberleri #haberchannelspor #habeleri #sergenyalçınhaberleri #beşiktaşantrenman #sergenyalçın #beyazlı #Rebocho #maçkadrosunda #rebocho