# Dataset: 01012 haberchannel com

Generated on: 2025-12-19T23:29:22.305496
Total questions: 1

| # | Question                                                                 | Answer                     | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------ | -------------------------- | -------- | ----------------- |
| 1 | Beşiktaş'ın Çaykur Rizespor maçının kadrosuna hangi oyuncu dahil edildi? | Portekizli sol bek Rebocho | FACTUAL  | c0000             |