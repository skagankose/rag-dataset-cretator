# Chunks Index

| ID    | Section                                    | Heading Path                               | Char Range | Preview                                                                                                |
| ----- | ------------------------------------------ | ------------------------------------------ | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Belediye Araç Filosuna Bir Yenisini Ekledi | Belediye Araç Filosuna Bir Yenisini Ekledi | 0-1000     | = Belediye Araç Filosuna Bir Yenisini Ekledi = *Malatya Haber Portalı – malatya haberleri* Kuluncak... |
| c0001 | Belediye Araç Filosuna Bir Yenisini Ekledi | Belediye Araç Filosuna Bir Yenisini Ekledi | 800-1218   | ğu içerisindeyiz.                                                                                      |