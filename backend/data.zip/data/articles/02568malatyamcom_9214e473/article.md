---
id: 02568malatyamcom_9214e473
url: file://02568_malatyam_com.md
title: 02568 malatyam com
lang: en
created_at: '2025-12-20T00:13:13.504998'
checksum: 105bbb24e2feba97cd1c621b67fb5530e57e313e0bb8f0fc5c1d9fef3639b0d5
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 154
  char_count: 1218
  num_chunks: 2
  num_sections: 1
---
= Belediye Araç Filosuna Bir Yenisini Ekledi =

*Malatya Haber Portalı – malatya haberleri*

Kuluncak Belediyesi araç filosuna, yeni bir Otokar Atlas (uzun şase Kamyon) ekleyerek araç filosunu güçlendirmeye devam ediyor.  
12 Nisan 2016 22:19  

Kuluncak Belediyesi, daha iyi hizmet vermek amacıyla, yeni bir Otokar Atlas (uzun şase Kamyon) ekleyerek araç filosunu güçlendirmeye devam ediyor. İlk deneme sürüşünü yapan Belediye Başkanımız Mehmet BOYRAZ şöyle dedi:

> "Halkımıza daha iyi hizmet verebilmek, vatandaşların taleplerini daha hızlı bir şekilde yerinde değerlendirip sonuçlandırmak için araç filomuzu yeniliyoruz. Belediyeye aldığımız kamyonet ile cenaze hizmetleri olan masa, sandalye, çadır ve yük taşımada kullanacağımız kapalı kasa kamyonet aracımızı belediyemize kazandırmanın mutluluğu içerisindeyiz. Yeni aracımızın ilçemize hayırlı olmasını dilerim."

*Etiketler*: malatya, haber, güncel, kuluncak, belediyesi, araç filosu, otokar, atlas, kamyon, haberler, etap, saglıklı, kilo, borç, keloğlan, koru, derneği, ulaşım, açtı, yemek, bebep, yeni yol, tepehen, medya bağımlılığı, çorba, çeşmesi, mültecilere yardım, bilinen, haşere mücadele, deyimler, TÜBA, doğanşehir, erkenek, Malatya Organize Sanayi.