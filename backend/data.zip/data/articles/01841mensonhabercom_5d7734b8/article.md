---
id: 01841mensonhabercom_5d7734b8
url: file://01841_m_ensonhaber_com.md
title: 01841 m ensonhaber com
lang: en
created_at: '2025-12-19T23:56:38.542766'
checksum: 763a6eaa71dd412554f2440d15651f6385e69140b4e127e84e179ed58becf6f2
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 360
  char_count: 2838
  num_chunks: 4
  num_sections: 3
---
AK Parti Genel Başkan Yardımcısı Mahir Ünal, partisince hazırlanan 'Sosyal Medya Etik Kuralları'na tüm partililierin hassasiyet göstermelerini istedi. Abone Ol - AA 02.05.2020 00:30 AK Parti Genel Başkan Yardımcısı Mahir Üna, söz konusu 12 etik kuralı Twitter'dan bir açıklamayla paylaştı. Açıklamasında sosyal medyanın hayata getirdiği kolaylıkların, bilgiye ulaşımda sağladığı hız ve avantajların önemli olduğunu, bu mecranın daha kuralsız ve genel toplumsal kabullerin dışında bir hareket alanı olarak görülmesinin de önemli bir etik sorun haline geldiğini belirten Ünal, "AK Parti olarak hazırladığımız 'Sosyal Medya Etik Kuralları'nı kamuoyu ile paylaşıyoruz. Bu kuralların her birine her bir teşkilat mensubumuz sonuna kadar riayet edecektir. Diğer siyasi partilerden de aynı hassasiyeti beklemekteyiz." ifadelerini kullandı.

== ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ ==

AK Parti tarafından hazırlanan "Sosyal Medya Etik Kuralları"na ilişkin açıklamada, sosyal medyanın hayata getirdiği kolaylıkların, bilgiye ulaşımda sağladığı hız ve avantajların herkesin malumu olduğu, ancak diğer platformlara göre bu mecranın daha kuralsız ve genel toplumsal kabullerin dışında bir hareket alanı olarak görülmesinin çeşitli ahlaki ve etik sorunları beraberinde getirdiği belirtildi. Diğer kitle iletişim araçlarının aksine anlık ve güncel bilgiyi kullanıcılarına sunan ve etkileşim düzeyi yüksek olan bu mecrada etik kuralların belirlenmesinin artık kaçınılmaz hale geldiği ifade edilen açıklamada, şunlar kaydedildi: "Bu kuralların eksikliğinden kaynaklanan problemler, her geçen gün kişi ve topluluklara yönelik zararların daha da büyümesine yol açmış, kötü niyetli kişi ya da grupların bu eksiklikten faydalanarak sosyal ağları nefret dilinin egemen olduğu, kişisel ve kurumsal hakların hiçe sayıldığı birer yalan ve iftira aracına dönüştürmelerine neden olmuştur. Bu durum etik kurallar dışında hukuki sorumlulukları da içermektedir."

Sosyal ağların doğru kullanıldığında vatandaşların birçok sorununa çözüm bulabilmesine imkan sağlayan, kişilerin direkt muhatapları ile temasa geçebilmesine fırsat veren platformlar bütünü olduğuna işaret edilen açıklamada, bu platformların etik kurallar çerçevesinde kullanıldığı takdirde en az zararla, topluma en çok faydayı sağlayabilecek ortamlardan biri haline gelebileceği belirtildi. Açıklamada, "Unutulmamalıdır ki özgürlüğümüzün sınırı, bir diğerinin özgürlüğünün başladığı yerdir. Zarar verici sonuçlar üretecek eylemlerin serbest bırakılması özgürlük değil, bizatihi özgürlüğün

== AK PARTİ'NİN SOSYAL MEDYA İÇİN 12 ETİK KURALI ==

Açıklamada, sosyal ağlarda zarara yol açan sorunlar göz ön

- Saygılı, hakaret ve nefret söylemi barındırmayan bir dil ve üslup kullanılması
- Diğer kullanıcıların özgürlük alanlarını kısıtlayacak, saldırgan tutumlar içeren paylaşımlardan kaçınılması