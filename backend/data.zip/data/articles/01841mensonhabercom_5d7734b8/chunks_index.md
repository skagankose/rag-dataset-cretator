# Chunks Index

| ID    | Section                                       | Heading Path                                  | Char Range | Preview                                                                                               |
| ----- | --------------------------------------------- | --------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | Lead                                          | Lead                                          | 0-833      | AK Parti Genel Başkan Yardımcısı Mahir Ünal, partisince hazırlanan 'Sosyal Medya Etik Kuralları'na... |
| c0001 | ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ | ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ | 833-1833   | == ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ == AK Parti tarafından hazırlanan "Sosyal Medya...   |
| c0002 | ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ | ETİK KURALLARIN BELİRLENMESİ ARTIK KAÇINILMAZ | 1633-2533  | da büyümesine yol açmış, kötü niyetli kişi ya da grupların bu eksiklikten faydalanarak sosyal...      |
| c0003 | AK PARTİ'NİN SOSYAL MEDYA İÇİN 12 ETİK KURALI | AK PARTİ'NİN SOSYAL MEDYA İÇİN 12 ETİK KURALI | 2535-2838  | == AK PARTİ'NİN SOSYAL MEDYA İÇİN 12 ETİK KURALI == Açıklamada, sosyal ağlarda zarara yol açan...     |