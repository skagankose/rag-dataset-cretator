---
id: 02069akyazinet_ccedcfcf
url: file://02069_akyazi_net.md
title: 02069 akyazi net
lang: en
created_at: '2025-12-20T00:04:14.557461'
checksum: 2369eb2dc46535a0f26e577d955827ed80ef5e639f0a0b37ffb46cc31a1c68c4
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 301
  char_count: 2433
  num_chunks: 4
  num_sections: 2
---
= Emniyetten Yerel Seçim Önlemleri =

İl Emniyet Müdürü Osman Babadağı'nın başkanlığında düzenlenen toplantıda yerel seçim sürecinde Emniyet'in yapacağı çalışmalar ele alındı. Kısa bir süre önce İl Emniyet Müdürlüğü görevine getirilen Osman Babadağı, Emniyette görevli müdürler ve amirlerle bir araya geldi. Sakarya gibi stratejik ve ekonomik yönden önemli bir ilde görev yapmaktan heyecan ve gurur duyduğunu belirten Babadağı, "Her vatandaşımız bizim için çok önemli ve değerlidir. Bize güvenen, bizden desteğini hiçbir zaman esirgemeyen halkımızın, bu güvenini zedelemeden onlara en iyi, en kaliteli hizmeti sunacağız. Sevgi, adalet, eşitlik, sabır ve nezaket ile vatandaşımızın memnuniyetini esas alıp, Polis‑halk ilişkilerini artırarak devam ettireceğiz" ifadelerini kullandı. Tedbirler en üst seviyeye çıkartılacak. İl Emniyet Müdürü Osman Babadağı, yerel seçim süreciyle ilgili olarak, "30 Mart 2014 Pazar günü yapılacak olan Mahalli İdareler Seçiminin huzurlu, güvenli bir ortamda gerçekleştirilmesi ve seçmen iradesinin sağlıklı bir şekilde sandığa yansımasının sağlanması adına güvenlik güçlerimizce alınması gereken tedbirler en üst seviyeye çıkartılarak güven ortamının devamlılığı sağlanacaktır" diye konuştu.

== Yerel Seçim Sürecinde Polisin Alacağı Önlemler ==

- Mahalli idareler seçiminin huzurlu ve güvenli bir ortamda yapılmasını sağlamak amacıyla ilimiz genelinde polis sorumluluk alanında alınacak güvenlik tedbirlerinin koordinasyonu ve seçim süreci içerisinde meydana gelebilecek olaylarla ilgili bilgilerin sağlıklı bir şekilde toplanması ve değerlendirilmesi için İl Emniyet Müdürlüğü bünyesinde Seçim Harekat Merkezi oluşturulmuştur.  
- Seçim dönemi süresince karşılaşılacak problemlerin çözümü ve tereddütlerin giderilmesi amacıyla ilgili seçim mevzuatı çerçevesinde yapılacak görevler hakkında İl Emniyet Müdürlüğü personeli için bilgilendirme toplantısı yapılmıştır.  
- 01 Ocak 2014 tarihinden itibaren İl Seçim Kurulunda 24 saat esasına göre gerekli güvenlik tedbirleri yeteri kadar personelle alınmıştır.  
- Muhtarlıklar etrafında gerekli güvenlik tedbirleri alınmıştır. Alınan güvenlik tedbirleri, muhtarlık bölgesi askı listelerinin askıda kalacağı süre boyunca devam ettirilecektir.  
- Siyasi Parti binaları ve Seçmen irtibat Büroları etrafında gerekli güvenlik tedbirleri alınmıştır.  
- Seçim dönemi süresince, genel güvenlik kapsamında yürütülen devriye hizmetlerinin periyodu arttırılmıştır.