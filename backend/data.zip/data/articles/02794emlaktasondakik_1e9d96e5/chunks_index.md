# Chunks Index

| ID    | Section         | Heading Path    | Char Range | Preview                                                                                                |
| ----- | --------------- | --------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Konut Projeleri | Konut Projeleri | 0-1000     | = Konut Projeleri = Uğurcan Tokay 02.10.2017 10:30 Dekon İnşaat'ın her zevke hitap eden Dekon Luna,... |
| c0001 | Konut Projeleri | Konut Projeleri | 800-1800   | dığı Dekon Suadiye Ametist'in yanı sıra, 2019 yılında teslim edilecek Dekon Senkron ve Dekon Luna...   |
| c0002 | Konut Projeleri | Konut Projeleri | 1600-2600  | ının tamamlanarak oturumun başladığı Dekon Suadiye Ametist'te 2+1, 3+1, 3+1 dubleks, 4+2 çatı teras... |
| c0003 | Konut Projeleri | Konut Projeleri | 2400-3010  | kurmaları gerekiyor.                                                                                   |