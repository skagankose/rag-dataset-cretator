---
id: 02794emlaktasondakik_1e9d96e5
url: file://02794_emlaktasondakika_com.md
title: 02794 emlaktasondakika com
lang: en
created_at: '2025-12-20T00:16:59.590123'
checksum: 52f1dafa1a924e15c5c0c72952e6b36d42ac62a9e3cfdd2240d98bfdd0d5ee65
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 416
  char_count: 3010
  num_chunks: 4
  num_sections: 1
---
= Konut Projeleri =

Uğurcan Tokay 02.10.2017 10:30  

Dekon İnşaat'ın her zevke hitap eden Dekon Luna, Dekon Suadiye Ametist ve Dekon Senkron'de av almak isteyenlere cazip fırsatlar sunuluyor. Dekon İnşaat, Dekon Suadiye Ametist, Dekon Senkron ve Dekon Luna projeleriyle farklı zevk, ihtiyaç ve bütçelere hitap ediyor. Dekon Suadiye Ametist, Bağdat Caddesi'nin keyfini lüks bir sitede, manzaralı dairelerde sürmek isteyenlere hitap ederken, Dekon Senkron, genç profesyonellere rezidans keyfini sunuyor. Dekon Luna ise, lansman öncesi fiyatlarıyla hem yatırım yapmak isteyenlere, hem de daha uygun fiyatlarla konforlu dairelerde oturmak isteyenlere hitap ediyor. Dekon İnşaat, üç farklı projesiyle, farklı ihtiyaç ve bütçelere hitap ediyor. Dekon İnşaat tarafından yapımı tamamlanan ve oturumun başladığı Dekon Suadiye Ametist'in yanı sıra, 2019 yılında teslim edilecek Dekon Senkron ve Dekon Luna da gerek yatırım, gerekse oturmak için konut arayanları bekliyor.

Dekon Suadiye Ametist Bağdat Caddesi'nin nadir site projelerinden Bağdat Caddesi'nin nadir site konseptli projelerinden olan Dekon Suadiye Ametist'in en büyük özelliği olan eşsiz deniz manzarasının yanı sıra, jakuzili açık yüzme havuzu, spor salonu, kafesi, zen bahçesi, çocuk oyun odası ve parkı, çok amaçlı spor alanları, iki katlı kapalı otoparkı, 24 saat güvenliği, sanat galerisi ve toplantı salonu daire sahiplerine ayrıcalıklı bir yaşam sunuyor. Bağdat Caddesi'ne 350 metre mesafede bulunan Dekon Suadiye Ametist, metro durağı, Marmaray istasyonu ve İDO İskelesi gibi toplu ulaşım noktalarına yürüme mesafesinde bulunuyor. Yapımının tamamlanarak oturumun başladığı Dekon Suadiye Ametist'te 2+1, 3+1, 3+1 dubleks, 4+2 çatı teras ve dubleks daireleriyle farklı ihtiyaçlara yanıt veren 152 daire bulunuyor. Tapuların hemen teslim edildiği projede banka kredili ödeme avantajı da sunuluyor.

Dekon Senkron'da 1+1'ler tükeniyor İstanbul Finans Merkezi'nin yanında, değerli konumu ve farklı daire seçenekleriyle her türlü ihtiyaca cevap veren Dekon Senkron'da tamamı balkonlu 63 metrekare ile 109 metrekare arasında değişen, 1+1 ve 2+1 168 dairenin yanı sıra, 10 adet de ticari ünite bulunuyor. Yaklaşık 5 bin metrekarelik bir alan üzerine kurulan 17 katlı projede, 1+1 daireler yoğun talep görüyor. Dekon Senkron'un son 5 1+1 dairesinden birine sahip olmak isteyenlerin avantajlı ödeme fiyatları için Dekon Senkron ofisi ile irtibat kurmaları gerekiyor. 168 araçlık kapalı otopark alanı, açık havuz, spor salonu, çocuk oyun alanları gibi sosyal alanların yanı sıra, sosyal donatı alanlarıyla da dikkat çeken Dekon Senkron'un altında iki açık kat şeklinde bulunan alanda, kafelerden restoranlara, marketlerden farklı ihtiyaçlara yönelik alışveriş ve hizmet alanlarına kadar pek çok mağaza bulunuyor.

İstanbul Finans Merkezi'nin yanında, tek bina olarak yükselecek olan yeni proje Dekon Luna, zemin + 14 kat ve 90 daireden oluşuyor. Açık havuz, kapalı otopark ve bir rezidansın gerektirdiği tüm konforu sunan projede, balkonlu daire opsiyonu da