# Dataset: 01617 sondakika com

Generated on: 2025-12-19T23:49:20.202312
Total questions: 1

| # | Question                                         | Answer                                | Category | Related_Chunk_IDs |
| - | ------------------------------------------------ | ------------------------------------- | -------- | ----------------- |
| 1 | Çorum Valiliği vatandaşları ne konusunda uyardı? | Azalan hava sıcaklıkları ve yağışlar. | FACTUAL  | c0000             |