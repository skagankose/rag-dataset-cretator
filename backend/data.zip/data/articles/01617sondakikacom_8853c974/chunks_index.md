# Chunks Index

| ID    | Section                                            | Heading Path                                       | Char Range | Preview                                                                                            |
| ----- | -------------------------------------------------- | -------------------------------------------------- | ---------- | -------------------------------------------------------------------------------------------------- |
| c0000 | Çorum Valiliğinden meteorolojik uyarı - Son Dakika | Çorum Valiliğinden meteorolojik uyarı - Son Dakika | 0-554      | = Çorum Valiliğinden meteorolojik uyarı - Son Dakika = Çorum Valiliği, vatandaşları azalan hava... |