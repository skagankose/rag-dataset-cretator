# Dataset: 02759 coinkolik com

Generated on: 2025-12-20T00:16:33.887745
Total questions: 1

| # | Question                                                                 | Answer     | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------ | ---------- | -------- | ----------------- |
| 1 | Metne göre Uniswap (UNI) son 24 saatte yüzde kaç oranında değer kazandı? | Yüzde 9.36 | FACTUAL  | c0000             |