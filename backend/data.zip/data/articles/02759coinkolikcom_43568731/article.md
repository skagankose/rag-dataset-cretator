---
id: 02759coinkolikcom_43568731
url: file://02759_coinkolik_com.md
title: 02759 coinkolik com
lang: en
created_at: '2025-12-20T00:16:24.534784'
checksum: 1debcd0990862144fbe9f11e576fa78fd55966ef50ecd3300c2ae13a46c9b45f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 75
  char_count: 543
  num_chunks: 1
  num_sections: 1
---
= UNI Hakkında Haberler =

En iyi merkezi olmayan finans (DeFi) kripto paraları, Ethereum (ETH) fiyatındaki güce rağmen düşüyor. Verilere göre, ABD doları karşısında Uniswap (UNI), SushiSwap (SUSHI), AAVE (AAVE) gibi DeFi token'ları son 24 saatte önemli düşüşler kaydetti. Kripto…

Bitcoin (BTC) rallisinin duraklama düğmesine basmasıyla, merkezi olmayan finans (DeFi) sektörü nihayet yükseliş anına kavuştu. Aave (AAVE) ve Uniswap (UNI), son 24 saat içinde sırasıyla yüzde 18.59 ve yüzde 9.36 oranında değer kazanarak CoinMarketCap'te piyasa…