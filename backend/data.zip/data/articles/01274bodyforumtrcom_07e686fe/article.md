---
id: 01274bodyforumtrcom_07e686fe
url: file://01274_bodyforumtr_com.md
title: 01274 bodyforumtr com
lang: en
created_at: '2025-12-19T23:37:44.541794'
checksum: d03f16a38b61f08b6b03a6ef904d35f6dd74abb6257e36c8ff3c47a3f4ef8a5c
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 444
  char_count: 3002
  num_chunks: 4
  num_sections: 1
---
Konusu 'Kadınlara Özel - Beslenme & Diyet' forumundadır ve crocus tarafından 11 Ocak 2014 başlatılmıştır. arkadaşlar şubat tatilinden sonra definasyon diyetine başlayacağım 1.65 boy 55 kiloyum. kadınlar için tam bir diyet bulamadım açık bir şekilde ne yenmesi gerektiği konusunda bilgisi olan varsa yazabilir mi? crocus, 11 Ocak 2014 110 gr protein içeren günlük kalori ihtiyacının %20 altında bir diyet, muhtemelen 1500 kalori civarı. Basit şeker az, hayvansal protein çok, kaç öğünde rahat edebiliyorsanız o kadar öğün, neyi yemeyi daha çok seviyorsanız o yemek, hangi saatlerde yemek daha uygunsa o saatler. Haftada 1 sabah aç karna tartılın. Yağ yakımı başladıysa devam. Başlamadıysa 1 hafta daha devam. 2. hafta da yağ yakımı başlamadıysa 100-150 kalori daha aşağı. Kadınların dikkat edeceği bir nokta regl döneminde vücutta su tutulumu. Yağ yakımı devam ettiği halde tartıda aynı veya daha ağır çıkartarak gereksiz yere moral bozulmasına sebep olabilir. En gerçekçi tartım periyodun aynı günlerindeki tartımlar arasındaki farklardır. Bu periyodun 15. günüyle gelecek periyodun 15. günü gibi. Asıl ilerlemenin ne yönde olduğunu bu gösterir.

Zaten fazla kilonuz yok, o yüzden kas kaybetmemek için protein alımı sizin için mesela aynı boyda olup 75 kilo olan bir kadından daha önemli. Yağ oranı düştükçe kas kaybı riski artar. Super yazmissin benim antreman prog bakmissindir belki ihtiyacimi gidermesi cok onemli bikac sorum olacak karbonhidrat pirinc lapasi yada tahilli makarna pismis 150 gr skmdide bole yiyom zati protein de sinir koymuyodum ama 110 gr yeterli diosun light peynir yogurt yenebilir mi zeytin varmi mesela bunlar gibi yumurta sarisi hoc yememek mi lazim yesil elma yenebilir mi yoksa meyve sekeride almamak mi sureci hizlandirir ceviz badem kuru kayisi falan yasak mi tatli die bunlari yiyom simdi hocam 5ay surer bu diyet dedi karin kasi cikartmak asil amac

dip not crocus, 12 Ocak 2014 Karbonhidrat alımını azaltıp, 110-120 gram kadar protein alman yeterli. Karbonhidratı sıfırlarsan daha hızlı sonuç alırsın. Peki protein alimini sadrce et ve yumurtadan mi almak lazim peynir yulaf ve yogurt yenebilir mi acaba tabiki kisiye gore degisiyordur ama birde protein bar yiyebilir miyiz sekersiz olanindan Süt ürünleri kişiden kişiye değişmekle beraber su tutumunu arttırabilir. Yoğurt ve sütün ise gram başı karbonhidrat miktarı çok fazla olmasa da düşük karbonhidratlı beslenme düzeni için nispeten yüksek. Lor güzel bir kaynak olur. Diğer et ürünleri ana protein kaynağın olmak üzere tabii ki onlardan da tüketebilirsin. Protein barların ise hem şekerden olmasa da karbonhidrat miktarları çok yüksek, hem de protein gramı başına ödediğin para fazla. Katı bir definisyon için uzak durmanda fayda var. Protein alımını supplement'ten çok Raw gıdaya kaydırman definisyonu kolaylaştırır.

Anladim baya zor gececek bir surec benim icin umarim tatli krizi vurmaz beni tesekkur ederim bilgiler icin crocus, 13 Ocak 2014 Karbonhidrat tüketimini TAMAMEN kesersen, tatlı krizi yaşamazsın.