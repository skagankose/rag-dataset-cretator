# Dataset: 04158 teknocozumler com

Generated on: 2025-12-20T00:39:52.236662
Total questions: 1

| # | Question                                  | Answer    | Category | Related_Chunk_IDs |
| - | ----------------------------------------- | --------- | -------- | ----------------- |
| 1 | Oyunun kaç görevden oluştuğu belirtilmiş? | 140 görev | FACTUAL  | c0000             |