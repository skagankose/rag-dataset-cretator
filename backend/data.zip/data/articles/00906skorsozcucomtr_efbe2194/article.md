---
id: 00906skorsozcucomtr_efbe2194
url: file://00906_skor_sozcu_com_tr.md
title: 00906 skor sozcu com tr
lang: en
created_at: '2025-12-19T23:25:40.537213'
checksum: f9d700d1e02abee7798616027f0657dbe0f41f4ba2daaa91edc6d77a5ffcc1a9
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 416
  char_count: 2967
  num_chunks: 4
  num_sections: 1
---
= Serdar Dursun 'Topa elle dokunmak ve kafa vurmak yasak' – Spor Haberleri =

Almanya 2'nci Ligi'nde Darmstadt 98 forması giyen golcü futbolcu Serdar Dursun, gelecek hedeflerinden A Milli Takıma, corona virüs için Almanya'da alınan önlemlerden bir çok konuya önemli açıklamalarda bulundu.

**Güncellenme:** 11:01, 11/04/2020

Darmstadt 98 formasıyla hem lig, hem de kupada 27 maçta 14 gol, 5 asistlik performans gösteren 28 yaşındaki futbolcu, "Yaklaşık 4 senedir Bundesliga 2'de oynuyorum. Her sezon başı ve devre arasında güzel teklifler oluyor. Mayıs 2021'de kontratım bitecek. Türkiye'de oynamayı hiç düşünmedim, bu sezon güzel bir teklif ve proje olursa Türkiye'ye **ye** dönmeyi düşünebilirim" dedi.

Bundesliga takımları tarafından takip edildiğini belirten golcü futbolcu, "Benim en büyük hedefim ve dileğim Bundesliga'da oynamak. Kalan maçlarda da iyi performans gösterebilirsem neden olmasın. Geçen sezon da Bundesliga ekipleriyle görüşmeler oldu ancak nasip olmadı. Şu an yakından takip eden ve izleyen kulüpler var. Bonservis konusunda anlaşma sağlanırsa bu yaz Bundesliga'ya transferim olabilir" diye konuştu.

Türk forvetler olarak çok fazla alternatif olmadığını dile getiren Dursun, "Burak Yılmaz, Cenk Tosun ve Enes Ünal var. Üçü de milli takımda. Zaten başka forvet de yok. Bu üçünü sayabilirim. Çoğu insan beni fiziksek olarak İbrahimoviç'e benzetiyor. Uzun boy, teknik, oyun ve saç stilimden dolayı. Futbolda örnek aldığım isim de İbrahimoviç" şeklinde konuştu.

En büyük hayalinin A Milli Takım olduğuna vurgu yapan Dursun, "Çocukluğumdan beri hayal ettiğim şey A Milli Takımda oynamak. En büyük hedefim bu. Her gün bunun için çalışıyorum. Bu yıl da iyi bir performans gösteriyorum. İnşallah ilerleyen dönemlerde Şenol Güneş beni görür ve beğenir. A Milli Takıma çağrılırsam başarılı olacağımı düşünüyorum" ifadelerini kullandı.

Corona virüs salgını nedeniyle belirli kurallara bağlı olarak antrenmanlara başladıklarını söyleyen Dursun, "Kulübümüz geçen gün antrenmanlara başladı. 5'er grup halinde 2 farklı sahada farklı zamanlarda antrenmanlar yapıyoruz. Sahadaki 5 kişinin de ayrı yerlerde kalması lazım. Kulüpte giyinmek ve duş almak yasak. Eşyaların evde yıkanması lazım ve üzerimizi evde giyerek antrenmana gidiyoruz. Giderken suyumuzu da kendimiz götürüyoruz. Şu ana kadar pas oyunu, koşu ve şut çalışması yaptık. Topa elle dokunmak ve kafa vurmak yasak. Antrenörler ve hocalar yakın olmamamız için sürekli dikkat ediyor ve bizi uyarıyorlar. Tabii ki normal antrenman gibi değil ama değişiklik güzel oldu. En azından sahada toplu oynuyoruz. Yaklaşık 1 aydır evde bisiklet sürerdik ya da parkta koşardık. O nedenle bu değişiklik güzel oldu. Takım arkadaşlarımızı da görmüş olduk" açıklamasında bulundu.

"CORONA VİRÜSTE ALMANYA BAŞARILI BİR DÖNEM GEÇİRİYOR" Sağlığın önemini dile getiren Dursun, "Burada yaşayan bir vatandaş olarak Almanya'nın başarılı bir dönem geçirdiğini söyleyebilirim. Herkes için bir ilk ve zor bir dönem. Çoğu in...