# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                                                                                |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | ------------------------------------------------------------------------------------------------------ |
| c0000 | Kanarya Sarısı Galaxy S10e Konsepti Ortaya Çıktı | Kanarya Sarısı Galaxy S10e Konsepti Ortaya Çıktı | 0-1000     | = Kanarya Sarısı Galaxy S10e Konsepti Ortaya Çıktı = Samsung'un Kanarya Sarısı Galaxy S10e modeline... |
| c0001 | Kanarya Sarısı Galaxy S10e Konsepti Ortaya Çıktı | Kanarya Sarısı Galaxy S10e Konsepti Ortaya Çıktı | 800-1389   | önden görünüşünde herhangi bir farklılık bulunmayacak ancak cam arka panel ve metal çerçeveler,...     |