# Dataset: 02000 soru doktorsitesi com

Generated on: 2025-12-20T00:02:13.316539
Total questions: 1

| # | Question                                                                                               | Answer                                                                                       | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------- | -------- | ----------------- |
| 1 | Metne göre florür uygulaması diş minesinin görünümünde farklılığa yol açar mı veya dişleri çürütür mü? | Hayır; bahsedilen şekilde zarar vermez. Ancak diş sıkması nedeniyle olan sızlamayı geçirmez. | FACTUAL  | c0000             |