---
id: 00865skorsozcucomtr_d3e7fc46
url: file://00865_skor_sozcu_com_tr.md
title: 00865 skor sozcu com tr
lang: en
created_at: '2025-12-19T23:24:18.537587'
checksum: 033167e5167d11e7e94de3a6703f8a862b1542256102a250c376b90f5752a06a
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 199
  char_count: 1479
  num_chunks: 2
  num_sections: 1
---
= Fenerbahçe, yeni sezon formalarını tanıttı! Yeni transferler sahnede… =

Fenerbahçe, yeni sezonda giyeceği formaları görkemli bir törenle tanıttı. Sarı‑lacivertliler biri alternatif, biri klasik olmak üzere iki çubuklu, bir lacivert ve bir de sarı formayı taraftarının beğenisine sunacak. Forma tanıtımında takımın yeni transferleri boy gösterdi.

18 Temmuz 2019 22:46 – Fenerbahçe, 2019‑2020 sezonunda giyeceği formaları tanıttı. Tanıtım töreninde yönetim, teknik heyet ve futbolcular da yer aldı.

Fenerbahçe'nin forma tanıtımında yeni transferler yer alırken, Emre Belözoğlu'nun tribünlerin efsane isimleri İhsan Teyze ve Mümtaz Amca'nın isimlerinin yazdığı çubuklu formaları İhsan Teyze'ye verdiği anlar ekranlara yansıdı ve duygusal anlar yaşandı...

Fenerbahçe Başkanı Ali Koç, forma tanıtımı öncesi tek tek futbolcularla ve ayrıca Sportif Direktör Damien Comolli ile sohbet etti.

Başkan Ali Koç, Teknik Direktör Ersun Yanal ve Sportif Direktör Comolli üçlüsü bir süre küçük bir üçlü zirve de gerçekleştirdi.

> Ali Koç: "Geçen yıl sezon formalarında mağazalarımızdan 261 bin adet, Adidas mağazalarından 70 bin forma olmak üzere 330 bin forma satıldı. Tarihimizin 2. en iyi sezon satışını gerçekleştirdik. Yönetim değişikliğinden sonra bir önceki sezonun 55 bin adet formasını erittik."

> Ali Koç: "Çubuklu formaya gözünüz alışacak. Bu senenin formalarında da radikal düşünceler geliştirdik. Çubuklu formaya bambaşka bir dizayn getirdik. Gözünüz alışacak göreceksiniz."