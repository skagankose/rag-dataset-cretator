---
id: 04178ulasimdaniletis_646bf1e8
url: file://04178_ulasimdaniletisime_com.md
title: 04178 ulasimdaniletisime com
lang: en
created_at: '2025-12-20T00:40:03.543081'
checksum: f0e36d06e8a4b595655c81eacc8a38370870e59a32bf79288a5e10c8ecb01420
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 121
  char_count: 953
  num_chunks: 1
  num_sections: 1
---
= Türkiye İle Birleşik Krallık Arasında Havacılık Güvenliği Alanında 2021 Yılı İşbirliği Programı İmzalandı =

Türkiye ile Birleşik Krallık arasında havacılık güvenliği alanında, 2021 yılı İşbirliği Programı 11 Mart 2021 tarihinde, Sivil Havacılık Genel Müdürümüz Sayın Prof. Dr. Kemal YÜKSEK ile Büyük Britanya ve Kuzey İrlanda Birleşik Krallığı Büyükelçisi Sayın Sir Dominick CHİLLCOTT KCMG tarafından imzalandı.

**Güncelleme:** 26‑03‑2021 23:27:10  
**Tarih:** 26‑03‑2021 23:19

Toplantıda, 2017, 2018 ve 2019 yıllarında da iki ülke arasında var olan işbirliği programlarının etkin bir şekilde yürütüldüğü belirtildi. Ancak 2020 yılında, içinde bulunduğumuz Covid‑19 salgınının etkisiyle, iki ülke arasında ortak etkinlik, çalıştay ve yıllık denetimlerin iptal edilmesi zorunluluğunun doğduğu açıklandı.

2021 yılında söz konusu ortak faaliyetlerin gerekli tedbirler alınarak, daha etkin yürütülmesine yönelik 2021 yılı İşbirliği Programı imzalandı.