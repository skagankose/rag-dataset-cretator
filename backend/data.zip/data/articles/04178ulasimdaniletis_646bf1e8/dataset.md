# Dataset: 04178 ulasimdaniletisime com

Generated on: 2025-12-20T00:40:12.589562
Total questions: 1

| # | Question                                              | Answer       | Category | Related_Chunk_IDs |
| - | ----------------------------------------------------- | ------------ | -------- | ----------------- |
| 1 | 2021 yılı İşbirliği Programı hangi tarihte imzalandı? | 11 Mart 2021 | FACTUAL  | c0000             |