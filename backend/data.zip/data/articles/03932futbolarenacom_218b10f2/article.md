---
id: 03932futbolarenacom_218b10f2
url: file://03932_futbolarena_com.md
title: 03932 futbolarena com
lang: en
created_at: '2025-12-20T00:35:57.552416'
checksum: 4ab36045c1f6c232888dff9a260f2cdc1a601cf02aec74a84bd7ed8b32548198
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 93
  char_count: 744
  num_chunks: 1
  num_sections: 1
---
= 08 Haziran 2018, Cuma 18:33 =

Medipol Başakşehir, Teleset Mobilya Akhisarspor'dan Soner Aydoğdu ile 3 yıllık sözleşme imzaladı.

FutbolArena - Spor Toto Süper Lig'i 3'üncü sırada bitiren Medipol Başakşehir, yeni sezon öncesi ilk transferini gerçekleştirdi.

Turuncu‑lacivertli ekip, Süper Lig takımlarından Teleset Mobilya Akhisarspor'da forma giyen Soner Aydoğdu ile 3 yıllık sözleşme imzaladı.

Başakşehir kulübünün resmi internet sitesinden yapılan açıklamada, "Kulübümüz, başarılı futbolcu Soner Aydoğdu ile 3 yıllık anlaşmaya varmıştır. 27 yaşındaki oyuncunun imza törenine Asbaşkanımız Mustafa Saral katıldı. Yeni transferimiz Soner Aydoğdu'ya aramıza hoş geldin diyor, turuncu‑lacivertli formamız altında başarılar diliyoruz" denildi.