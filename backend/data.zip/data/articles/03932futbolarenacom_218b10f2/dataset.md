# Dataset: 03932 futbolarena com

Generated on: 2025-12-20T00:36:06.789601
Total questions: 1

| # | Question                                                        | Answer        | Category | Related_Chunk_IDs |
| - | --------------------------------------------------------------- | ------------- | -------- | ----------------- |
| 1 | Medipol Başakşehir hangi oyuncu ile 3 yıllık sözleşme imzaladı? | Soner Aydoğdu | FACTUAL  | c0000             |