# Chunks Index

| ID    | Section                     | Heading Path                | Char Range | Preview                                                                                              |
| ----- | --------------------------- | --------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | 08 Haziran 2018, Cuma 18:33 | 08 Haziran 2018, Cuma 18:33 | 0-744      | = 08 Haziran 2018, Cuma 18:33 = Medipol Başakşehir, Teleset Mobilya Akhisarspor'dan Soner Aydoğdu... |