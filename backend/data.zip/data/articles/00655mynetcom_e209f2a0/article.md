---
id: 00655mynetcom_e209f2a0
url: file://00655_mynet_com.md
title: 00655 mynet com
lang: en
created_at: '2025-12-19T23:17:18.535406'
checksum: 7cc083ca143dbd00be2a1fbc91e93fdc831c37cc2dbc83dd95b469306f7e579f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 91
  char_count: 767
  num_chunks: 1
  num_sections: 1
---
= Tarihi hikayelerle öğrenecekler - Son Dakika Haberler =

Trabzon'da uygulanan, "Neslim Ecdadımın İzinde Projesi" kapsamında, Osmanlı padişahları ve Selçuklu sultanlarının hayat hikayeleri ve başarıları, öğretmenler tarafından hikayeleştirilerek anlatılacak.  

Proje kapsamında çeşitli okullarda İngilizce, sınıf öğretmenliği, okul öncesi ve rehber öğretmenliği branşlarından 18 öğretmene hikaye anlatıcılığının incelikleri konusunda eğitim verildi.  

Hikaye anlatıcısı Tekşen: "Bu bizim sözlü halk sanatımız olduğu için aslında unutulmaya yüz tutmuş da bir sanat dalıdır. Anadolu ve her yerde hikayeler var. Bunları unutmamamız gerektiğini düşünüyorum."  

"Neslim Ecdadımın İzinde" projesi Öykü Tekşen, Trabzon, Trabzon Ticaret İlkokulu öğretmeni Mürsel Hunutlu.