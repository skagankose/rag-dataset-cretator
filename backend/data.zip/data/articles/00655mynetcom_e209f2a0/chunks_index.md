# Chunks Index

| ID    | Section                                               | Heading Path                                          | Char Range | Preview                                                                                              |
| ----- | ----------------------------------------------------- | ----------------------------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Tarihi hikayelerle öğrenecekler - Son Dakika Haberler | Tarihi hikayelerle öğrenecekler - Son Dakika Haberler | 0-767      | = Tarihi hikayelerle öğrenecekler - Son Dakika Haberler = Trabzon'da uygulanan, "Neslim Ecdadımın... |