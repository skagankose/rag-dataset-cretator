# Dataset: 00655 mynet com

Generated on: 2025-12-19T23:17:26.314940
Total questions: 1

| # | Question                                                                                    | Answer       | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------------------------------------------- | ------------ | -------- | ----------------- |
| 1 | Proje kapsamında kaç öğretmene hikaye anlatıcılığının incelikleri konusunda eğitim verildi? | 18 öğretmene | FACTUAL  | c0000             |