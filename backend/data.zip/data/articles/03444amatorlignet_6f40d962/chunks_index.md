# Chunks Index

| ID    | Section                                                  | Heading Path                                             | Char Range | Preview                                                                                   |
| ----- | -------------------------------------------------------- | -------------------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------- |
| c0000 | Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu | Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu | 0-1000     | = Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu = İstanbul Süper Amatör Lig 8. |
| c0001 | Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu | Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu | 800-1492   | Hüseyin Çakır ve yönetimi yanı sıra taraftar temsilcileri de katıldı.                     |