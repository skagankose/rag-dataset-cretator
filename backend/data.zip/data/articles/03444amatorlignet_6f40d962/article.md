---
id: 03444amatorlignet_6f40d962
url: file://03444_amatorlig_net.md
title: 03444 amatorlig net
lang: en
created_at: '2025-12-20T00:27:49.546687'
checksum: 84f3151331f2aa50bc1c5cbc0a952c7936e5bae0c7b7e7f8c2553a780a3fd050
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 183
  char_count: 1492
  num_chunks: 2
  num_sections: 1
---
= Gültepeliler ve Ayazağalılar zorlu maç öncesinde buluştu =

İstanbul Süper Amatör Lig 8. Grup 3. hafta karşılaşmasında Pazar günü İBB Bayrampaşa Stadında tarafsız sahada oynanacak olan Gültepespor‑Ayazağaspor karşılaşması öncesinde iki takım başkanları, yöneticiler ve taraftar temsilcileri yemekte buluştu.

Pazar günü oynanacak karşılaşmaya iki takım taraftarlarının da yoğun bir katılım göstermesi beklenirken, maç öncesinde İBB Bayrampaşa Stadında yoğun güvenlik önlemlerinin alınacağı belirtildi.

İlk hafta karşılaşmasında İASFK aleyhine pankart açan ve ilginç bir şekilde iki maç saha kapatma cezası alan Gültepespor, Ayazağaspor'u tarafsız sahada konuk edecek.

Zorlu karşılaşma öncesinde ev sahibi Gültepespor Başkanı Zeki Özcan misafirliğinde gerçekleştirilen yemeğe, Ayazağaspor Başkanı Hüseyin Çakır ve yönetimi yanı sıra taraftar temsilcileri de katıldı. Oldukça samimi bir şekilde geçen yemekte iki takım başkanı birbirlerine başarılar dilerken, hak edenin kazanacağı bir karşılaşma olması dileklerinde bulundular.

Taraftar temsilcileri de karşılaşma öncesinde sosyal medyada ortam gerecek paylaşım yapılmaması ve karşılaşma boyunca sadece kendi takımlarını destekleme konusunda fikir birliğine vararak, yapacakları görsel şovlar ve tezahüratlarla birbirlerine üstünlük sağlamaya çalışacaklarını belirttiler.

Karşılaşma öncesinde gerçekleştirilen bu güzel organizasyonun Pazar günü de devam etmesi bekleniyor. İki güçlü camia da maçta hak edenin kazanmasını temenni ettiler.