# Dataset: 01281 bodyforumtr com

Generated on: 2025-12-19T23:38:12.342204
Total questions: 1

| # | Question                                                | Answer                            | Category | Related_Chunk_IDs |
| - | ------------------------------------------------------- | --------------------------------- | -------- | ----------------- |
| 1 | Kullanıcının elindeki glutamine ürününün tam adı nedir? | UNİVERSAL 2700 MHP GLUTAMINE -SR. | FACTUAL  | c0000             |