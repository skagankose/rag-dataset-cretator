# Chunks Index

| ID    | Section | Heading Path | Char Range | Preview                                                                                    |
| ----- | ------- | ------------ | ---------- | ------------------------------------------------------------------------------------------ |
| c0000 | Lead    | Lead         | 0-745      | Konusu 'Supplementler' forumundadır ve fernandes tarafından 17 Temmuz 2012 başlatılmıştır. |