---
id: 00885gazetemistanbul_1a853bdf
url: file://00885_gazetemistanbul_com.md
title: 00885 gazetemistanbul com
lang: en
created_at: '2025-12-19T23:24:57.534467'
checksum: 34a4a0f9474d3ef8035ea7fd98f2aeac2cb5983bce30142b41a4aa55f76e00d3
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 88
  char_count: 701
  num_chunks: 1
  num_sections: 1
---
= Eric Bailly Manchester United’da gidiyor =

İngiliz devi Manchester United, geride kalan sezonda Villarreal formasıyla önemli katkı yapan Eric Bailly'nin transferini bitirmek üzere. Jose Mourinho'nun göreve başlamasıyla transferde hareketli günler geçiren Manchester United, Villarreal'de harikalar yaratan savunma oyuncusu Eric Bailly'yi kadrosuna katmaya hazırlanıyor.

Fanatik'in haberine göre, İspanyol kulübü “Sarı Denizaltılar”la 30 milyon Euro bonservis bedeline anlaştığı öğrenilen United'ın, cuma günü transferi resmen açıklaması bekleniyor. Geçtiğimiz sezon başında Espanyol'dan 5 milyon Euro'ya Villarreal'in yolunu tutan Bailly, çıktığı 35 maçta 2 990 dakika süre aldı ve 1 gol kaydetti.