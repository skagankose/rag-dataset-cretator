# Chunks Index

| ID    | Section                                  | Heading Path                             | Char Range | Preview                                                                                              |
| ----- | ---------------------------------------- | ---------------------------------------- | ---------- | ---------------------------------------------------------------------------------------------------- |
| c0000 | Eric Bailly Manchester United’da gidiyor | Eric Bailly Manchester United’da gidiyor | 0-701      | = Eric Bailly Manchester United’da gidiyor = İngiliz devi Manchester United, geride kalan sezonda... |