# Dataset: 00885 gazetemistanbul com

Generated on: 2025-12-19T23:25:07.181825
Total questions: 1

| # | Question                                                                                                  | Answer                                            | Category | Related_Chunk_IDs |
| - | --------------------------------------------------------------------------------------------------------- | ------------------------------------------------- | -------- | ----------------- |
| 1 | Eric Bailly, Villarreal formasıyla geçtiğimiz sezonda kaç maçta kaç dakika süre aldı ve kaç gol kaydetti? | 35 maçta 2990 dakika süre aldı ve 1 gol kaydetti. | FACTUAL  | c0000             |