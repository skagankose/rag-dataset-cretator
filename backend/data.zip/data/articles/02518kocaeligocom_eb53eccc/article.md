---
id: 02518kocaeligocom_eb53eccc
url: file://02518_kocaeligo_com.md
title: 02518 kocaeligo com
lang: en
created_at: '2025-12-20T00:12:23.510436'
checksum: cd2294319527023fe9568ad5043b973fb1b64cb7f3746d7aecf4cdef933b4a49
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 216
  char_count: 1651
  num_chunks: 3
  num_sections: 2
---
= Domates Çorbası - Sebzeli Çorba =

Kocaeli Yaşam Sebzeli Çorba Domates Çorbası Orta büyüklükteki bir kase domates çorbası yaklaşık olarak 63 kaloriye denk gelmektedir. Sıcacık içinizi ısıtacak bu harika tarife hadi gelin geçelim.

== Giriş 18.12.2019 11:36 ==

- Domates (4-5 adet)
- Tereyağı (2 çorba kaşığı)
- Rendelenmiş taze kaşar (1 çorba kaşığı)

Çorbanıza başlamak için öncelikli olarak yağ ve ununuzu bir tencerede kavurun. Diğer taraftan domateslerinizin kabuğunu soyup, küp küp doğrayın. Ardından tencerede kavurduğunuz yağ ve ununuzun içerisine ekleyin ve birkaç dakika daha kavurun. Kavurma işleminizin bitiminde 1 litre suyunuzu da tencerenize ekleyip 15 dakika kaynatın. Daha sonrasında 1 su bardağı sütünüzü ekleyerek birkaç dakika daha kaynatın ve tuzunu da ilave edin. Çorbanızı sıcak servis edin. Çorbanızı servis ederken rendelenmiş kaşar peynirini domates çorbanızın üzerine ekleyin. Çorbanız servis e hazır, afiyet olsun.

Domates çorbanızı yaz mevsiminde yapacak iseniz tane olgun domatesleri kullanabilirsiniz fakat kış mevsiminde iseniz, yaz mevsiminden hazırladığınız domates soslarınızı kullanabilirsiniz. Arzu ederseniz çorbanızın içerisine şehriye ekleyerek, arpa şehriyeli domates çorbası da yapabilirsiniz. Domates çorbanız ekşi olursa çorbanızın içerisine bir miktar havuç ekleyip ekşiliğini gidebilirsiniz. Piştikten sonra havuçları çorbanızdan alın. Küp küp doğrayıp içerisine patates eklerseniz de çorbanızın ekşiliğini ve tuzluluğunu giderir. Piştikten sonra içerisinden patateslerinizi alın. Domates çorbanızın yanına patates kızartması ile köfte yapabilirsiniz veya makarna da çorbanızın yanına çok yakışacaktır.