---
id: 03746lifebursacom_8240d6fc
url: file://03746_lifebursa_com.md
title: 03746 lifebursa com
lang: en
created_at: '2025-12-20T00:32:51.600621'
checksum: 419222731ee8cadd38b6b2a0f14a42975782bbbd429fedd0393784628af9c531
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 262
  char_count: 1918
  num_chunks: 3
  num_sections: 1
---
= Kraliçe Elizabeth'in iki haftalık yası bitti, neşeli tavrı dikkat çekti =

== 28 Nisan 2021, Çarşamba, 11:11 ==

Kraliçe Elizabeth'in, eşi Edinburgh Dükü Prens Philip'in hayatını kaybetmesinin ardından iki haftalık Kraliyet yası geçtiğimiz Cuma günü sona erdi. Yas süresinin sona ermesinin ardından bir Kraliyet işi sırasında ilk kez görüntülenen Kraliçe'nin neşeli olduğu görülürken sık sık gülümsemesi dikkat çekti.

9 Nisan günü eşi, Edinburgh Dükü Prens Philip'in hayatını kaybetmesi sonrası Kraliyet yası süreci başlayan Kraliçe Elizabeth'in geçtiğimiz Cuma günü resmi yas süresi sona erdi. Son olarak eşinin cenaze töreninde siyah kostümüyle ve üzgün yüzüyle görüntülenen Elizabeth'in görüşmede güler yüzü ve neşeli tavrı dikkat çekerken büyük mor, beyaz ve sarı çiçeklerden oluşan soluk mavi çiçekli bir elbise giydiği görülürken üç telli inci kolye ve aksesuar olarak elmas bir broş taktığı görüldü.

73 yıllık eşi Prens Philip'in hayatını kaybetmesinden bu yana resmi bir Kraliyet işi yaparken ilk kez görüntülenen Kraliçe'nin elçilerle yaptığı görüşmede, sıkça güldüğü ve pozitif bir havada olduğu görülürken büyükelçilerden çevrim içi ortamda güven mektubu aldığı bildirildi.

Eşi Edinburgh Dükü Prens Philip'in hayatını kaybetmesinden 12 gün sonra 95'nci yaş gününü kutlayan Kraliçe Elizabeth, doğum günü mesajında "büyük bir üzüntü" duyduğunu söylemişti. 17 Nisan'da düzenlenen cenaze törenleri sırasında görülen Kraliçe ise, törende tek başına oturduğu ve üzüntülü haliyle görüntülenmişti.

Kraliçe Elizabeth, eşi Prens Philip'in ölümünden sadece dört gün sonra kraliyet görevlerine geri dönmüştü. 95 yaşındaki Britanya Kraliçesi, hanesinin en üst düzey yetkililerinden olan eski Lord Chamberlain Earl Peel'in emeklilik töreni için ilk yüz yüze etkinliğine ev sahipliği yapmış, Windsor Kalesi'nde düzenlenen tören sırasında Kraliçe, eski kraliyet yardımcısının asasını ve görev işaretini kabul etmişti.