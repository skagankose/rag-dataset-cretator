# Chunks Index

| ID    | Section                        | Heading Path                   | Char Range | Preview                                                                                               |
| ----- | ------------------------------ | ------------------------------ | ---------- | ----------------------------------------------------------------------------------------------------- |
| c0000 | 28 Nisan 2021, Çarşamba, 11:11 | 28 Nisan 2021, Çarşamba, 11:11 | 77-1077    | == 28 Nisan 2021, Çarşamba, 11:11 == Kraliçe Elizabeth'in, eşi Edinburgh Dükü Prens Philip'in...      |
| c0001 | 28 Nisan 2021, Çarşamba, 11:11 | 28 Nisan 2021, Çarşamba, 11:11 | 877-1877   | elmas bir broş taktığı görüldü.                                                                       |
| c0002 | 28 Nisan 2021, Çarşamba, 11:11 | 28 Nisan 2021, Çarşamba, 11:11 | 1677-1918  | lerinden olan eski Lord Chamberlain Earl Peel'in emeklilik töreni için ilk yüz yüze etkinliğine ev... |