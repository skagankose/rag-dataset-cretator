---
id: 00312eksisozlukcom_f768286c
url: file://00312_eksisozluk_com.md
title: 00312 eksisozluk com
lang: en
created_at: '2025-12-19T23:06:00.556868'
checksum: f5193e9dfa440d12a2787fd97ab6e32daf57b5ed41dbe7091dfe8ab206010697
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 392
  char_count: 3020
  num_chunks: 4
  num_sections: 1
---
= Chartalism =

chartalism - ekşi sözlük meghan markle'ın kraliyeti ırkçılıkla suçlaması 170 72 yıl önce eşi tarafından bilekleri kesilen kadın 23 engelli kadına yapılan ahlaksız yorumlar 58 köylülerin lakap takarken çok insafsız olması 123 8 mart 2021 ekrem imamoğlu tweet'i 444 erkek annesi ikiyüzlülüğü 92 paranın değerini materyalde değil para kullanımını regüle eden yönetmeliklerde ve devlet otoritesinde temellendiren görüştür. "charta" latincede kağıt ve papirüs anlamına gelir. bu açıdan bakıldığında "chartalism" adı, paranın içsel bir değeri olmayıp kıymetini yasalardan aldığı fikri ile uyuşur.

knapp, chartalist para mefhumunu bir tiyatronun vestiyer odasına ceketler bırakılırken alınan, üzerinde bir sayı yazan küçük teneke parçalarına veya posta ücreti ödendiğinde mektuba yapıştıran pullara benzetir. pulun ve tenekenin doğal bir değeri yoktur, onları değerli kılan materyalden bağımsız antlaşmalardır. bu bağlamda, bir değişim metası olarak paranın ilkel takas yöntemlerinden evrildiğini söylemek pek anlamlı olmaz. tahıla karşı kolye verildiğinde ne kolye ne de tahıl para birimi olarak kabul edilemez, burada özel bir alışveriş vardır. ancak bir hiyerarşi sisteminde, üst sınıflar tahılı bir ödeme standardı olarak belirlediğinde burada bir değişim metası olarak paradan söz edilebilir. yani parayı para olarak tanımlamak için, paranın metal veya kağıt olması zaruri değildir.

knapp ortaya attığı teorinin zıttını da yine kendisi yazar: metallism. (bkz: metallism/@highpriestess) metallismde chartalismin aksine paranın içsel değeri vardır. yani paranın değeri materyalden gelir. tarihte ikisi de bir arada görülür. mesela, antik mezopotamya medeniyetlerinde görülmüş pratikler iki bakış açısından da değerlendirilebilir. öyle ki, bir ödeme aracı olarak kullanılan tahıl da bir nevi gücünü hiyerarşi sisteminden alan bir para birimi işlevi görmüştür. lakin tahıl işlevseldir de. mohenjo-daro ve harappa'da bulunan, elitlerin yaşadığı hisarlardaki devasa tahıl ambarları korunmuştur.

orta çağda bir kral kendi parasını istediği formda bastırmıştır. kralın kendi otoritesini topraklarının sınırları içinde vergileri o paralardan temin edebilmesine yetmiştir. ancak söz konusu dış ticaret olduğunda altın gibi metalar kullanılmıştır çünkü altının materyal olarak evrensel bir öz değeri vardır. günümüzde devletlerin bastırdığı paranın altın karşılığı yoktur, devletleri uluslararası alan sınırlar. eğer keynes'in önerdiği türde bir supranasyonel birim olsaydı dünyada şimdiki esnek döviz kuru sisteminden ve abd dolarının rezerv birim olarak kabul görmesinden farklı bir sistem egemen olurdu.

modern para büyük ölçüde chartlismin öne sürdüğü gibi itibarî iken, cryptocurrency gibi bağımsız para sistemleri chartalist teoriye kökten tezattır. bu yüzden bitcoin haberlerinde "cryptocurrency is agorism in action" gibi başlıklar görebiliriz. (bkz: agorizm/@highpriestess) 07.10.2020 01:47 ~ 03:17 highpriestess kripto paraların da modeline uygun olduğunu düşündüğüm para yaklaşımı. kripto teknolojileri