# Dataset: 01475 yeniasya com tr

Generated on: 2025-12-19T23:44:38.968518
Total questions: 1

| # | Question                                                                                 | Answer                       | Category | Related_Chunk_IDs |
| - | ---------------------------------------------------------------------------------------- | ---------------------------- | -------- | ----------------- |
| 1 | Valiliğin açıklamasına göre Alacaatlı mevkisinde süren yol çalışmasında ne kullanılıyor? | Dinamitle çalışma yapılıyor. | FACTUAL  | c0000             |