---
id: 01475yeniasyacomtr_7c91ac1a
url: file://01475_yeniasya_com_tr.md
title: 01475 yeniasya com tr
lang: en
created_at: '2025-12-19T23:44:27.542912'
checksum: ca344969fd6ed02ed045c3a1893b5bfc2ecce9b4d29a42e3de5e137ff4be8924
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 62
  char_count: 496
  num_chunks: 1
  num_sections: 1
---
= Ankara Valiliği: Bir patlama söz konusu olmadı =

*YENİ ASYA*  
08 Şubat 2018, Perşembe 17:55  

Ankara Valiliğinden, Çankaya ilçesi Alacaatlı mevkisinde süren yol çalışmasında dinamit kullanıldığı, bir patlamanın söz konusu olmadığı bildirildi. Valilik, sosyal medyada "Ankara'da patlama olduğu" yönünde yer alan iddialara ilişkin açıklama yaptı. Açıklamada, "Alacaatlı mevkisinde devam eden yol çalışmasında dinamitle çalışma yapılmaktadır. Patlama söz konusu değildir." ifadeleri kullanıldı.