---
id: 00396grafikerlernet_411e6fa6
url: file://00396_grafikerler_net.md
title: 00396 grafikerler net
lang: en
created_at: '2025-12-19T23:08:39.530468'
checksum: d4165308d1d92bb2eceea9d16983aa539f30ca245008102c9da3a5b2861b11c0
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 345
  char_count: 2598
  num_chunks: 3
  num_sections: 1
---
= UC‑Logic LaPazz A4 Profesyonel Dizayn Tablet (PF1209‑TABA1) =

UC‑Logic LaPazz PF1209 A4 Boy Grafik Tablet Yeni A4 oyun alanınız! Ayarlanabilir yükseklik seviyesi, geniş bileklik alanı ve ergonomik kalemi sayesinde kolunuzu rahatça dayayıp keyifle çizmeye başlayın!

Öncelikle tabletin arka kısmında bulunan yükseltme aparatları çok zekice düşünülmüş; önceki tabletimde hep bunun eksikliğini çekiyordum. Şimdi bu aparatlar sayesinde tableti 20 dereceli açıda kullanabiliyorum. Tabletin kurulumu çok basit, 2 dakika içinde oturup çizmeye başladım. Opsiyonlar da sade ve anlaşılır, basınç ayarlama özelliği kullanışlı.

Tabletin ön panelinde gördüğüm en önemli özellik, çizim alanının üstündeki ince plastiğin oldukça dayanıklı oluşu. Neden önemli derseniz, önceki tabletimde çizim alanının üstündeki plastiğin yıpranması sebebiyle (özellikle çok kullandığım orta bölümlerde) kabartılar oluşmuştu. Her ne kadar milimlik de olsa çizerken sorun oluşturuyorlardı; oysa ki bu üründe ne kadar bastırırsam bastırayım yüzeyde bir çizik oluşturamadım, bu da ileride çizim yüzeyinde bir sorun oluşmayacağını gösteriyor.

Tabletin ön paneli oldukça geniş ve bu sayede çizerken bileğinize destek oluyor. Kısa yollar da çok kullanışlı; Photoshop ve Painter ile çok uyumlu bir şekilde çalışabiliyorsunuz. Basınç hassasiyeti çok dengeli, ince‑kalın ve koyu‑açık geçişlerinde oldukça smooth sonuçlar elde ettim. Açıkçası 1 haftalık bir kullanıcı olarak söyleyebilirim ki, şekil dışında piyasadaki rakiplerinden aşağı kalır bir yanı yok, hatta UC‑Logic yükseltme aparatları sayesinde bence artı özelliklere sahip.

Diğer marka tabletlere gücü yetmeyen kullanıcılar için harika bir alternatif. PF1209 ile birlikte gelen tablet yüzeyinde kullanabileceğiniz 3 tuşlu mouse ve P23 çizim kalemi, kalemi yerleştirebileceğiniz ayrı kalem tutucusu ile birlikte üst seviye tabletlerdeki ergonomik kullanım imkanını size sunmaktadır. Kutudan çıkan 3 adet yedek uç size 1000 saatten fazla bir kullanım ömrü sunar. Bu sayede sürekli olarak günde 3 saatlik bir kullanım ile 1 yıl boyunca yedek kalem ihtiyacınız olmadan ürünü kullanabilirsiniz. Ayrıca satın alabileceğiniz yedek kalemler de yanlarında 3 adet yedek uçla birlikte gelmektedir.

MacOS 9 / X Tiger (Leopard) sürücüsünü uc‑logic.com.tr sitesinden indirebilirsiniz. Aktif Alan A4  
Stok Kodu BD46898  
Mağazaya Eklenme 26.06.2006  

Arkadaşım, en son fiyatı ne olur? Açıkçası bir tablete ihtiyacım var, hiç bir problemi yoksa ben talibim. Özelime yaz, anlaşalım. Şirket bilgileri ilanın alt kısmında yazıyor; bize o numaralardan ulaşabilirsiniz. Özel mesaj atılmıyor.