---
id: 01137risalehabercom_f694607a
url: file://01137_risalehaber_com.md
title: 01137 risalehaber com
lang: en
created_at: '2025-12-19T23:33:11.529232'
checksum: 72f25a35bae3944f496a7975776090db8449e0e709a8d1156b98f7ed86c16816
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 182
  char_count: 1465
  num_chunks: 2
  num_sections: 1
---
= İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin =

10:4909 Aralık 2015 Diyarbakırlı olsaydınız, kundaklanan, içi cephaneliğe dönüştürülen Kurşunlu Camii için feryat ederdiniz. İçiniz yanardı.

Risale Haber‑Habe Merkezi Yazar Ahmet Taşgetiren, teröristler tarafından yakılan Kurşunlu cami ile Kürtlerin asimile edildiğini söyledi. Star'daki yazısında Selahattin Demirtaş ve onunla birlikte yürüyenlere çağrıda bulunan Taşgetiren, "Siz önce Diyarbakırlılaşın. Hatta siz önce Kürtleşin! Türkiyelileşmek de onun içinde. Diyarbakırlılaşırsanız İstanbullulaşırsınız" dedi.

Taşgetiren, bu çağrısıyla ne kastettiğini de şöyle açıkladı: "Diyarbakırlı olsaydınız, mesela Tahir Elçi gibi, gider, kurşun yarası alan Dört Ayaklı Minare'nin yanında 'Kıymayın bu minarelere' diye seslenirdiniz. Diyarbakırlı olsaydınız, kundaklanan, içi cephaneliğe dönüştürülen Kurşunlu Camii için feryat ederdiniz. İçiniz yanardı. Bir iki sözünüz olurdu ağıt babında. Nerdesiniz Sayın Demirtaş? Yok mu iki kelamınız Sur içindeki her sokağı mevzi haline getirip patlamaya hazır bombalarla dolduranlara karşı?"

Asıl asimilasyon hareketinin, PKK'nın Kürtler üzerindeki operasyonu ile gerçekleştiğine dikkat çeken Taşgetiren, "Kürt olmak! Nedir sahi o? Bir kan aidiyeti midir? O camiyi kundaklayan hayta Kürt müdür? Kafasında zırnık tarih bilinci olmayan, çocuk yaşta dağa çıkarılıp eline silah verilen ve kültürsüzlüğün dip gayyasına sürüklenen gençte Kürtlük adına ne kalmıştır?" dedi.