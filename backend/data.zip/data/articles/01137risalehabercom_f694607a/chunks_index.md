# Chunks Index

| ID    | Section                                                 | Heading Path                                            | Char Range | Preview                                                                                         |
| ----- | ------------------------------------------------------- | ------------------------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin | İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin | 0-1000     | = İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin = 10:4909 Aralık 2015 Diyarbakırlı... |
| c0001 | İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin | İçinize biraz Selahattin Eyyubi biraz Said Nursi girsin | 800-1465   | rlı olsaydınız, kundaklanan, içi cephaneliğe dönüştürülen Kurşunlu Camii için feryat ederdiniz. |