---
id: 01320sonhaberlercom_f7c39fff
url: file://01320_sonhaberler_com.md
title: 01320 sonhaberler com
lang: en
created_at: '2025-12-19T23:39:17.530595'
checksum: 170b019d26a116c54ec1a78db62720d6a570339b2599e1ac6032c43edb4a913f
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 169
  char_count: 1267
  num_chunks: 2
  num_sections: 1
---
= İstanbul en güvenli metropoller arasında =

*Son Dakika Haberler*  
06 Eylül 2016, Salı 13:17  

Zirvenin açılış programına Maliye Bakanı Naci Ağbal'ın yanısıra İstanbul Valisi Vasip Şahin katıldı. Burada konuşan Vali Şahin, şunları söyledi:

> "İstanbul içinde bulunduğumuz coğrafya itibariyle belki riskli bir alan görünse de, aslında terörün globalleşmesi, bütün dünyayı tehdit ediyor olması İstanbul'u da diğer şehirlerden daha fazla riskli göstermiyor. Dünyanın herhangi bir metropolü ne kadar terör tehdidi ile karşı karşıyaysa, İstanbul'da ancak o kadar terör tehdidi ile karşı karşıyadır. Bizim yakın coğrafyamızdaki huzursuzluklar bizi bu konuda biraz daha riskli gösterse de, yaşanan olaylara baktığımızda algıda oluşan risk kadar yüksek bir riske sahip değiliz. Şehri yönetenler olarak bu riski en yüksek seviyede algılayarak tedbirlerimizi oranda alıyoruz. Gerek istihbarat, gerekse fiziki güvenlik tedbirleri konusunda bugün dünyada her halde en fazla gayret eden güvenlik teşkilatı İstanbul ve Türkiye'de görev yapıyor."

Genel asayişte güvenlik konusunu ele aldığımızda; İstanbul'da 2015 yılında bir önceki yıla göre asayiş olaylarında %9 azalma görülmüştür. Genel metropol karşılaştırmalarında da İstanbul en güvenli kentler arasında yer almaktadır.