# Chunks Index

| ID    | Section                                  | Heading Path                             | Char Range | Preview                                                                                         |
| ----- | ---------------------------------------- | ---------------------------------------- | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | İstanbul en güvenli metropoller arasında | İstanbul en güvenli metropoller arasında | 0-1000     | = İstanbul en güvenli metropoller arasında = *Son Dakika Haberler* 06 Eylül 2016, Salı 13:17... |
| c0001 | İstanbul en güvenli metropoller arasında | İstanbul en güvenli metropoller arasında | 800-1267   | u riski en yüksek seviyede algılayarak tedbirlerimizi oranda alıyoruz.                          |