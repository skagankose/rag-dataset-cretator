# Chunks Index

| ID    | Section                              | Heading Path                         | Char Range | Preview                                                                                         |
| ----- | ------------------------------------ | ------------------------------------ | ---------- | ----------------------------------------------------------------------------------------------- |
| c0000 | Kampanyalı Fiyatlar & Taksit Fırsatı | Kampanyalı Fiyatlar & Taksit Fırsatı | 21-96      | == Kampanyalı Fiyatlar & Taksit Fırsatı == 9.5 Mükemmel 92 Değerlendirme                        |
| c0001 | Otel Bilgileri                       | Otel Bilgileri                       | 96-1096    | == Otel Bilgileri == Embarc Panorama misafirlere Panorama bölgesinde, kayak teleferiklerinin... |
| c0002 | Otel Bilgileri                       | Otel Bilgileri                       | 896-1373   | na yürüme mesafesindeki bu dairede ayrıca açık havuz ve spa küveti sunulmaktadır.               |