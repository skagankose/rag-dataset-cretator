---
id: 03779ozgurdenizlicom_5e92b0fc
url: file://03779_ozgurdenizli_com.md
title: 03779 ozgurdenizli com
lang: en
created_at: '2025-12-20T00:33:24.547352'
checksum: 4272604b28e84b580b63141a38a2b65dd1496a797dc68e379b9dd1a42fd9cc76
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 391
  char_count: 3032
  num_chunks: 4
  num_sections: 1
---
= 12 Eylül'ün cesur kadınları – Esra Çiftçi – Özgür Denizli =

23 Eylül 2021 19 Eylül 2021 tarihinde, Haber Merkezi | 378 Views | 80 dk. okundu  

Bu gün 12 Eylül dosyamızın üçüncü ve son bölümünü 12 Eylül'ün kadınlarına ayırdık. 12 Eylül darbe sonrası cezaevi direnişlerinde, açlık grevlerinde, işkence tezgahlarında hep erkeklerin adı geçti. Oysa aynı vahşeti belki de daha ağırlarını kadınlar yaşadı. Toplumun hemen hemen bütün kesimlerini derinden etkileyen darbe her kadın için elbette farklı şekillerde yaşandı. Mücadelenin bir parçası olmalarına rağmen pek önde görülmeyen kadınlar darbeciler ve uzantıları tarafından göz ardı edilmedi. Bilindik işkencelerin yanı sıra özel olarak taciz, tecavüz ve cinsiyetçi saldırılara maruz kaldılar.

**“12 EYLÜL ABD GÜDÜMÜNDE BİR SERMAYE HAREKETİ”**  
**“12 EYLÜL ÖNCESİ BU TOPRAKLARDA TOPLUMSAL ZENGİNLİK ORTAYA ÇIKARDI”**  
**“12 EYLÜL İŞKENCECİLERİNİN SABIKASI HİÇBİR ZAMAN SİLİNMEYECEK”**

Alpay, devrimci duyguların ve hareketliliğin yükseldiğini ama “devrimci durum” denilen nesnel koşulların olmadığının altını çiziyor. Alpay'ın sözleri şöyle: “Hareketlilik belirli gençlik kesimlerinin birbirinden kopuk çıkışlarıyla sınırlıydı. Sınıfsal hareketlilik ise 15‑16 Haziran 1970 işçi eylemlerini düşünürsek, 12 Mart 1971 darbesi dönemindekinden bile daha sınırlıydı. Peki, ordu neden o kadar ‘orantısız’ bir güç kullandı? Çünkü darbeyi yapanlar ‘onların çocukları’ydı.”

“Darbe öncesinde Mülkiye'de çiçeği burnunda bir öğretim üyesiydim. Darbe olduğunda bu gelenin bir faşist diktatörlük olduğu fikri oluştu bende. Özellikle iktisatçı Eugene Varga'nın tezlerine dayanıyordu bu fikrim. Mensup olduğum partinin (TKP) görüşü ise bunun bir ‘askerî diktatörlük’ olduğu yönündeydi. Ankara il örgütünün benden bu konuda bir yazı istediğini hatırlıyorum. Yazı arşivlerinde midir, bilmiyorum. Cunta başlıca sol örgütlere sırayla ‘operasyon’ uyguluyordu. TKP operasyonu başladığında eşimle birlikte Ankara'dan ayrıldık. Yurt dışına çıkmak istemiyorduk, yerel direnişler örgütlemeyi deneyecektik. Temmuz 1981'de ben İzmir'de yakalandım. Bir hafta İzmir emniyetinde işkence gördüm. Ardından Ankara'ya, ünlü DAL'a götürüldüm. Oradan da bir ay sonra Mamak Askerî Cezaevi'ne götürdüler.”

“TCK'nın ünlü 141‑142. maddeleri kaldırıldığında, cezamın geriye kalanı kalkmış oldu. Kimliğimi almak üzere Mamak'taki mahkemeye gittiğimde, bizi mahkûm etmiş olan heyetten iki yargıçla karşılaştım. Siz bir fikir suçlususunuz dediler bana. TCK'nın ilgili maddeleri kalkınca, benim sabıkam da silinmiş oldu. 12 Eylül işkencecilerinin sabıkası ise hiçbir zaman silinmeyecek. Onlar insanlık suçu işlediler.”

“Bir sabah uyandığımızda çatıların üzerinde namlularını bize doğrultmuş askerleri görünce önce ‘darbemi acaba?’ dedik ama biz ‘siyasi kızları’ Selimiye'ye götürmeye gelmişlerdi. Benim yanımda 9 aylık oğlum vardı, hamile arkadaşlar ve sağlığı bozuk olanlarımızla birlikte toplama kampına gider gibi tüm direnmemize rağmen o havasız cemselere doldurdular. Selimiye'ye gelince de havasız bir koğuşta saa...