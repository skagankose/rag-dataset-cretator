---
id: 02190kadinlarkulubuc_a3812bca
url: file://02190_kadinlarkulubu_com.md
title: 02190 kadinlarkulubu com
lang: en
created_at: '2025-12-20T00:06:55.519794'
checksum: b0ee777bbb40b4b1b2405e5fde9d686031963214ceedc0efaa99adfd68c2bcbe
options:
  chunk_size: 1000
  chunk_overlap: 200
  split_strategy: header_aware
  total_questions: 2
  llm_model: gpt-5-mini
stats:
  word_count: 158
  char_count: 1225
  num_chunks: 2
  num_sections: 1
---
= Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. =

Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. Konusu “Yurtdışı Paylaşım K.K.T.C.” forumundadır ve Temizhayalim tarafından 6 Mayıs 2009’da başlatılmıştır. Konu sahibi: Temizhayalim.

Temizhayalim: Gecemin güneşi kızlar, eşim 2 aydır işi dolayısıyla orada. Biz de Haziran’da okullar kapanınca geleceğiz, yani taşınacağız ama istediğimiz gibi ev bulamadık. Lütfen oraları bilenler yardımcı olsun. Görürseniz müstakil, bahçeli 3+1 arıyoruz. İşini Karakum’da emlakçıdan sorduk, hep Girne merkezde gösterdi, hep. Bina istemedik.  

Temizhayalim, ne arıyorsunuz? Dublex mi? Walla, Girne turistik bir yer olduğu için genelde villalar vardır; dolayısıyla müstakil evlerin fiyatları da yüksektir. Teşekkür ederim ama ben taşındım, Girne'deyim; şimdi burayı sevdim ama sadece bir komşum var Çatalköy’de. Müstakil ev tuttuk, ilgine teşekkür. Ben uzun zaman açamadım; net yeni aldık ancak yerleştik işte.

Seksibebek, nasıl Girne? Biz de Mayıs’ta oradayız, hayırlısıyla. Seksibebek, MinikKelebegimm, Minik kelebeğim artık kollarımda...

Merhabalar, bizim de eşimin işinden dolayı Kıbrıs’a taşınma durumumuz var. Girne Kaşgara. Birkaç sorum olacak; yardımcı olabilecek var mı acaba?