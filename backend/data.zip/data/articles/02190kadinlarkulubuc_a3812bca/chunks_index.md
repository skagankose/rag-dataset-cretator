# Chunks Index

| ID    | Section                                          | Heading Path                                     | Char Range | Preview                                            |
| ----- | ------------------------------------------------ | ------------------------------------------------ | ---------- | -------------------------------------------------- |
| c0000 | Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. | Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. | 0-1000     | = Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. |
| c0001 | Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. | Arkadaşlar, ben Girne'ye taşınıcam, yardım edin. | 800-1225   | ayı sevdim ama sadece bir komşum var Çatalköy’de.  |